/* Native order editor: review current server policy before each mutation. */
(function ($) {
 'use strict';
 const panel = document.querySelector('.editharbor-panel');
 if (!panel) return;
 const form = panel.closest('form');
 const reason = document.getElementById('editharbor-reason');
 const nonce = document.querySelector('[name="editharbor_nonce"]');
 if (!form || !reason || !nonce) return;
 let page = 1, replay = false, reviewing = false;
 const controls = '#publish, #save, .save_order, .save-action, .delete-order-item, .add-order-item, .add-order-fee, .add-order-shipping, .add-order-tax, .add-coupon, .remove-coupon, .calculate-action, .recalculate';
 function state() {
  return $(form).serializeArray().filter(function (field) { return !/nonce|editharbor_|closedpostboxes|meta-box-order/.test(field.name); }).map(function (field) { return field.name + '=' + field.value; }).join('&');
 }
 let baseline = state();
 function mutation(data) { return /(?:^|&)action=woocommerce_(?:save_order_items|calc_line_taxes|add_order_item|add_order_fee|add_order_shipping|add_order_tax|remove_order_item|remove_order_coupon|add_coupon_discount)(?:&|$)/.test(data || ''); }
 $(document).ajaxComplete(function (_, xhr, options) {
  if (!mutation(options.data) || xhr.status >= 400 || (xhr.responseJSON && xhr.responseJSON.success === false)) return;
  baseline = state(); reason.value = ''; load();
 });
 $.ajaxPrefilter(function (options) {
  if (mutation(options.data)) options.data += '&' + $.param({editharbor_reason:reason.value,editharbor_nonce:nonce.value});
 });
 function load() {
  $.post(editharborAdmin.url, {action:'editharbor_history',nonce:editharborAdmin.nonce,order_id:panel.dataset.order,page:page,category:panel.querySelector('.editharbor-category').value}).done(function (response) {
   if (!response.success) return;
   panel.querySelector('.editharbor-history').innerHTML = response.data.html;
   panel.querySelector('.editharbor-prev').disabled = page === 1;
   panel.querySelector('.editharbor-next').disabled = !response.data.has_more;
   panel.querySelector('.editharbor-page').textContent = page;
  });
 }
 panel.querySelector('.editharbor-prev').addEventListener('click',function () { page=Math.max(1,page-1);load(); });
 panel.querySelector('.editharbor-next').addEventListener('click',function () { page++;load(); });
 panel.querySelector('.editharbor-category').addEventListener('change',function () { page=1;load(); });
 panel.querySelector('.editharbor-search').addEventListener('input',function (event) {
  const keyword=event.target.value.toLocaleLowerCase();
  panel.querySelectorAll('.editharbor-event').forEach(function (entry) { entry.hidden=!entry.textContent.toLocaleLowerCase().includes(keyword); });
 });
 function proceed(target,submitter) {
  replay=true;
  try { if (submitter) form.requestSubmit(submitter); else target.click(); } finally { replay=false; }
 }
 function review(target,submitter,config) {
  const dialog=document.createElement('dialog');dialog.className='editharbor-dialog';
  const heading=document.createElement('h2');heading.id='editharbor-dialog-title';heading.textContent=editharborAdmin.title;
  dialog.setAttribute('aria-labelledby',heading.id);dialog.appendChild(heading);
  [config.message,config.paid?editharborAdmin.paid:'',config.warning && !config.message?editharborAdmin.protected:''].filter(Boolean).forEach(function (text) { const p=document.createElement('p');p.textContent=text;dialog.appendChild(p); });
  let input;
  if (config.required && config.action!=='block') {
   const label=document.createElement('label');label.htmlFor='editharbor-dialog-reason';label.textContent=editharborAdmin.reason;
   input=document.createElement('textarea');input.id='editharbor-dialog-reason';input.value=reason.value;input.maxLength=config.max;
   dialog.appendChild(label);dialog.appendChild(input);
  }
  const error=document.createElement('p');error.className='editharbor-error';error.setAttribute('role','alert');dialog.appendChild(error);
  const footer=document.createElement('footer');const cancel=document.createElement('button');cancel.type='button';cancel.className='button';cancel.textContent=editharborAdmin.cancel;
  cancel.addEventListener('click',function () { dialog.close(); });footer.appendChild(cancel);
  if (config.action!=='block') {
   const confirm=document.createElement('button');confirm.type='button';confirm.className='button button-primary';confirm.textContent=config.action==='approval'?editharborAdmin.submitApproval:editharborAdmin.continue;
   confirm.addEventListener('click',function () {
    if (input && (Array.from(input.value.trim()).length<config.min || Array.from(input.value.trim()).length>config.max)) { error.textContent=editharborAdmin.reasonError;input.focus();return; }
    if (input) reason.value=input.value.trim();
    dialog.close();proceed(target,submitter);
   });footer.appendChild(confirm);
  }
  dialog.appendChild(footer);dialog.addEventListener('close',function () { dialog.remove();target.focus(); });
  document.body.appendChild(dialog);dialog.showModal();(input || cancel).focus();
 }
 function intent(target) {
  for (const [selector,action] of [['.save-action','save_order_items'],['.delete-order-item','remove_order_item'],['.add-order-item','add_order_item'],['.add-order-fee','add_order_fee'],['.add-order-shipping','add_order_shipping'],['.add-order-tax','add_order_tax'],['.add-coupon','add_coupon_discount'],['.remove-coupon','remove_order_coupon'],['.calculate-action,.recalculate','tax_recalculation']]) { if (target.matches(selector)) return action; }
  return 'save_order';
 }
 function check(target,submitter) {
  if (reviewing) return;
  reviewing=true;target.setAttribute('aria-busy','true');
  const row=target.closest('[data-order_item_id]');
  $.post(editharborAdmin.url,{action:'editharbor_order_review',nonce:nonce.value,order_id:panel.dataset.order,form:$(form).serialize(),intent:intent(target),item_id:row?row.dataset.order_item_id:0}).done(function (response) {
   if (!response.success) { review(target,submitter,{action:'block',message:response.data.message || editharborAdmin.reviewError});return; }
   const config=response.data;
   const length=Array.from(reason.value.trim()).length;
   if (config.action==='block' || config.action==='approval' || config.paid || config.warning || (config.required && (length<config.min || length>config.max))) review(target,submitter,config);
   else proceed(target,submitter);
  }).fail(function (xhr) { review(target,submitter,{action:'block',message:(xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || editharborAdmin.reviewError}); }).always(function () { reviewing=false;target.removeAttribute('aria-busy'); });
 }
 document.addEventListener('click',function (event) {
  const target=event.target.closest(controls);
  if (!target || replay || !form.contains(target)) return;
  const main=target.matches('#publish,#save,.save_order');
  if (main && state()===baseline) return;
  event.preventDefault();event.stopImmediatePropagation();check(target,main?target:null);
 },true);
 form.addEventListener('submit',function (event) {
  if (replay || state()===baseline) return;
  const target=event.submitter || form.querySelector('.save_order,#publish,#save');
  if (!target) return;
  event.preventDefault();check(target,event.submitter || target);
 });
})(jQuery);
