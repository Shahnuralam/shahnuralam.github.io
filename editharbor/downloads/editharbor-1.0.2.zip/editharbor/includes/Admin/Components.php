<?php
/**
 * Shared, accessible workspace presentation.
 *
 * @package EDHB
 */
namespace EDHB\Admin;

defined( 'ABSPATH' ) || exit;

/** Small native HTML components shared by Free and extensions. */
final class Components {
	/** Render a page introduction. */
	public static function heading( $label, $title, $description ) {
		echo '<div class="editharbor-section-header"><span class="editharbor-eyebrow">' . esc_html( $label ) . '</span><h2>' . esc_html( $title ) . '</h2><p>' . esc_html( $description ) . '</p></div>';
	}

	/** Render a labelled count with explanatory text. */
	public static function metric( $label, $value, $description, $icon = 'chart-bar' ) {
		echo '<div class="editharbor-metric"><span class="editharbor-metric-label"><span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span>' . esc_html( $label ) . '</span><strong>' . esc_html( number_format_i18n( (int) $value ) ) . '</strong><span class="editharbor-metric-help">' . esc_html( $description ) . '</span></div>';
	}

	/** Explain an empty result with a useful next step. */
	public static function empty_state( $title, $description, $icon = 'clipboard' ) {
		echo '<div class="editharbor-empty"><span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $description ) . '</p></div>';
	}

	/** Friendly names for recorded operation origins. */
	public static function sources() {
		return array(
			'wc_admin'         => __( 'Order editor', 'editharbor' ),
			'ajax'             => __( 'Admin item editor', 'editharbor' ),
			'rest'             => __( 'API / integration', 'editharbor' ),
			'store_api'        => __( 'Store checkout API', 'editharbor' ),
			'checkout'         => __( 'Checkout', 'editharbor' ),
			'cron'             => __( 'Scheduled task', 'editharbor' ),
			'action_scheduler' => __( 'WooCommerce background task', 'editharbor' ),
			'wp_cli'           => __( 'Command line', 'editharbor' ),
			'unknown'          => __( 'Other / unknown source', 'editharbor' ),
		);
	}

	/** Readable event labels retain machine identifiers in storage. */
	public static function event_label( $type ) {
		$labels = array(
			'order_updated'      => __( 'Order edited', 'editharbor' ),
			'order_locked'       => __( 'Order locked', 'editharbor' ),
			'order_unlocked'     => __( 'Order unlocked', 'editharbor' ),
			'order_relocked'     => __( 'Order locked again', 'editharbor' ),
			'approval_requested' => __( 'Approval requested', 'editharbor' ),
			'approval_approved'  => __( 'Change approved', 'editharbor' ),
			'approval_rejected'  => __( 'Change rejected', 'editharbor' ),
			'approval_cancelled' => __( 'Request cancelled', 'editharbor' ),
			'restore_performed'  => __( 'Previous values restored', 'editharbor' ),
			'order_restored'     => __( 'Previous values restored', 'editharbor' ),
			'values_restored'    => __( 'Previous values restored', 'editharbor' ),
			'logs_cleaned'       => __( 'Old history removed', 'editharbor' ),
			'unusual_activity'   => __( 'Activity needs review', 'editharbor' ),
		);
		return $labels[ $type ] ?? ucwords( str_replace( '_', ' ', $type ) );
	}

	/** Friendly status text for approvals and deliveries. */
	public static function status_label( $status ) {
		$labels = array(
			'pending'   => __( 'Awaiting review', 'editharbor' ),
			'applying'  => __( 'Applying changes', 'editharbor' ),
			'approved'  => __( 'Approved', 'editharbor' ),
			'rejected'  => __( 'Rejected', 'editharbor' ),
			'cancelled' => __( 'Cancelled', 'editharbor' ),
			'failed'    => __( 'Needs attention', 'editharbor' ),
			'sending'   => __( 'Sending', 'editharbor' ),
			'delivered' => __( 'Delivered', 'editharbor' ),
		);
		return $labels[ $status ] ?? ucwords( str_replace( '_', ' ', $status ) );
	}

	/** A text badge conveys state without relying on color. */
	public static function badge( $label, $state = 'neutral' ) {
		echo '<span class="editharbor-status-pill editharbor-status-' . esc_attr( sanitize_key( $state ) ) . '">' . esc_html( $label ) . '</span>';
	}
}
