<?php
/** One-page administration with section-scoped asynchronous settings. @package EDHB */
namespace EDHB\Admin;

defined( 'ABSPATH' ) || exit;
final class Workspace {
	private $plugin;
	public function __construct( $plugin ) {
		$this->plugin = $plugin; }
	public function register() {
		add_action( 'wp_ajax_editharbor_workspace_panel', array( $this, 'panel_ajax' ) );
		add_action( 'wp_ajax_editharbor_save_settings', array( $this, 'save_ajax' ) );
		add_action( 'admin_init', array( $this, 'redirect_legacy' ) );
	}
	public function tabs() {
		return apply_filters(
			'editharbor_admin_tabs',
			array(
				'overview'    => array(
					'label'      => __( 'Overview', 'editharbor' ),
					'icon'       => 'dashboard',
					'group'      => 'activity',
					'capability' => 'editharbor_view_all_audits',
				),
				'audit'       => array(
					'label'      => __( 'Audit history', 'editharbor' ),
					'icon'       => 'clock',
					'group'      => 'activity',
					'capability' => 'editharbor_view_all_audits',
				),
				'general'     => array(
					'label'      => __( 'General', 'editharbor' ),
					'icon'       => 'admin-settings',
					'group'      => 'settings',
					'capability' => 'editharbor_manage_settings',
				),
				'reasons'     => array(
					'label'      => __( 'Change reasons', 'editharbor' ),
					'icon'       => 'edit',
					'group'      => 'settings',
					'capability' => 'editharbor_manage_settings',
				),
				'warnings'    => array(
					'label'      => __( 'Order protection', 'editharbor' ),
					'icon'       => 'shield',
					'group'      => 'settings',
					'capability' => 'editharbor_manage_settings',
				),
				'privacy'     => array(
					'label'      => __( 'Privacy & data', 'editharbor' ),
					'icon'       => 'privacy',
					'group'      => 'settings',
					'capability' => 'editharbor_manage_settings',
				),
				'maintenance' => array(
					'label'      => __( 'System status', 'editharbor' ),
					'icon'       => 'heart',
					'group'      => 'settings',
					'capability' => 'editharbor_manage_settings',
				),
			)
		);
	}
	public function sections() {
		return array(
			'general'  => array( 'enabled', 'manual', 'automated', 'order_notes', 'date_display', 'per_page' ),
			'reasons'  => array( 'reason_mode', 'reason_statuses', 'reason_min', 'reason_max' ),
			'warnings' => array( 'warn_paid', 'warning_statuses' ),
			'privacy'  => array( 'log_ip', 'mask_display', 'retain_personal', 'delete_data' ),
		);
	}
	private function access( $section ) {
		$tabs = $this->tabs();
		return isset( $tabs[ $section ] ) && current_user_can( $tabs[ $section ]['capability'] ); }
	public function menu() {
		add_menu_page( __( 'EditHarbor', 'editharbor' ), __( 'EditHarbor', 'editharbor' ), 'editharbor_view_order_audit', 'editharbor', array( $this, 'page' ), 'dashicons-shield', 56 );
	}
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL controls; screen access is capability checked.
	public function redirect_legacy() {
		if ( wp_doing_ajax() || ! isset( $_GET['page'] ) ) {
			return; }
		$page = sanitize_key( wp_unslash( $_GET['page'] ) );
		$map  = array(
			'editharbor-audit'         => 'audit',
			'editharbor-settings'      => 'general',
			'editharbor-pro-settings'  => 'pro-rules',
			'editharbor-pro-approvals' => 'pro-approvals',
			'editharbor-pro-reports'   => 'pro-reports',
		);
		if ( isset( $map[ $page ] ) ) {
			$query            = array_map( 'sanitize_text_field', wp_unslash( $_GET ) );
			$query['page']    = 'editharbor';
			$query['section'] = $map[ $page ];
			wp_safe_redirect( add_query_arg( $query, admin_url( 'admin.php' ) ) );
			exit; }
	}	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL controls; screen access is capability checked.
	public function page() {
		$tabs = array_filter(
			$this->tabs(),
			static function ( $tab ) {
				return current_user_can( $tab['capability'] );
			}
		);
		if ( ! $tabs ) {
			wp_die( esc_html__( 'Open an order to view its edit history.', 'editharbor' ) ); }
		$section = isset( $_GET['section'] ) && is_scalar( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : key( $tabs );
		if ( ! isset( $tabs[ $section ] ) ) {
			$section = key( $tabs ); }
		echo '<div class="wrap editharbor-workspace"><h1 class="screen-reader-text">EditHarbor</h1><div class="editharbor-workspace-header"><div class="editharbor-wordmark"><span class="editharbor-brand-icon dashicons dashicons-shield" aria-hidden="true"></span><div><h2>' . esc_html__( 'EditHarbor', 'editharbor' ) . '</h2><p>' . esc_html__( 'A little more confidence in every order change.', 'editharbor' ) . '</p></div></div><div class="editharbor-header-state' . ( $this->plugin->get( 'settings' )->get( 'enabled' ) ? '' : ' editharbor-paused' ) . '"><span class="editharbor-state-dot" aria-hidden="true"></span><span class="editharbor-header-state-label">' . esc_html( $this->plugin->get( 'settings' )->get( 'enabled' ) ? __( 'Auditing is on', 'editharbor' ) : __( 'Auditing is paused', 'editharbor' ) ) . '</span></div></div><div class="editharbor-workspace-layout"><aside class="editharbor-sidebar"><nav role="tablist" aria-label="' . esc_attr__( 'EditHarbor sections', 'editharbor' ) . '" aria-orientation="vertical">';
		$group = '';
		foreach ( $tabs as $key => $tab ) {
			if ( $group !== $tab['group'] ) {
				$group = $tab['group'];
				echo '<p class="editharbor-nav-label">' . esc_html( 'activity' === $group ? __( 'Your store', 'editharbor' ) : ( 'settings' === $group ? __( 'Settings', 'editharbor' ) : __( 'Pro tools', 'editharbor' ) ) ) . '</p>'; }
			echo '<button type="button" id="editharbor-tab-' . esc_attr( $key ) . '" role="tab" aria-controls="editharbor-section-' . esc_attr( $key ) . '" aria-selected="' . ( $key === $section ? 'true' : 'false' ) . '" tabindex="' . ( $key === $section ? '0' : '-1' ) . '" data-section="' . esc_attr( $key ) . '"><span class="dashicons dashicons-' . esc_attr( $tab['icon'] ) . '" aria-hidden="true"></span><span>' . esc_html( $tab['label'] ) . '</span><span class="editharbor-dirty-indicator" aria-hidden="true"></span></button>';
		}
		echo '</nav><div class="editharbor-sidebar-note"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><p>' . esc_html__( 'Order changes are recorded. Payments are never collected or refunded by this plugin.', 'editharbor' ) . '</p></div><span class="editharbor-version">v' . esc_html( EDHB_VERSION ) . '</span></aside><main class="editharbor-main"><div class="editharbor-loading" role="status" hidden>' . esc_html__( 'Loading your settings…', 'editharbor' ) . '</div><div class="editharbor-panels"><section id="editharbor-section-' . esc_attr( $section ) . '" data-section="' . esc_attr( $section ) . '" role="tabpanel" aria-labelledby="editharbor-tab-' . esc_attr( $section ) . '" tabindex="0">';
		$this->content( $section );
		echo '</section></div><div class="editharbor-toast" role="status" aria-live="polite" hidden></div></main></div></div>';
	}	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	public function panel_ajax() {
		check_ajax_referer( 'editharbor_workspace', 'nonce' );
		$section = isset( $_GET['section'] ) && is_scalar( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : '';
		if ( ! $this->access( $section ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have access to this section.', 'editharbor' ) ), 403 ); }
		ob_start();
		$this->content( $section );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}
	public function revision( $section, $settings = null ) {
		$settings = $settings ?? $this->plugin->get( 'settings' )->all();
		return hash( 'sha256', wp_json_encode( array_intersect_key( $settings, array_flip( $this->sections()[ $section ] ?? array() ) ) ) );
	}
	public function save_ajax() {
		check_ajax_referer( 'editharbor_workspace', 'nonce' );
		if ( ! current_user_can( 'editharbor_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot change these settings.', 'editharbor' ) ), 403 ); }
		$section = isset( $_POST['section'] ) && is_scalar( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';
		if ( ! isset( $this->sections()[ $section ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown settings section.', 'editharbor' ) ), 400 ); }
		$revision = isset( $_POST['revision'] ) && is_scalar( $_POST['revision'] ) ? sanitize_text_field( wp_unslash( $_POST['revision'] ) ) : '';
		if ( ! isset( $_POST['editharbor_settings'] ) || ! is_array( $_POST['editharbor_settings'] ) ) {
			wp_send_json_error( array( 'message' => __( 'The settings payload is invalid.', 'editharbor' ) ), 400 );
		}
		$posted = map_deep( wp_unslash( $_POST['editharbor_settings'] ), 'sanitize_text_field' );
		$result   = \EDHB\Support\Settings_Lock::update(
			'editharbor_settings',
			function () use ( $section, $revision, $posted ) {
				if ( ! hash_equals( $this->revision( $section ), $revision ) ) {
					return new \WP_Error( 'editharbor_settings_stale', __( 'These settings were changed in another session. Reload this section and review your changes.', 'editharbor' ), array( 'status' => 409 ) );
				}
				$current  = $this->plugin->get( 'settings' )->all();
				$defaults = $this->plugin->get( 'settings' )->defaults();
				foreach ( $this->sections()[ $section ] as $key ) {
					$current[ $key ] = $posted[ $key ] ?? ( is_array( $defaults[ $key ] ) ? array() : ( is_bool( $defaults[ $key ] ) ? false : $defaults[ $key ] ) ); }
				$clean = $this->plugin->get( 'settings' )->sanitize( $current );
				update_option( 'editharbor_settings', $clean, false );
				if ( get_option( 'editharbor_settings' ) !== $clean ) {
					return new \WP_Error( 'editharbor_settings_failed', __( 'The database could not save your settings. Please try again.', 'editharbor' ), array( 'status' => 500 ) ); }
				return array(
					'message'  => __( 'Your settings are saved.', 'editharbor' ),
					'revision' => $this->revision( $section, $clean ),
					'settings' => $clean,
				);
			}
		);
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), $result->get_error_data()['status'] ?? 500 ); }
		wp_send_json_success( $result );
	}
	public function content( $section ) {
		if ( ! $this->access( $section ) ) {
			return; }
		if ( 'overview' === $section ) {
			$this->plugin->get( 'admin' )->dashboard();
			return; }
		if ( 'audit' === $section ) {
			$this->plugin->get( 'admin' )->audit();
			return; }
		if ( 0 === strpos( $section, 'pro-' ) ) {
			do_action( 'editharbor_admin_tab_content', $section );
			return; }
		if ( 'maintenance' === $section ) {
			$this->maintenance();
			return; }
		$copy = array(
			'general'  => array( __( 'Make every change traceable.', 'editharbor' ), __( 'Choose which order changes to record and how your history is displayed.', 'editharbor' ) ),
			'reasons'  => array( __( 'Give every edit a reason.', 'editharbor' ), __( 'Help your team remember why an order changed. Automated operations keep running normally.', 'editharbor' ) ),
			'warnings' => array( __( 'Add a pause before important edits.', 'editharbor' ), __( 'Friendly warnings help staff review changes to paid or finished orders.', 'editharbor' ) ),
			'privacy'  => array( __( 'Keep useful history. Protect personal data.', 'editharbor' ), __( 'Control what your audit history retains and what your team can see.', 'editharbor' ) ),
		);
		$tabs = $this->tabs();
		echo '<div class="editharbor-section-header"><span class="editharbor-eyebrow">' . esc_html( $tabs[ $section ]['label'] ) . '</span><h2>' . esc_html( $copy[ $section ][0] ) . '</h2><p>' . esc_html( $copy[ $section ][1] ) . '</p></div><form method="post" class="editharbor-settings-form" data-section="' . esc_attr( $section ) . '" data-action="editharbor_save_settings"><input type="hidden" name="revision" value="' . esc_attr( $this->revision( $section ) ) . '">';
		$s = $this->plugin->get( 'settings' )->all();
		foreach ( $this->sections()[ $section ] as $key ) {
			$this->field( $key, $s[ $key ] ); }
		if ( 'warnings' === $section ) {
			$this->callout( __( 'An order total is different from the amount collected.', 'editharbor' ), __( 'Editing a paid order will never automatically charge the difference or issue a refund. Always review payment and fulfillment separately.', 'editharbor' ) ); }
		if ( 'privacy' === $section ) {
			$this->callout( __( 'Privacy requests are handled by WordPress.', 'editharbor' ), __( 'Use Tools → Export Personal Data or Erase Personal Data to process customer requests. These settings affect audit history, not the actual order.', 'editharbor' ) ); }
		$this->save_bar();
		echo '</form>';
	}
	public function save_bar() {
		echo '<footer class="editharbor-save-bar"><div class="editharbor-save-status"><span class="editharbor-save-state" role="status" aria-live="polite">' . esc_html__( 'All changes saved', 'editharbor' ) . '</span><button type="button" class="button-link editharbor-reload-section" hidden>' . esc_html__( 'Reload saved settings', 'editharbor' ) . '</button></div><button type="submit" class="editharbor-save-button"><span class="dashicons dashicons-saved" aria-hidden="true"></span>' . esc_html__( 'Save changes', 'editharbor' ) . '</button></footer>'; }
	public function callout( $title, $text ) {
		echo '<div class="editharbor-callout"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><div><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $text ) . '</p></div></div>'; }
	public function field( $key, $value ) {
		$copy = array(
			'enabled'          => array( __( 'Order auditing', 'editharbor' ), __( 'Keep a clear history of meaningful changes to existing orders.', 'editharbor' ) ),
			'manual'           => array( __( 'Changes made by your team', 'editharbor' ), __( 'Record order edits made by administrators and shop managers.', 'editharbor' ) ),
			'automated'        => array( __( 'Changes from apps & automations', 'editharbor' ), __( 'Include API, scheduled task and integration changes when their source is known.', 'editharbor' ) ),
			'order_notes'      => array( __( 'Add a short order note', 'editharbor' ), __( 'Add one summary per change group. Personal before-and-after values stay in the audit history.', 'editharbor' ) ),
			'date_display'     => array( __( 'Time display', 'editharbor' ), __( 'Choose the timezone used to show audit timestamps.', 'editharbor' ) ),
			'per_page'         => array( __( 'History per page', 'editharbor' ), __( 'Show between 5 and 100 change groups on each page.', 'editharbor' ) ),
			'reason_mode'      => array( __( 'When should a reason be required?', 'editharbor' ), __( 'Ask staff for a reason only when they make a meaningful change.', 'editharbor' ) ),
			'reason_statuses'  => array( __( 'Orders that need a reason', 'editharbor' ), __( 'Select the order statuses where staff must explain an edit.', 'editharbor' ) ),
			'reason_min'       => array( __( 'Minimum reason length', 'editharbor' ), __( 'Keep reasons meaningful. Default: 3 characters.', 'editharbor' ) ),
			'reason_max'       => array( __( 'Maximum reason length', 'editharbor' ), __( 'Keep explanations concise. Default: 500 characters.', 'editharbor' ) ),
			'warn_paid'        => array( __( 'Warn before editing paid orders', 'editharbor' ), __( 'Remind staff that financial edits do not change the money already collected.', 'editharbor' ) ),
			'warning_statuses' => array( __( 'Protect important order statuses', 'editharbor' ), __( 'Show a warning before manual edits to these statuses. Staff can continue after reviewing it.', 'editharbor' ) ),
			'log_ip'           => array( __( 'Record IP addresses', 'editharbor' ), __( 'Disabled by default. Enable only if your store needs this extra audit detail.', 'editharbor' ) ),
			'mask_display'     => array( __( 'Mask personal details in history', 'editharbor' ), __( 'Hide names, addresses and parts of email addresses and phone numbers in audit displays.', 'editharbor' ) ),
			'retain_personal'  => array( __( 'Retain personal audit values', 'editharbor' ), __( 'Keep previous and current customer details for review. Turning this off redacts new personal audit values.', 'editharbor' ) ),
			'delete_data'      => array( __( 'Remove data when uninstalling', 'editharbor' ), __( 'Permanently delete this plugin’s history and settings when the plugin is deleted. Keep off to preserve your records.', 'editharbor' ) ),
		);
		$id   = 'editharbor-setting-' . $key;
		$name = 'editharbor_settings[' . $key . ']';
		echo '<div class="editharbor-field-row' . ( is_bool( $value ) ? ' editharbor-toggle-row' : '' ) . '" data-field="' . esc_attr( $key ) . '"><div class="editharbor-field-copy"><label id="' . esc_attr( $id ) . '-label" for="' . esc_attr( $id ) . '">' . esc_html( $copy[ $key ][0] ) . '</label><p id="' . esc_attr( $id ) . '-help">' . esc_html( $copy[ $key ][1] ) . '</p></div><div class="editharbor-field-control">';
		if ( is_bool( $value ) ) {
			echo '<label class="editharbor-switch"><input id="' . esc_attr( $id ) . '" type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . ' aria-describedby="' . esc_attr( $id ) . '-help"><span aria-hidden="true"></span></label>';
		} elseif ( is_array( $value ) ) {
			echo '<fieldset aria-labelledby="' . esc_attr( $id ) . '-label" aria-describedby="' . esc_attr( $id ) . '-help" class="editharbor-status-options"><legend class="screen-reader-text">' . esc_html( $copy[ $key ][0] ) . '</legend>';
			foreach ( wc_get_order_statuses() as $status => $label ) {
				$status = substr( $status, 3 );
				echo '<label class="editharbor-status-choice"><input type="checkbox" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $status ) . '" ' . checked( in_array( $status, $value, true ), true, false ) . '><span>' . esc_html( $label ) . '</span></label>';
			} echo '</fieldset>';
		} elseif ( in_array( $key, array( 'reason_mode', 'date_display' ), true ) ) {
			$options = 'reason_mode' === $key ? array(
				'disabled' => __( 'Optional for all edits', 'editharbor' ),
				'all'      => __( 'Required for all team edits', 'editharbor' ),
				'statuses' => __( 'Required for selected statuses', 'editharbor' ),
			) : array(
				'local' => __( 'Store timezone', 'editharbor' ),
				'utc'   => __( 'UTC', 'editharbor' ),
			);
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" aria-describedby="' . esc_attr( $id ) . '-help">';
			foreach ( $options as $option => $label ) {
					echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $label ) . '</option>';
			} echo '</select>';
		} else {
			$limits = array(
				'per_page'   => array( 5, 100 ),
				'reason_min' => array( 1, 100 ),
				'reason_max' => array( 1, 2000 ),
			);
			echo '<input id="' . esc_attr( $id ) . '" type="number" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" min="' . esc_attr( $limits[ $key ][0] ) . '" max="' . esc_attr( $limits[ $key ][1] ) . '" required aria-describedby="' . esc_attr( $id ) . '-help">';
		}
		echo '</div></div>';
	}
	private function maintenance() {
		Components::heading( __( 'System status', 'editharbor' ), __( 'Check the health of your audit tools.', 'editharbor' ), __( 'Review your store environment, check the audit database, and copy a support report without customer information.', 'editharbor' ) );
		$labels = array(
			'EditHarbor' => __( 'Free plugin version', 'editharbor' ),
			'Pro'              => __( 'Pro plugin version', 'editharbor' ),
			'WordPress'        => __( 'WordPress version', 'editharbor' ),
			'WooCommerce'      => __( 'WooCommerce version', 'editharbor' ),
			'PHP'              => __( 'Server PHP version', 'editharbor' ),
			'HPOS'             => __( 'Order storage', 'editharbor' ),
			'DB schema'        => __( 'Audit database version', 'editharbor' ),
			'Events'           => __( 'Saved change groups', 'editharbor' ),
			'Changes'          => __( 'Saved field changes', 'editharbor' ),
			'WP Cron disabled' => __( 'WordPress scheduled tasks', 'editharbor' ),
			'Last error'       => __( 'Last reported issue', 'editharbor' ),
		);
		echo '<div class="editharbor-system-grid">';
		foreach ( explode( "\n", $this->plugin->get( 'admin' )->diagnostics() ) as $line ) {
			$parts = explode( ': ', $line, 2 );
			$value = $parts[1] ?? '';
			if ( 'HPOS' === $parts[0] ) {
				$value = 'yes' === $value ? __( 'High-performance order storage (HPOS)', 'editharbor' ) : __( 'Legacy order storage', 'editharbor' ); }
			if ( 'WP Cron disabled' === $parts[0] ) {
				$value = 'yes' === $value ? __( 'Disabled in configuration', 'editharbor' ) : __( 'Enabled', 'editharbor' ); }
			if ( 'Last error' === $parts[0] ) {
				$error = json_decode( $value, true );
				$value = empty( $error['code'] ) ? __( 'No issue reported', 'editharbor' ) : ucwords( str_replace( '_', ' ', $error['code'] ) ); }
			if ( 'inactive' === $value ) {
				$value = __( 'Not active', 'editharbor' ); }
			echo '<div><span>' . esc_html( $labels[ $parts[0] ] ?? $parts[0] ) . '</span><strong>' . esc_html( $value ) . '</strong></div>';
		}
		echo '</div><p><button class="button editharbor-copy-diagnostics" type="button">' . esc_html__( 'Copy support report', 'editharbor' ) . '</button></p><textarea class="editharbor-diagnostics screen-reader-text" readonly>' . esc_textarea( $this->plugin->get( 'admin' )->diagnostics() ) . '</textarea><div class="editharbor-card editharbor-tool-card"><h3>' . esc_html__( 'Check your audit database', 'editharbor' ) . '</h3><p>' . esc_html__( 'Check and repair the plugin’s database structure. Order data stays in WooCommerce. Removing history for deleted orders is optional and permanent.', 'editharbor' ) . '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="editharbor-tool-form">';
		wp_nonce_field( 'editharbor_maintenance' );
		echo '<input type="hidden" name="action" value="editharbor_maintenance"><label class="editharbor-confirm"><input type="checkbox" name="confirm_cleanup" value="1"> ' . esc_html__( 'Also remove up to 100 history groups for deleted orders.', 'editharbor' ) . '</label><button type="submit" class="button">' . esc_html__( 'Check / repair database', 'editharbor' ) . '</button><span class="editharbor-save-state" role="status" aria-live="polite"></span></form></div>';
	}
}
