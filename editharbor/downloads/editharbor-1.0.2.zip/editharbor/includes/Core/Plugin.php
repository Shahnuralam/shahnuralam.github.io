<?php
/** Public service graph and deterministic bootstrap. @package EDHB */
namespace EDHB\Core;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static $instance;
	private $services = array();
	private $booted   = false;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function get( $key ) {
		return $this->services[ $key ] ?? null;
	}

	public function boot() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;
		$upgrade = \EDHB\Database\Legacy_Upgrade::run();
		if ( is_wp_error( $upgrade ) ) {
			add_action( 'admin_notices', static function () use ( $upgrade ) {
				if ( \EDHB\Support\Capabilities::notice_screen() ) {
					echo '<div class="notice notice-error"><p>' . esc_html( $upgrade->get_error_message() ) . '</p></div>';
				}
			} );
			return;
		}
		if ( EDHB_DB_VERSION !== get_option( 'editharbor_db_version' ) ) {
			\EDHB\Database\Installer::activate();
		}
		$s               = &$this->services;
		$s['settings']   = new Settings();
		$s['snapshot']   = new \EDHB\Services\Order_Snapshot();
		$s['diff']       = new \EDHB\Services\Order_Diff( $s['snapshot'] );
		$s['repository'] = new \EDHB\Database\Event_Repository();
		$s['context']    = new \EDHB\Services\Request_Context();
		$s['lock']       = new \EDHB\Support\Order_Lock();
		$s['reason']     = new \EDHB\Services\Change_Reason( $s['settings'], $s['context'] );
		$s['recorder']   = new \EDHB\Services\Audit_Recorder( $s['settings'], $s['snapshot'], $s['diff'], $s['repository'], $s['context'], $s['reason'], $s['lock'] );
		$s['preflight']  = new \EDHB\Services\Preflight( $s['recorder'], $s['snapshot'], $s['context'] );
		$s['recorder']->register();
		$s['preflight']->register();
		$s['privacy'] = new \EDHB\Privacy\Privacy( $s['repository'] );
		$s['privacy']->register();
		$s['workspace'] = new \EDHB\Admin\Workspace( $this );
		$s['workspace']->register();
		$s['admin'] = new \EDHB\Admin\Admin( $this );
		$s['admin']->register();
		add_action(
			'action_scheduler_before_execute',
			function () {
				$this->get( 'context' )->scheduler = true;
			}
		);
		add_action(
			'action_scheduler_after_execute',
			function () {
				$this->get( 'context' )->scheduler = false;
			}
		);
		do_action( 'editharbor_loaded', $this );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'editharbor_cleanup_orphans' );
	}
}
