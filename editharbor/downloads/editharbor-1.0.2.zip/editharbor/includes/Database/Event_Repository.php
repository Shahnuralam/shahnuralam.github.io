<?php
/** Bounded custom-table audit queries and atomic append. @package EDHB */
namespace EDHB\Database;

defined( 'ABSPATH' ) || exit;

// Plugin-owned audit tables/advisory locks require current database state; WordPress has no CRUD API for them.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

final class Event_Repository {
	public function table( $name ) {
		global $wpdb;
		if ( ! in_array( $name, array( 'events', 'changes', 'identities' ), true ) ) {
			throw new \InvalidArgumentException( 'Invalid audit table.' );
		}
		return $wpdb->prefix . 'editharbor_' . $name;
	}

	public static function identity_hash( $email ) {
		return hash_hmac( 'sha256', strtolower( trim( $email ) ), wp_salt( 'auth' ) );
	}

	public function append( array $event, array $changes, array $before, array $after ) {
		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		try {
			do_action( 'editharbor_before_record_event', $event, $changes );
			$row             = $event;
			$row['metadata'] = wp_json_encode( $row['metadata'] );
			if ( false === $wpdb->insert( $this->table( 'events' ), $row ) ) {
				throw new \RuntimeException( 'event_insert_failed' );
			}
			$id = (int) $wpdb->insert_id;
			foreach ( $changes as $change ) {
				do_action( 'editharbor_before_record_change', $change, $id );
				$change['event_id'] = $id;
				$change['order_id'] = $event['order_id'];
				foreach ( array( 'old_value', 'new_value', 'metadata' ) as $key ) {
					$change[ $key ] = wp_json_encode( $change[ $key ] );
				}
				$change['is_sensitive'] = (int) $change['is_sensitive'];
				if ( false === $wpdb->insert( $this->table( 'changes' ), $change ) ) {
					throw new \RuntimeException( 'change_insert_failed' );
				}
				do_action( 'editharbor_after_record_change', (int) $wpdb->insert_id, $id );
			}
			$user   = wp_get_current_user();
			$emails = array( $before['fields']['billing_email'] ?? '', $after['fields']['billing_email'] ?? '', $user->user_email );
			foreach ( array_unique( array_filter( $emails, 'is_email' ) ) as $email ) {
				if ( false === $wpdb->insert(
					$this->table( 'identities' ),
					array(
						'event_id'   => $id,
						'email_hash' => self::identity_hash( $email ),
					)
				) ) {
					throw new \RuntimeException( 'identity_insert_failed' );
				}
			}
			do_action( 'editharbor_event_persisting', $id, $event, $changes, $before, $after );
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new \RuntimeException( 'event_commit_failed' );
			}
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' );
			\EDHB\Support\Logger::error( 'audit_persistence_failed' );
			return new \WP_Error( 'editharbor_audit_failed', __( 'The audit record could not be saved. Check EditHarbor diagnostics.', 'editharbor' ) );
		}
		delete_transient( 'editharbor_stats' );
		do_action( 'editharbor_after_record_event', $id, $event, $changes );
		return $id;
	}

	public function event( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $this->table( 'events' ), absint( $id ) ), ARRAY_A );
		if ( $row ) {
			$row['metadata'] = json_decode( $row['metadata'], true ) ?: array();
			$row['changes']  = $this->changes( $id );
		}
		return $row;
	}

	public function changes( $id ) {
		global $wpdb;
		$rows = array();
		$cursor = 0;
		do {
			$batch = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE event_id = %d AND id > %d ORDER BY id ASC LIMIT 500', $this->table( 'changes' ), absint( $id ), $cursor ), ARRAY_A );
			foreach ( $batch as $change ) { $rows[] = $change; $cursor = (int) $change['id']; }
		} while ( count( $batch ) === 500 );
		foreach ( $rows as &$row ) {
			foreach ( array( 'old_value', 'new_value', 'metadata' ) as $key ) {
				$row[ $key ] = json_decode( $row[ $key ], true );
			}
		}
		return $rows;
	}

	public function where( array $filters ) {
		global $wpdb;
		$filters = array_filter( $filters, 'is_scalar' );
		$parts = array( '1=1' );
		foreach ( array( 'order_id', 'user_id' ) as $key ) {
			if ( ! empty( $filters[ $key ] ) ) {
				$parts[] = $wpdb->prepare( 'e.%i = %d', $key, absint( $filters[ $key ] ) );
			}
		}
		if ( isset( $filters['was_paid'] ) ) {
			$parts[] = $wpdb->prepare( 'e.was_paid = %d', (int) (bool) $filters['was_paid'] );
		}
		foreach ( array( 'source', 'actor_role', 'event_type', 'order_status_after' ) as $key ) {
			if ( ! empty( $filters[ $key ] ) ) {
				$parts[] = $wpdb->prepare( 'e.%i = %s', $key, sanitize_key( $filters[ $key ] ) );
			}
		}
		foreach ( array( 'from', 'to' ) as $key ) {
			if ( ! empty( $filters[ $key ] ) && preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/', $filters[ $key ] ) ) {
				$date    = strlen( $filters[ $key ] ) > 10 ? $filters[ $key ] : $filters[ $key ] . ( 'from' === $key ? ' 00:00:00' : ' 23:59:59' );
				if ( 'from' === $key ) {
					$parts[] = $wpdb->prepare( 'e.created_at_gmt >= %s', $date );
				} else {
					$parts[] = $wpdb->prepare( 'e.created_at_gmt <= %s', $date );
				}
			}
		}
		if ( ! empty( $filters['category'] ) ) {
			$parts[] = $wpdb->prepare( 'EXISTS (SELECT 1 FROM %i c WHERE c.event_id = e.id AND c.category = %s)', $this->table( 'changes' ), sanitize_key( $filters['category'] ) );
		}
		if ( ! empty( $filters['search'] ) && strlen( $filters['search'] ) >= 3 ) {
			$term    = '%' . $wpdb->esc_like( substr( sanitize_text_field( $filters['search'] ), 0, 100 ) ) . '%';
			$parts[] = $wpdb->prepare( '(e.actor_name LIKE %s OR e.reason LIKE %s)', $term, $term );
		}
		if ( isset( $filters['after_id'] ) ) {
			$parts[] = $wpdb->prepare( 'e.id > %d', absint( $filters['after_id'] ) );
		}
		if ( isset( $filters['max_id'] ) ) {
			$parts[] = $wpdb->prepare( 'e.id <= %d', absint( $filters['max_id'] ) );
		}
		return implode( ' AND ', $parts );
	}

	public function query( array $filters = array(), $page = 1, $limit = 20, $ascending = false ) {
		global $wpdb;
		$limit     = min( 100, max( 1, absint( $limit ) ) );
		$offset    = min( 1000000, max( 0, absint( $page ) - 1 ) * $limit );
		$where     = $this->where( $filters );
		$direction = $ascending ? 'ASC' : 'DESC';
		// where() prepares every value; direction is selected only from ASC and DESC.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Only prepared clauses and a fixed sort direction are interpolated.
		return $wpdb->get_results( $wpdb->prepare( "SELECT e.* FROM %i e WHERE $where ORDER BY e.id $direction LIMIT %d OFFSET %d", $this->table( 'events' ), $limit, $offset ), ARRAY_A );
	}

	public function count( array $filters = array() ) {
		global $wpdb;
		$where = $this->where( $filters );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- where() returns prepared clauses only.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i e WHERE $where", $this->table( 'events' ) ) );
	}

	public function summary( array $filters = array() ) {
		global $wpdb;
		$where = $this->where( $filters );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- where() returns prepared clauses only.
		return $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) events, COUNT(DISTINCT order_id) orders, COUNT(DISTINCT NULLIF(user_id,0)) users FROM %i e WHERE $where", $this->table( 'events' ) ), ARRAY_A );
	}

	public function identity_events( $email, $page = 1 ) {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare( 'SELECT event_id FROM %i WHERE email_hash = %s ORDER BY event_id ASC LIMIT 100 OFFSET %d', $this->table( 'identities' ), self::identity_hash( $email ), max( 0, absint( $page ) - 1 ) * 100 ) );
	}

	public function anonymize( $id ) {
		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		try {
			do_action( 'editharbor_before_privacy_anonymize', $id );
			$ok = $wpdb->update(
				$this->table( 'events' ),
				array(
					'actor_name' => '',
					'user_id'    => 0,
					'reason'     => '',
					'ip_address' => '',
					'actor_role' => '',
					'metadata'   => wp_json_encode(
						array(
							'payload_version' => 1,
							'anonymized'      => true,
						)
					),
				),
				array( 'id' => $id )
			);
			$ok = false !== $ok && false !== $wpdb->query( $wpdb->prepare( 'UPDATE %i SET old_value = %s, new_value = %s, metadata = %s WHERE event_id = %d AND is_sensitive = 1', $this->table( 'changes' ), wp_json_encode( '[erased]' ), wp_json_encode( '[erased]' ), '{}', $id ) );
			$ok = $ok && false !== $wpdb->delete( $this->table( 'identities' ), array( 'event_id' => $id ) );
			if ( ! $ok ) {
				throw new \RuntimeException( 'privacy_write_failed' );
			}
			do_action( 'editharbor_after_privacy_anonymize', $id );
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new \RuntimeException( 'privacy_commit_failed' );
			}
			return true;
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' );
			return false;
		}
	}
}
