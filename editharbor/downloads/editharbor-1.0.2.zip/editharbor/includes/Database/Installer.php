<?php
/** Site-scoped, repeatable schema installation. @package EDHB */
namespace EDHB\Database;

defined( 'ABSPATH' ) || exit;

final class Installer {
	public static function activate() {
		if ( defined( 'OEG_VERSION' ) ) {
			wp_die( esc_html__( 'Deactivate the old Order Edit Guard plugin before activating EditHarbor.', 'editharbor' ) );
		}
		$upgrade = Legacy_Upgrade::run();
		if ( is_wp_error( $upgrade ) ) {
			wp_die( esc_html( $upgrade->get_error_message() ) );
		}
		self::install();
		add_option( 'editharbor_settings', ( new \EDHB\Core\Settings() )->defaults(), '', false );
		\EDHB\Support\Capabilities::install();
		add_option( 'editharbor_welcome', 1, '', false );
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset    = $wpdb->get_charset_collate();
		$events     = $wpdb->prefix . 'editharbor_events';
		$changes    = $wpdb->prefix . 'editharbor_changes';
		$identities = $wpdb->prefix . 'editharbor_identities';
		dbDelta(
			"CREATE TABLE $events (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			order_id bigint(20) unsigned NOT NULL,
			change_group varchar(64) NOT NULL,
			created_at_gmt datetime NOT NULL,
			actor_type varchar(32) NOT NULL,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			actor_name varchar(191) NOT NULL DEFAULT '',
			actor_role varchar(64) NOT NULL DEFAULT '',
			source varchar(64) NOT NULL,
			event_type varchar(64) NOT NULL DEFAULT 'order_updated',
			was_paid tinyint(1) NOT NULL DEFAULT 0,
			reason text NOT NULL,
			request_id varchar(64) NOT NULL,
			ip_address varchar(45) NOT NULL DEFAULT '',
			order_status_before varchar(64) NOT NULL DEFAULT '',
			order_status_after varchar(64) NOT NULL DEFAULT '',
			metadata longtext NOT NULL,
			plugin_version varchar(20) NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY change_group (change_group),
			KEY order_date (order_id,created_at_gmt),
			KEY created_at_gmt (created_at_gmt),
			KEY actor_date (user_id,created_at_gmt),
			KEY source (source),
			KEY event_type (event_type),
			KEY actor_role (actor_role)
		) ENGINE=InnoDB $charset;"
		);
		dbDelta(
			"CREATE TABLE $changes (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			event_id bigint(20) unsigned NOT NULL,
			order_id bigint(20) unsigned NOT NULL,
			category varchar(32) NOT NULL,
			object_type varchar(32) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			field_key varchar(191) NOT NULL,
			field_label varchar(191) NOT NULL,
			old_value longtext NOT NULL,
			new_value longtext NOT NULL,
			value_type varchar(32) NOT NULL,
			is_sensitive tinyint(1) NOT NULL DEFAULT 0,
			metadata longtext NOT NULL,
			PRIMARY KEY  (id),
			KEY event_id (event_id),
			KEY order_id (order_id),
			KEY category (category),
			KEY field_key (field_key)
		) ENGINE=InnoDB $charset;"
		);
		dbDelta(
			"CREATE TABLE $identities (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			event_id bigint(20) unsigned NOT NULL,
			email_hash char(64) NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY identity (email_hash,event_id),
			KEY event_id (event_id)
		) ENGINE=InnoDB $charset;"
		);
		$healthy = true;
		foreach ( array( $events, $changes, $identities ) as $table ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Verify newly installed custom tables without stale caching.
			$healthy = $healthy && $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
		}
		if ( $healthy ) {
			update_option( 'editharbor_db_version', EDHB_DB_VERSION, false );
			delete_option( 'editharbor_db_error' );
		} else {
			update_option( 'editharbor_db_error', 1, false );
		}
	}
}
