<?php
/** Preserve pre-EditHarbor records while adopting the distinctive storage prefix. @package EDHB */
namespace EDHB\Database;

defined( 'ABSPATH' ) || exit;

// Custom table migration and advisory serialization must read current database state.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
final class Legacy_Upgrade {
	const CAPABILITIES = array( 'view_order_audit', 'view_all_audits', 'manage_settings', 'export_audits', 'lock_orders', 'unlock_orders', 'approve_changes', 'restore_values', 'manage_rules', 'manage_notifications' );

	public static function run() {
		if ( get_option( 'editharbor_legacy_upgraded' ) ) {
			return true;
		}
		global $wpdb;
		$lock = 'editharbor_upgrade_' . md5( $wpdb->prefix );
		if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock ) ) ) {
			return new \WP_Error( 'editharbor_upgrade_busy', __( 'The EditHarbor upgrade is busy. Please try again.', 'editharbor' ) );
		}
		try {
			wp_cache_delete( 'alloptions', 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			wp_cache_delete( 'editharbor_legacy_upgraded', 'options' );
			if ( get_option( 'editharbor_legacy_upgraded' ) ) {
				return true;
			}
			$missing = new \stdClass();
			$options = array();
			foreach ( array( 'settings', 'db_version', 'db_error', 'last_error', 'identity_secret', 'welcome', 'orphan_cursor', 'pro_settings', 'pro_db_version', 'pro_integrity_secret' ) as $suffix ) {
				$legacy = get_option( 'oeg_' . $suffix, $missing );
				if ( $legacy === $missing ) {
					continue;
				}
				if ( 'pro_settings' === $suffix && is_array( $legacy ) && ! empty( $legacy['rules'] ) ) {
					foreach ( $legacy['rules'] as &$rule ) {
						if ( is_array( $rule ) && isset( $rule['capabilities'] ) && is_array( $rule['capabilities'] ) ) {
							foreach ( $rule['capabilities'] as &$cap ) {
								if ( is_string( $cap ) && 0 === strpos( $cap, 'oeg_' ) && in_array( substr( $cap, 4 ), self::CAPABILITIES, true ) ) {
									$cap = 'editharbor_' . substr( $cap, 4 );
								}
							}
							unset( $cap );
						}
					}
					unset( $rule );
				}
				$current = get_option( 'editharbor_' . $suffix, $missing );
				if ( $current !== $missing && $current !== $legacy ) {
					throw new \RuntimeException( 'option_conflict' );
				}
				$options[ 'editharbor_' . $suffix ] = $legacy;
			}
			$renames = array();
			foreach ( array( 'events', 'changes', 'identities', 'pro_snapshots', 'pro_locks', 'pro_approvals', 'pro_deliveries', 'pro_integrity', 'pro_integrity_state' ) as $suffix ) {
				$old = $wpdb->prefix . 'oeg_' . $suffix;
				$new = $wpdb->prefix . 'editharbor_' . $suffix;
				if ( $old !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $old ) ) ) ) {
					continue;
				}
				if ( $new === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $new ) ) ) ) {
					throw new \RuntimeException( 'table_conflict' );
				}
				$renames[] = $wpdb->prepare( '%i TO %i', $old, $new );
			}
			if ( $renames ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Atomic migration uses only allowlisted, prepared table identifiers.
				if ( false === $wpdb->query( 'RENAME TABLE ' . implode( ', ', $renames ) ) ) {
					throw new \RuntimeException( 'table_rename_failed' );
				}
			}
			foreach ( $options as $key => $value ) {
				add_option( $key, $value, '', false );
				if ( get_option( $key, $missing ) !== $value ) {
					throw new \RuntimeException( 'option_copy_failed' );
				}
			}
			foreach ( wp_roles()->role_objects as $role ) {
				self::copy_caps( $role, $role->capabilities );
			}
			$offset = 0;
			do {
				$users = get_users( array( 'blog_id' => get_current_blog_id(), 'fields' => 'ids', 'number' => 100, 'offset' => $offset ) );
				foreach ( $users as $id ) {
					$user = new \WP_User( $id );
					self::copy_caps( $user, $user->caps );
				}
				$offset += 100;
			} while ( count( $users ) === 100 );
			update_option( 'editharbor_legacy_upgraded', 1, false );
			if ( ! get_option( 'editharbor_legacy_upgraded' ) ) {
				throw new \RuntimeException( 'marker_write_failed' );
			}
			delete_option( 'editharbor_upgrade_error' );
			return true;
		} catch ( \Throwable $exception ) {
			update_option( 'editharbor_upgrade_error', sanitize_key( $exception->getMessage() ), false );
			return new \WP_Error( 'editharbor_upgrade_failed', __( 'EditHarbor could not finish the data upgrade. Existing history is preserved. Review conflicting data or database permissions before retrying.', 'editharbor' ) );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	private static function copy_caps( $subject, array $caps ) {
		foreach ( self::CAPABILITIES as $suffix ) {
			$legacy = 'oeg_' . $suffix;
			$current = 'editharbor_' . $suffix;
			if ( array_key_exists( $legacy, $caps ) && ! array_key_exists( $current, $caps ) ) {
				$subject->add_cap( $current, (bool) $caps[ $legacy ] );
			}
		}
	}
}
