<?php
/** WordPress personal data tools with historical identity matching. @package EDHB */
namespace EDHB\Privacy;

defined( 'ABSPATH' ) || exit;

final class Privacy {
	private $repository;

	public function __construct( $repository ) {
		$this->repository = $repository;
	}

	public function register() {
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'exporters' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'erasers' ) );
		add_action( 'admin_init', array( $this, 'policy' ) );
	}

	public function exporters( $exporters ) {
		$exporters['editharbor'] = array(
			'exporter_friendly_name' => __( 'EditHarbor audit history', 'editharbor' ),
			'callback'               => array( $this, 'export' ),
		);
		return $exporters;
	}

	public function erasers( $erasers ) {
		$erasers['editharbor'] = array(
			'eraser_friendly_name' => __( 'EditHarbor audit history', 'editharbor' ),
			'callback'             => array( $this, 'erase' ),
		);
		return $erasers;
	}

	public function export( $email, $page = 1 ) {
		$ids  = $this->repository->identity_events( $email, $page );
		$data = array();
		foreach ( $ids as $id ) {
			$event = $this->repository->event( $id );
			if ( ! $event ) {
				continue;
			}
			$fields = array();
			foreach ( array( 'order_id', 'created_at_gmt', 'actor_name', 'reason', 'source', 'ip_address' ) as $key ) {
				$fields[] = array(
					'name'  => $key,
					'value' => $event[ $key ],
				);
			}
			foreach ( $event['changes'] as $change ) {
				$fields[] = array(
					'name'  => $change['field_key'],
					'value' => wp_json_encode(
						array(
							'previous' => $change['old_value'],
							'current'  => $change['new_value'],
						)
					),
				);
			}
			$fields = apply_filters( 'editharbor_privacy_export_event', $fields, $event );
			$data[] = array(
				'group_id'    => 'editharbor',
				'group_label' => __( 'Order edit history', 'editharbor' ),
				'item_id'     => 'editharbor-' . $id,
				'data'        => $fields,
			);
		}
		return array(
			'data' => $data,
			'done' => count( $ids ) < 100,
		);
	}

	public function erase( $email, $page = 1 ) {
		// Process the first remaining page: successful anonymization removes lookup rows.
		$ids      = $this->repository->identity_events( $email, 1 );
		$removed  = false;
		$retained = false;
		foreach ( $ids as $id ) {
			if ( $this->repository->anonymize( absint( $id ) ) ) {
				$removed = true;
			} else {
				$retained = true;
			}
		}
		return array(
			'items_removed'  => $removed,
			'items_retained' => $retained,
			'messages'       => $retained ? array( __( 'Some audit data could not be anonymized. Check database diagnostics and retry.', 'editharbor' ) ) : array(),
			'done'           => count( $ids ) < 100 || $retained,
		);
	}

	public function policy() {
		if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
			wp_add_privacy_policy_content( 'EditHarbor', '<p>' . esc_html__( 'We keep an audit trail of changes to existing orders, including staff identity, time, source, change reasons and previous/current order details. IP collection is disabled by default. Audit history is retained unless a configured retention or privacy workflow removes or anonymizes it. Authorized staff can view the history. Contact the store to request access to or erasure of personal audit data. Store operators must select a retention period appropriate for their obligations.', 'editharbor' ) . '</p>' );
		}
	}
}
