<?php
/** Hook capture, policy boundary and request grouping. @package EDHB */
namespace EDHB\Services;

defined( 'ABSPATH' ) || exit;

final class Audit_Recorder {
	private $settings;
	private $snapshot;
	private $diff;
	private $repository;
	private $context;
	private $reason;
	private $lock;
	private $before    = array();
	private $after     = array();
	private $created   = array();
	private $deleting  = array();
	private $recording = false;

	public function __construct( $settings, $snapshot, $diff, $repository, $context, $reason, $lock ) {
		$this->settings   = $settings;
		$this->snapshot   = $snapshot;
		$this->diff       = $diff;
		$this->repository = $repository;
		$this->context    = $context;
		$this->reason     = $reason;
		$this->lock       = $lock;
	}

	public function register() {
		add_action( 'woocommerce_before_order_object_save', array( $this, 'before_order' ), PHP_INT_MAX );
		add_action( 'woocommerce_after_order_object_save', array( $this, 'after_order' ), PHP_INT_MAX );
		add_action( 'woocommerce_before_order_item_object_save', array( $this, 'before_item' ), PHP_INT_MAX );
		add_action( 'woocommerce_after_order_item_object_save', array( $this, 'after_item' ), PHP_INT_MAX );
		add_action( 'woocommerce_before_delete_order_item', array( $this, 'before_delete' ), 0 );
		add_action( 'woocommerce_delete_order_item', array( $this, 'after_delete' ), PHP_INT_MAX );
		add_action(
			'woocommerce_new_order',
			function ( $id ) {
				$this->created[ $id ] = true;
			}
		);
		add_action( 'shutdown', array( $this, 'flush' ), 5 );
	}

	public function capture( $id ) {
		if ( $this->recording || isset( $this->created[ $id ] ) || ! $id ) {
			return null;
		}
		if ( ! $this->lock->acquire( $id ) ) {
			\EDHB\Support\Logger::error( 'order_lock_unavailable' );
			return new \WP_Error( 'editharbor_busy', __( 'Another request is editing this order. Please retry.', 'editharbor' ), array( 'status' => 409 ) );
		}
		try {
			$current = $this->snapshot->fresh( $id );
			if ( $current && ! isset( $this->before[ $id ] ) ) {
				$this->before[ $id ] = $current;
			}
			return $current;
		} catch ( \Throwable $exception ) {
			\EDHB\Support\Logger::error( 'snapshot_failed' );
			return new \WP_Error( 'editharbor_snapshot_failed', __( 'The order safety check could not read this order.', 'editharbor' ), array( 'status' => 503 ) );
		}
	}

	public function guard( $id, array $proposed ) {
		if ( isset( $this->context->denied[ $id ] ) ) {
			return $this->context->denied[ $id ];
		}
		$before = $this->capture( $id );
		if ( is_wp_error( $before ) ) {
			return $before;
		}
		if ( ! $before ) {
			return true;
		}
		$changes = $this->diff->compare( $before, $proposed, false );
		if ( ! empty( $proposed['structural'] ) ) {
			$action    = $proposed['structural'];
			$category  = false !== strpos( $action, 'coupon' ) ? 'coupon' : ( false !== strpos( $action, 'tax' ) ? 'tax' : ( false !== strpos( $action, 'shipping' ) ? 'shipping' : ( false !== strpos( $action, 'fee' ) ? 'fee' : 'items' ) ) );
			$changes[] = array(
				'category'  => $category,
				'field_key' => 'structural_operation',
				'object_id' => 0,
			);
		}
		$result = $this->reason->validate( $id, $before, $changes );
		if ( ! is_wp_error( $result ) ) {
			$result = apply_filters( 'editharbor_preflight_order_edit', true, $id, $before, $proposed, $changes );
		}
		if ( is_wp_error( $result ) ) {
			$this->context->denied[ $id ] = $result;
		}
		return $result;
	}

	private function enforce( $id, $proposed ) {
		$result = $this->guard( $id, $proposed );
		if ( is_wp_error( $result ) ) {
			$actor = $this->context->actor();
			if ( 'editharbor_busy' !== $result->get_error_code() && 'editharbor_snapshot_failed' !== $result->get_error_code() || $actor['manual'] || ( current_user_can( 'edit_shop_order', $id ) && ! wp_doing_cron() && ! $this->context->scheduler ) || apply_filters( 'editharbor_fail_closed_capture', false, $id ) ) {
				throw new \WC_Data_Exception( esc_html( $result->get_error_code() ), esc_html( $result->get_error_message() ), 409 );
			}
		}
	}

	public function before_order( $order ) {
		if ( $this->recording || ! $order->get_id() || 'shop_order' !== $order->get_type() || isset( $this->created[ $order->get_id() ] ) ) {
			return;
		}
		$this->enforce( $order->get_id(), $this->snapshot->take( $order ) );
	}

	public function after_order( $order ) {
		$this->remember_after( $order->get_id() );
	}

	public function before_item( $item ) {
		$id = $item->get_order_id();
		if ( ! $id || isset( $this->created[ $id ] ) || $this->recording ) {
			return;
		}
		$before = $this->capture( $id );
		if ( is_wp_error( $before ) ) {
			$this->enforce( $id, array() );
			return;
		}
		if ( $before ) {
			$key                     = $item->get_id() ? (string) $item->get_id() : 'new:' . spl_object_hash( $item );
			$before['items'][ $key ] = $this->snapshot->item( $item );
			$this->enforce( $id, $before );
		}
	}

	public function after_item( $item ) {
		$this->remember_after( $item->get_order_id() );
	}

	public function before_delete( $item_id ) {
		$item = \WC_Order_Factory::get_order_item( $item_id );
		if ( ! $item || $this->recording ) {
			return;
		}
		$id = $item->get_order_id();
		if ( isset( $this->created[ $id ] ) ) {
			return;
		}
		$before = $this->capture( $id );
		if ( is_wp_error( $before ) ) {
			$this->enforce( $id, array() );
			return;
		}
		if ( $before ) {
			$this->deleting[ $item_id ] = $id;
			unset( $before['items'][ $item_id ] );
			$this->enforce( $id, $before );
		}
	}

	public function after_delete( $item_id ) {
		if ( isset( $this->deleting[ $item_id ] ) ) {
			$this->remember_after( $this->deleting[ $item_id ] );
			unset( $this->after[ $this->deleting[ $item_id ] ]['items'][ $item_id ] );
			unset( $this->deleting[ $item_id ] );
		}
	}

	private function remember_after( $id ) {
		if ( ! $this->recording && isset( $this->before[ $id ] ) ) {
			try {
				$this->after[ $id ] = $this->snapshot->fresh( $id );
			} catch ( \Throwable $exception ) {
				\EDHB\Support\Logger::error( 'after_snapshot_failed' );
			}
		}
	}

	public function flush() {
		if ( $this->recording ) {
			return;
		}
		$this->recording = true;
		try {
			foreach ( $this->before as $id => $before ) {
				$result    = 0;
				$after     = $this->after[ $id ] ?? null;
				$actor     = $this->context->actor();
				$audit     = $this->settings->get( 'enabled' ) && $this->settings->get( $actor['manual'] ? 'manual' : 'automated' );
				$committed = $after && $this->diff->compare( $before, $after, false );
				$changes   = $after && $audit && apply_filters( 'editharbor_should_audit_order', true, $id, $actor ) ? $this->diff->compare( $before, $after ) : array();
				if ( $changes ) {
					$event = $this->event_data( $id, $before, $after, 'order_updated', $this->context->group( $id ) );
					$this->minimize_personal( $event, $changes, $before, $after );
					$result = $this->repository->append( $event, $changes, $before, $after );
					if ( is_wp_error( $result ) ) {
						if ( $committed ) {
							do_action( 'editharbor_order_edit_committed', $id, 0 ); }
						unset( $this->before[ $id ], $this->after[ $id ] );
						$this->context->clear( $id );
						$this->lock->release( $id );
						continue;
					}
					if ( $this->settings->get( 'order_notes' ) ) {
						$order = wc_get_order( $id );
						if ( $order ) {
							/* translators: 1: actor, 2: number of changes, 3: reason. */
							$order->add_order_note( sprintf( __( 'EditHarbor: %1$s changed %2$d fields. Reason: %3$s', 'editharbor' ), $event['actor_name'], count( $changes ), $event['reason'] ) );
						}
					}
					do_action( 'editharbor_reason_saved', $id, $event['reason'], $result );
				}
				if ( $committed ) {
					do_action( 'editharbor_order_edit_committed', $id, $result ?? 0 ); }
				unset( $this->before[ $id ], $this->after[ $id ] );
				$this->context->clear( $id );
				$this->lock->release( $id );
			}
		} catch ( \Throwable $exception ) {
			\EDHB\Support\Logger::error( 'audit_flush_failed' );
		} finally {
			$this->recording = false;
			$this->lock->release_all();
		}
	}

	public function record_system( $id, $type, $reason, array $metadata = array() ) {
		$state             = $this->snapshot->fresh( $id ) ?: array(
			'fields'   => array(),
			'items'    => array(),
			'currency' => '',
		);
		$event             = $this->event_data( $id, $state, $state, $type, wp_generate_uuid4() );
		$event['reason']   = sanitize_textarea_field( $reason );
		$event['metadata'] = array_merge( $event['metadata'], $metadata );
		$changes           = array();
		$this->minimize_personal( $event, $changes, $state, $state );
		return $this->repository->append( $event, $changes, $state, $state );
	}

	private function event_data( $id, $before, $after, $type, $group ) {
		$actor = $this->context->actor();
		$ip    = $this->settings->get( 'log_ip' ) && isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return array(
			'order_id'            => $id,
			'change_group'        => $group,
			'created_at_gmt'      => current_time( 'mysql', true ),
			'actor_type'          => sanitize_key( $actor['actor_type'] ),
			'user_id'             => absint( $actor['user_id'] ),
			'actor_name'          => sanitize_text_field( $actor['actor_name'] ),
			'actor_role'          => sanitize_key( $actor['actor_role'] ),
			'source'              => sanitize_key( $actor['source'] ),
			'event_type'          => $type,
			'reason'              => $this->context->reason( $id ),
			'was_paid'            => (int) ! empty( $before['is_paid'] ),
			'request_id'          => $this->context->request_id,
			'ip_address'          => filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '',
			'order_status_before' => $before['fields']['status'] ?? '',
			'order_status_after'  => $after['fields']['status'] ?? '',
			'metadata'            => array_merge(
				array(
					'payload_version' => 1,
					'currency'        => $after['currency'],
					'was_paid'        => ! empty( $before['is_paid'] ),
				),
				$this->context->operation[ $id ] ?? array()
			),
			'plugin_version'      => EDHB_VERSION,
		);
	}

	private function minimize_personal( &$event, &$changes, &$before, &$after ) {
		if ( $this->settings->get( 'retain_personal' ) ) {
			return;
		}
		$event['actor_name'] = '';
		$event['reason']     = '';
		$event['ip_address'] = '';
		foreach ( $changes as &$change ) {
			if ( $change['is_sensitive'] ) {
				$change['old_value'] = '[redacted]';
				$change['new_value'] = '[redacted]';
				$change['metadata']  = array();
			}
		}
		unset( $change );
		foreach ( array( 'before', 'after' ) as $name ) {
			$state = &$$name;
			foreach ( $state['fields'] as $key => &$value ) {
				if ( preg_match( '/^(billing_|shipping_|meta:|customer_note|customer_id)/', $key ) ) {
					$value = '[redacted]';
				}
			}
			unset( $value );
			$state['customer_name'] = '';
			unset( $state );
		}
	}
}
