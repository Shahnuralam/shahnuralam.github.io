<?php
/** Authoritative reason validation, independent from capture failures. @package EDHB */
namespace EDHB\Services;

defined( 'ABSPATH' ) || exit;

final class Change_Reason {
	private $settings;
	private $context;

	public function __construct( $settings, $context ) {
		$this->settings = $settings;
		$this->context  = $context;
	}

	/** Whether this manual edit needs an explanation under the current settings. */
	public function required( array $before ) {
		$actor    = $this->context->actor();
		$mode     = $this->settings->get( 'reason_mode' );
		$statuses = apply_filters( 'editharbor_required_reason_statuses', $this->settings->get( 'reason_statuses' ) );
		return $actor['manual'] && ( 'all' === $mode || ( 'statuses' === $mode && in_array( $before['fields']['status'] ?? '', $statuses, true ) ) );
	}

	public function validate( $order_id, $before, $changes, $force = false ) {
		if ( ! $changes ) {
			return true;
		}
		$required = $force || $this->required( $before );
		$reason = $this->context->reason( $order_id );
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $reason ) : strlen( $reason );
		if ( ( $required && $length < $this->settings->get( 'reason_min' ) ) || $length > $this->settings->get( 'reason_max' ) ) {
			return new \WP_Error( 'editharbor_reason_required', __( 'Please provide a reason within the configured length before saving this order.', 'editharbor' ), array( 'status' => 409 ) );
		}
		return true;
	}
}
