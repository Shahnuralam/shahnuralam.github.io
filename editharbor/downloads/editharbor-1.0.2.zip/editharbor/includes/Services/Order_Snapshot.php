<?php
/** Normalized, explicit WooCommerce CRUD snapshots. @package EDHB */
namespace EDHB\Services;

defined( 'ABSPATH' ) || exit;

final class Order_Snapshot {
	const FIELDS  = array(
		'status'               => 'status',
		'customer_id'          => 'customer',
		'currency'             => 'pricing',
		'discount_total'       => 'pricing',
		'discount_tax'         => 'tax',
		'shipping_total'       => 'shipping',
		'shipping_tax'         => 'tax',
		'cart_tax'             => 'tax',
		'total'                => 'pricing',
		'payment_method'       => 'payment',
		'payment_method_title' => 'payment',
		'customer_note'        => 'note',
	);
	const ADDRESS = array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country', 'email', 'phone' );
	const MONEY   = array( 'discount_total', 'discount_tax', 'shipping_total', 'shipping_tax', 'cart_tax', 'total', 'subtotal', 'total_tax', 'subtotal_tax', 'amount', 'discount', 'tax_total', 'shipping_tax_total' );

	public static function safe_meta_key( $key ) {
		return is_string( $key ) && strlen( $key ) <= 191 && preg_match( '/^[a-zA-Z0-9_\-]+$/', $key ) && ! preg_match( '/token|secret|password|credential|transaction|credit.?card|card.?number|security.?code|api.?key|private.?key|^_?editharbor/i', $key );
	}

	public function meta_keys() {
		$keys    = apply_filters( 'editharbor_audited_meta_keys', array() );
		$ignored = (array) apply_filters( 'editharbor_ignored_meta_keys', array() );
		$out     = array();
		foreach ( (array) $keys as $key => $config ) {
			if ( is_int( $key ) ) {
				$key    = $config;
				$config = array();
			}
			if ( self::safe_meta_key( $key ) && ! in_array( $key, $ignored, true ) ) {
				$out[ $key ] = wp_parse_args(
					is_array( $config ) ? $config : array(),
					array(
						'label'     => $key,
						'category'  => 'metadata',
						'sensitive' => true,
					)
				);
			}
		}
		return $out;
	}

	public static function normalize( $value, $numeric = false ) {
		if ( is_array( $value ) ) {
			ksort( $value );
			foreach ( $value as $key => $part ) {
				$value[ $key ] = self::normalize( $part, $numeric );
			}
			return $value;
		}
		if ( $numeric && is_numeric( $value ) ) {
			$value = wc_format_decimal( $value, 6 );
			return '0' === trim( $value, '0.' ) || '' === trim( $value, '0.' ) ? '0' : rtrim( rtrim( $value, '0' ), '.' );
		}
		if ( is_object( $value ) || is_resource( $value ) ) {
			return null;
		}
		return is_string( $value ) ? trim( str_replace( array( "\r\n", "\r" ), "\n", $value ) ) : $value;
	}

	public function item( $item ) {
		$fields = array( 'name', 'product_id', 'variation_id', 'quantity', 'subtotal', 'subtotal_tax', 'total', 'total_tax', 'taxes', 'tax_class', 'amount', 'method_id', 'method_title', 'instance_id', 'code', 'discount', 'discount_tax', 'rate_id', 'label', 'compound', 'tax_total', 'shipping_tax_total' );
		$data   = array();
		foreach ( $fields as $field ) {
			$getter = 'get_' . $field;
			if ( is_callable( array( $item, $getter ) ) ) {
				$data[ $field ] = self::normalize( $item->$getter( 'edit' ), in_array( $field, array_merge( self::MONEY, array( 'quantity', 'taxes', 'tax_total', 'shipping_tax_total' ) ), true ) );
			}
		}
		$attributes = array();
		if ( $item instanceof \WC_Order_Item_Product && $item->get_variation_id() ) {
			$product = $item->get_product();
			if ( $product && $product->is_type( 'variation' ) ) {
				foreach ( array_keys( $product->get_attributes() ) as $key ) {
					$attributes[ $key ] = sanitize_text_field( $item->get_meta( $key, true ) );
				}
			}
		}
		return array(
			'type'       => $item->get_type(),
			'name'       => $item->get_name(),
			'attributes' => $attributes,
			'fields'     => $data,
		);
	}

	public function take( $order ) {
		$fields  = array();
		$audited = (array) apply_filters( 'editharbor_audited_fields', array_keys( self::FIELDS ), $order );
		foreach ( self::FIELDS as $field => $category ) {
				$getter           = 'get_' . $field;
				$fields[ $field ] = self::normalize( $order->$getter( 'edit' ), in_array( $field, self::MONEY, true ) );
		}
		foreach ( array( 'billing', 'shipping' ) as $type ) {
			foreach ( self::ADDRESS as $field ) {
				$getter = 'get_' . $type . '_' . $field;
				if ( is_callable( array( $order, $getter ) ) ) {
					$fields[ $type . '_' . $field ] = self::normalize( $order->$getter( 'edit' ) );
				}
			}
		}
		foreach ( $this->meta_keys() as $key => $config ) {
			$fields[ 'meta:' . $key ] = self::normalize( $order->get_meta( $key, true, 'edit' ) );
		}
		$items = array();
		foreach ( $order->get_items( array( 'line_item', 'fee', 'shipping', 'coupon', 'tax' ) ) as $item ) {
			$key           = $item->get_id() ? (string) $item->get_id() : 'new:' . spl_object_hash( $item );
			$items[ $key ] = $this->item( $item );
		}
		ksort( $fields );
		ksort( $items );
		$customer = $order->get_user();
		return array(
			'fields'         => $fields,
			'audited_fields' => $audited,
			'items'          => $items,
			'currency'       => $order->get_currency(),
			'is_paid'        => $order->is_paid(),
			'customer_name'  => $customer ? $customer->display_name : $order->get_formatted_billing_full_name(),
		);
	}

	public function fresh( $id ) {
		$order = new \WC_Order( $id );
		return $order->get_id() && 'shop_order' === $order->get_type() ? $this->take( $order ) : null;
	}
}
