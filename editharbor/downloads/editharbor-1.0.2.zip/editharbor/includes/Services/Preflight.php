<?php
/** Complete-operation checks before WooCommerce's multiwrite handlers. @package EDHB */
namespace EDHB\Services;

defined( 'ABSPATH' ) || exit;

final class Preflight {
	private $recorder;
	private $snapshot;
	private $context;

	public function __construct( $recorder, $snapshot, $context ) {
		$this->recorder = $recorder;
		$this->snapshot = $snapshot;
		$this->context  = $context;
	}

	public function register() {
		add_action( 'wp_ajax_editharbor_order_review', array( $this, 'review_ajax' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'admin' ), 0 );
		foreach ( array( 'save_order_items', 'calc_line_taxes', 'add_order_item', 'add_order_fee', 'add_order_shipping', 'add_order_tax', 'remove_order_item', 'remove_order_coupon', 'add_coupon_discount' ) as $action ) {
			add_action( 'wp_ajax_woocommerce_' . $action, array( $this, 'ajax' ), 0 );
		}
		add_filter( 'rest_request_before_callbacks', array( $this, 'rest' ), 10, 3 );
	}

	private function posted_reason( $id ) {
		// WooCommerce validates its own mutation nonce; the extra reason is bound to this order.
		if ( isset( $_POST['editharbor_reason'], $_POST['editharbor_nonce'] ) && is_string( $_POST['editharbor_reason'] ) && is_string( $_POST['editharbor_nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['editharbor_nonce'] ) );
			if ( wp_verify_nonce( $nonce, 'editharbor_edit_' . $id ) ) {
				$this->context->set_reason( $id, sanitize_textarea_field( wp_unslash( $_POST['editharbor_reason'] ) ) );
			}
		}
	}

	public function admin( $id ) {
		if ( ! current_user_can( 'edit_shop_order', $id ) ) {
			return;
		}
		$this->posted_reason( $id );
		// WooCommerce verifies its editor nonce before invoking woocommerce_process_shop_order_meta.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Runs after WooCommerce's authenticated editor save checks.
		list( $data, $items ) = $this->admin_data( wc_clean( wp_unslash( $_POST ) ) );
		$result               = $this->check( $id, $data, $items );
		if ( is_wp_error( $result ) ) {
			wp_die(
				esc_html( $result->get_error_message() ),
				esc_html__( 'Order change stopped', 'editharbor' ),
				array(
					'response'  => 409,
					'back_link' => true,
				)
			);
		}
	}

	/** Parse the native editor payload once for review and authoritative preflight. */
	public function admin_data( array $posted ) {
		$data = array();
		foreach ( array_keys( Order_Snapshot::FIELDS ) as $field ) {
			$key = 'status' === $field ? 'order_status' : ( 'customer_id' === $field ? 'customer_user' : ( 'customer_note' === $field ? 'customer_note' : '_' . $field ) );
			if ( isset( $posted[ $key ] ) ) {
				$data[ $field ] = sanitize_textarea_field( $posted[ $key ] );
				if ( 'status' === $field ) {
					$data[ $field ] = preg_replace( '/^wc-/', '', $data[ $field ] );
				}
			}
		}
		foreach ( array( 'billing', 'shipping' ) as $type ) {
			foreach ( Order_Snapshot::ADDRESS as $field ) {
				$key = '_' . $type . '_' . $field;
				if ( isset( $posted[ $key ] ) ) {
					$data[ $type ][ $field ] = sanitize_text_field( $posted[ $key ] );
				}
			}
		}
		$items = isset( $posted['order_item_id'] ) ? $posted : array();
		return array( $data, $items );
	}

	/** Preview policy without writing orders, requesting approvals or creating audit events. */
	public function review_ajax() {
		$id = absint( $_POST['order_id'] ?? 0 );
		check_ajax_referer( 'editharbor_edit_' . $id, 'nonce' );
		if ( ! current_user_can( 'edit_shop_order', $id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot edit this order.', 'editharbor' ) ), 403 );
		}
		$posted = array();
		if ( isset( $_POST['form'] ) && ! is_string( $_POST['form'] ) ) {
			wp_send_json_error( array( 'message' => __( 'The order form payload is invalid.', 'editharbor' ) ), 400 );
		}
		// Sanitize the parsed fields below; sanitizing the encoded string corrupts its values.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Fields are cleaned after parse_str().
		parse_str( wp_unslash( $_POST['form'] ?? '' ), $posted );
		list( $data, $items ) = $this->admin_data( wc_clean( $posted ) );
		$intent               = sanitize_key( wp_unslash( $_POST['intent'] ?? '' ) );
		if ( 'remove_order_item' === $intent ) {
			$data['remove_items'] = array( absint( $_POST['item_id'] ?? 0 ) );
		} elseif ( ! in_array( $intent, array( '', 'save_order', 'save_order_items' ), true ) ) {
			$data['structural'] = $intent;
		}
		$before = $this->snapshot->fresh( $id );
		if ( ! $before ) {
			wp_send_json_error( array( 'message' => __( 'This order is unavailable. Reload the editor.', 'editharbor' ) ), 404 );
		}
		$after   = $this->propose( $before, $data, $items );
		$plugin  = \EDHB\Core\Plugin::instance();
		$changes = $plugin->get( 'diff' )->compare( $before, $after, false );
		if ( ! empty( $after['structural'] ) ) {
			$category  = false !== strpos( $intent, 'coupon' ) ? 'coupon' : ( false !== strpos( $intent, 'tax' ) ? 'tax' : ( false !== strpos( $intent, 'shipping' ) ? 'shipping' : ( false !== strpos( $intent, 'fee' ) ? 'fee' : 'items' ) ) );
			$changes[] = array(
				'category'  => $category,
				'field_key' => 'structural_operation',
				'object_id' => 0,
			);
		}
		$settings = $plugin->get( 'settings' );
		$review   = array(
			'changed'  => (bool) $changes,
			'required' => $changes && $plugin->get( 'reason' )->required( $before ),
			'paid'     => $changes && ! empty( $before['is_paid'] ) && $settings->get( 'warn_paid' ) && (bool) array_intersect( array_column( $changes, 'category' ), array( 'pricing', 'items', 'shipping', 'tax', 'fee', 'coupon' ) ),
			'warning'  => $changes && in_array( $before['fields']['status'], apply_filters( 'editharbor_warning_statuses', $settings->get( 'warning_statuses' ) ), true ),
			'min'      => $settings->get( 'reason_min' ),
			'max'      => $settings->get( 'reason_max' ),
			'action'   => 'allow',
			'message'  => '',
		);
		wp_send_json_success( apply_filters( 'editharbor_order_editor_review', $review, $id, $before, $after, $changes ) );
	}

	public function ajax() {
		$id = isset( $_POST['order_id'] ) && is_scalar( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		if ( ! $id || ! current_user_can( 'edit_shop_order', $id ) ) {
			wp_send_json_error( array( 'error' => __( 'You cannot edit this order.', 'editharbor' ) ), 403 );
		}
		check_ajax_referer( 'order-item', 'security' );
		$this->posted_reason( $id );
		$items = array();
		if ( isset( $_POST['items'] ) && is_string( $_POST['items'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Serialized fields are cleaned immediately after parsing.
			parse_str( wp_unslash( $_POST['items'] ), $items );
			$items = wc_clean( $items );
		}
		$action = isset( $_POST['action'] ) && is_scalar( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';
		$data   = array();
		if ( 'woocommerce_remove_order_item' === $action ) {
			$data['remove_items'] = array_map( 'absint', (array) ( $_POST['order_item_ids'] ?? array() ) );
		} elseif ( ! in_array( $action, array( 'woocommerce_save_order_items', 'woocommerce_calc_line_taxes' ), true ) ) {
			// A structural sentinel checks policy before coupon/product handlers can write anything.
			$data['structural'] = $action;
		}
		if ( 'woocommerce_calc_line_taxes' === $action ) {
			$data['recalculate_tax'] = true;
		}
		$result = $this->check( $id, $data, $items );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'error'  => $result->get_error_message(),
					'code'   => $result->get_error_code(),
					'detail' => $result->get_error_data(),
				),
				409
			);
		}
	}

	public function rest( $response, $handler, $request ) {
		if ( null !== $response || ! in_array( $request->get_method(), array( 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
			return $response;
		}
		$route = $request->get_route();
		if ( ! preg_match( '#^/wc/v[123]/orders/(\d+)(?:/|$)#', $route, $match ) ) {
			return $response;
		}
		$id = absint( $match[1] );
		if ( ! current_user_can( 'edit_shop_order', $id ) ) {
			return new \WP_Error( 'editharbor_forbidden', __( 'You cannot edit this order.', 'editharbor' ), array( 'status' => 403 ) );
		}
		$reason = $request->get_header( 'x-editharbor-reason' );
		$this->context->set_reason( $id, sanitize_textarea_field( $reason ?: '' ) );
		$data = wc_clean( $request->get_params() );
		if ( 'DELETE' === $request->get_method() || false !== strpos( $route, '/refunds' ) ) {
			$data['structural'] = 'order_delete_or_refund';
		}
		$result = $this->check( $id, $data );
		return is_wp_error( $result ) ? $result : $response;
	}

	public function propose( array $before, array $data, array $items = array() ) {
		$after = $before;
		foreach ( Order_Snapshot::FIELDS as $field => $category ) {
			if ( isset( $data[ $field ] ) ) {
				$after['fields'][ $field ] = Order_Snapshot::normalize( 'customer_id' === $field ? absint( $data[ $field ] ) : $data[ $field ], in_array( $field, Order_Snapshot::MONEY, true ) );
			}
		}
		foreach ( array( 'billing', 'shipping' ) as $type ) {
			foreach ( Order_Snapshot::ADDRESS as $field ) {
				if ( isset( $data[ $type ][ $field ] ) ) {
					$after['fields'][ $type . '_' . $field ] = sanitize_text_field( $data[ $type ][ $field ] );
				}
			}
		}
		foreach ( (array) ( $data['meta_data'] ?? array() ) as $meta ) {
			if ( isset( $meta['key'] ) && isset( $this->snapshot->meta_keys()[ $meta['key'] ] ) ) {
				$after['fields'][ 'meta:' . $meta['key'] ] = Order_Snapshot::normalize( $meta['value'] ?? '' );
			}
		}
		foreach ( (array) ( $data['remove_items'] ?? array() ) as $id ) {
			unset( $after['items'][ absint( $id ) ] );
		}
		foreach ( array(
			'line_items'     => 'line_item',
			'fee_lines'      => 'fee',
			'shipping_lines' => 'shipping',
			'coupon_lines'   => 'coupon',
		) as $key => $type ) {
			foreach ( (array) ( $data[ $key ] ?? array() ) as $item ) {
				$id = absint( $item['id'] ?? 0 );
				if ( ! $id || ! isset( $before['items'][ $id ] ) ) {
					$after['structural'] = 'new_or_unknown_item';
					continue;
				}
				if ( isset( $item['quantity'] ) && 0 === (int) $item['quantity'] ) {
					unset( $after['items'][ $id ] );
					continue;
				}
				foreach ( $before['items'][ $id ]['fields'] as $field => $value ) {
					if ( isset( $item[ $field ] ) ) {
						$after['items'][ $id ]['fields'][ $field ] = Order_Snapshot::normalize( $item[ $field ], in_array( $field, array_merge( Order_Snapshot::MONEY, array( 'quantity', 'taxes' ) ), true ) );
					}
				}
			}
		}
		$map = array(
			'order_item_name'       => 'name',
			'order_item_qty'        => 'quantity',
			'order_item_tax_class'  => 'tax_class',
			'line_total'            => 'total',
			'line_subtotal'         => 'subtotal',
			'shipping_method'       => 'method_id',
			'shipping_method_title' => 'method_title',
			'shipping_cost'         => 'total',
		);
		foreach ( $after['items'] as $id => &$item ) {
			foreach ( $map as $key => $field ) {
				if ( isset( $items[ $key ][ $id ] ) ) {
					$item['fields'][ $field ] = Order_Snapshot::normalize( $items[ $key ][ $id ], in_array( $field, array_merge( Order_Snapshot::MONEY, array( 'quantity' ) ), true ) );
				}
			}
			foreach ( array(
				'line_tax'          => 'total',
				'line_subtotal_tax' => 'subtotal',
				'shipping_taxes'    => 'total',
			) as $key => $field ) {
				if ( isset( $items[ $key ][ $id ] ) ) {
					$item['fields']['taxes'][ $field ]                                      = Order_Snapshot::normalize( $items[ $key ][ $id ], true );
					$item['fields'][ 'subtotal' === $field ? 'subtotal_tax' : 'total_tax' ] = Order_Snapshot::normalize( array_sum( $items[ $key ][ $id ] ), true );
				}
			}
		}
		unset( $item );
		if ( $items || array_intersect( array_keys( $data ), array( 'line_items', 'fee_lines', 'shipping_lines', 'remove_items' ) ) ) {
			$totals = array(
				'total'          => 0,
				'shipping_total' => 0,
				'cart_tax'       => 0,
				'shipping_tax'   => 0,
				'discount_total' => 0,
			);
			foreach ( $after['items'] as $item ) {
				$f = $item['fields'];
				if ( in_array( $item['type'], array( 'line_item', 'fee', 'shipping' ), true ) ) {
					$totals['total'] += (float) ( $f['total'] ?? 0 ) + (float) ( $f['total_tax'] ?? 0 );
					$totals[ 'shipping' === $item['type'] ? 'shipping_tax' : 'cart_tax' ] += (float) ( $f['total_tax'] ?? 0 );
				}
				if ( 'shipping' === $item['type'] ) {
					$totals['shipping_total'] += (float) ( $f['total'] ?? 0 );
				}
				if ( 'line_item' === $item['type'] ) {
					$totals['discount_total'] += (float) ( $f['subtotal'] ?? 0 ) - (float) ( $f['total'] ?? 0 );
				}
			}
			foreach ( $totals as $key => $value ) {
				$after['fields'][ $key ] = Order_Snapshot::normalize( $value, true );
			}
		}
		if ( isset( $data['structural'] ) ) {
			$after['structural'] = sanitize_key( $data['structural'] );
		}
		if ( ! empty( $data['recalculate_tax'] ) ) {
			$after['structural'] = 'tax_recalculation';
		}
		return $after;
	}

	public function check( $id, array $data, array $items = array() ) {
		$before = $this->recorder->capture( $id );
		if ( is_wp_error( $before ) || ! $before ) {
			return $before ?: true;
		}
		return $this->recorder->guard( $id, $this->propose( $before, $data, $items ) );
	}
}
