<?php
/** Capability installation. @package EDHB */
namespace EDHB\Support;

defined( 'ABSPATH' ) || exit;

final class Capabilities {
	const ALL = array( 'editharbor_view_order_audit', 'editharbor_view_all_audits', 'editharbor_manage_settings' );

	public static function install() {
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( self::ALL as $capability ) {
				if ( ! array_key_exists( $capability, $admin->capabilities ) ) {
					$admin->add_cap( $capability );
				}
			}
		}
		$manager = get_role( 'shop_manager' );
		if ( $manager && ! array_key_exists( 'editharbor_view_order_audit', $manager->capabilities ) ) {
			$manager->add_cap( 'editharbor_view_order_audit' );
		}
	}

	public static function notice_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return current_user_can( 'activate_plugins' ) && $screen && ( 'plugins' === $screen->id || false !== strpos( $screen->id, 'editharbor' ) );
	}

	public static function can_view_order( $id ) {
		$id = absint( $id );
		if ( ! $id || ! current_user_can( 'editharbor_view_order_audit' ) || ! current_user_can( 'edit_shop_order', $id ) ) {
			return false;
		}
		$order = wc_get_order( $id );
		return $order && 'shop_order' === $order->get_type();
	}
}
