<?php
/** Human-readable audit values; callers escape output. @package EDHB */
namespace EDHB\Support;

defined( 'ABSPATH' ) || exit;

final class Formatting {
	public static function label( $change ) {
		$labels         = array(
			'status'               => __( 'Order status', 'editharbor' ),
			'customer_id'          => __( 'Customer', 'editharbor' ),
			'total'                => __( 'Total', 'editharbor' ),
			'subtotal'             => __( 'Subtotal', 'editharbor' ),
			'quantity'             => __( 'Quantity', 'editharbor' ),
			'item_added'           => __( 'Item added', 'editharbor' ),
			'item_removed'         => __( 'Item removed', 'editharbor' ),
			'discount_total'       => __( 'Discount total', 'editharbor' ),
			'shipping_total'       => __( 'Shipping total', 'editharbor' ),
			'payment_method'       => __( 'Payment method', 'editharbor' ),
			'payment_method_title' => __( 'Payment method title', 'editharbor' ),
			'tax_total'            => __( 'Tax total', 'editharbor' ),
			'shipping_tax_total'   => __( 'Shipping tax total', 'editharbor' ),
			'cart_tax'             => __( 'Order tax', 'editharbor' ),
			'shipping_tax'         => __( 'Shipping tax', 'editharbor' ),
			'currency'             => __( 'Currency', 'editharbor' ),
			'customer_note'        => __( 'Customer note', 'editharbor' ),
		);
		$address_labels = array(
			'first_name' => __( 'First name', 'editharbor' ),
			'last_name'  => __( 'Last name', 'editharbor' ),
			'company'    => __( 'Company', 'editharbor' ),
			'address_1'  => __( 'Address line 1', 'editharbor' ),
			'address_2'  => __( 'Address line 2', 'editharbor' ),
			'city'       => __( 'City', 'editharbor' ),
			'state'      => __( 'State', 'editharbor' ),
			'postcode'   => __( 'Postcode', 'editharbor' ),
			'country'    => __( 'Country', 'editharbor' ),
			'email'      => __( 'Email', 'editharbor' ),
			'phone'      => __( 'Phone', 'editharbor' ),
		);
		$key            = $change['field_key'];
		$label          = $labels[ $key ] ?? ucwords( str_replace( '_', ' ', $change['field_label'] ) );
		if ( preg_match( '/^(billing|shipping)_(.+)$/', $key, $parts ) && in_array( $parts[2], \EDHB\Services\Order_Snapshot::ADDRESS, true ) ) {
			/* translators: 1: address type, 2: field. */
			$label = sprintf( __( '%1$s: %2$s', 'editharbor' ), 'billing' === $parts[1] ? __( 'Billing', 'editharbor' ) : __( 'Shipping', 'editharbor' ), $address_labels[ $parts[2] ] ?? $parts[2] );
		}
		return apply_filters( 'editharbor_format_field_label', $label, $change );
	}

	public static function value( $change, $side, $mask = false ) {
		$value = $change[ $side . '_value' ];
		if ( $mask && $change['is_sensitive'] ) {
			$masked = \EDHB\Privacy\Masker::mask( $value, $change['field_key'] );
			return is_array( $masked ) ? implode( ', ', self::flatten( $masked ) ) : $masked;
		}
		if ( null === $value || '' === $value ) {
			$value = __( 'None', 'editharbor' );
		} elseif ( 'money' === $change['value_type'] ) {
			$value = html_entity_decode( wp_strip_all_tags( wc_price( $value, array( 'currency' => $change['metadata']['currency'] ?? get_woocommerce_currency() ) ) ), ENT_QUOTES, 'UTF-8' );
		} elseif ( 'status' === $change['field_key'] ) {
			$value = wc_get_order_status_name( $value );
		} elseif ( 'customer_id' === $change['field_key'] ) {
			$value = $change['metadata'][ $side . '_name' ] ?? __( 'Guest / former customer', 'editharbor' );
		} elseif ( is_array( $value ) ) {
			$value = isset( $value['name'] ) ? $value['name'] : implode( ', ', self::flatten( $value ) );
		}
		return apply_filters( 'editharbor_format_audit_value', (string) $value, $change, $side );
	}

	private static function flatten( array $values ) {
		$out = array();
		foreach ( $values as $key => $value ) {
			$out[] = $key . ': ' . ( is_array( $value ) ? implode( ', ', self::flatten( $value ) ) : (string) $value );
		}
		return $out;
	}

	public static function date( $date, $utc = false ) {
		$timestamp = strtotime( $date . ' UTC' );
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp, $utc ? new \DateTimeZone( 'UTC' ) : wp_timezone() );
	}
}
