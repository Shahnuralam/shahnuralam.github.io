<?php
/** Diagnostic logging without order contents. @package EDHB */
namespace EDHB\Support;

defined( 'ABSPATH' ) || exit;

final class Logger {
	public static function error( $code ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->error( sanitize_key( $code ), array( 'source' => 'editharbor' ) );
		}
		update_option(
			'editharbor_last_error',
			array(
				'code' => sanitize_key( $code ),
				'time' => time(),
			),
			false
		);
	}
}
