<?php
/** Serialize option updates across independent admin sessions. @package EDHB */
namespace EDHB\Support;

defined( 'ABSPATH' ) || exit;

// Plugin-owned audit tables/advisory locks require current database state; WordPress has no CRUD API for them.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

final class Settings_Lock {
	public static function update( $option, callable $callback ) {
		global $wpdb;
		$name = substr( 'editharbor_settings_' . hash( 'sha256', $wpdb->prefix . ':' . $option ), 0, 64 );
		if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $name ) ) ) {
			return new \WP_Error( 'editharbor_settings_busy', __( 'Another settings save is in progress. Please try again.', 'editharbor' ), array( 'status' => 409 ) );
		}
		try {
			// Options may have been read before another request finished its save.
			wp_cache_delete( $option, 'options' );
			wp_cache_delete( 'alloptions', 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			return $callback();
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $name ) );
		}
	}
}
