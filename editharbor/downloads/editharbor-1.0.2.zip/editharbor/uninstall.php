<?php
/** Explicit opt-in uninstall; never deletes WooCommerce order data. @package EDHB */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
function editharbor_uninstall_site() {
	global $wpdb;
	$settings = get_option( 'editharbor_settings', array() );
	foreach ( array( 'editharbor_cleanup_orphans' ) as $hook ) {
		wp_clear_scheduled_hook( $hook );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( $hook, array(), 'editharbor' ); }
	}
	if ( empty( $settings['delete_data'] ) ) {
		return; }
	foreach ( array( 'events', 'changes', 'identities' ) as $suffix ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Explicit opt-in uninstall removes only the plugin-owned table.
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'editharbor_' . $suffix ) ); }
	foreach ( array( 'editharbor_settings', 'editharbor_db_version', 'editharbor_db_error', 'editharbor_last_error', 'editharbor_identity_secret', 'editharbor_welcome', 'editharbor_orphan_cursor', 'editharbor_legacy_upgraded', 'editharbor_upgrade_error' ) as $option ) {
		delete_option( $option ); }
	foreach ( wp_roles()->role_objects as $role ) {
		foreach ( array( 'editharbor_view_order_audit', 'editharbor_view_all_audits', 'editharbor_manage_settings' ) as $capability ) {
			$role->remove_cap( $capability ); }
	}
	delete_transient( 'editharbor_stats' );
}
if ( is_multisite() ) {
	$editharbor_offset = 0;
	do {
		$editharbor_sites = get_sites(
			array(
				'fields' => 'ids',
				'number' => 100,
				'offset' => $editharbor_offset,
			)
		);
		foreach ( $editharbor_sites as $editharbor_site ) {
			switch_to_blog( $editharbor_site );
			editharbor_uninstall_site();
			restore_current_blog(); }
		$editharbor_offset += 100;
	} while ( count( $editharbor_sites ) === 100 );
} else {
	editharbor_uninstall_site(); }
