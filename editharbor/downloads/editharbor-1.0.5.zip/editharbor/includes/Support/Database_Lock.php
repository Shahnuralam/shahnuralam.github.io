<?php
/** Database serialization with a fenced lease for non-MySQL backends. @package EDHB */
namespace EDHB\Support;
defined( 'ABSPATH' ) || exit;

// Lock rows require uncached reads and owner-checked writes against the options unique key.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
final class Database_Lock {
	private static $checking = false;
	private static $advisory_supported = null;
	private $name;
	private $option;
	private $token = '';
	private $held = false;
	private $advisory = false;

	public function __construct( $name ) {
		$this->name = substr( $name, 0, 64 );
		$this->option = 'editharbor_db_lock_' . hash( 'sha256', $name );
	}
	public static function sqlite() {
		global $wpdb;
		return ( defined( 'DB_ENGINE' ) && 'sqlite' === DB_ENGINE ) || ( defined( 'DATABASE_TYPE' ) && 'sqlite' === DATABASE_TYPE ) || defined( 'SQLITE_DB_DROPIN_VERSION' ) || $wpdb instanceof \WP_SQLite_DB;
	}
	public function acquire( $wait = 5 ) {
		global $wpdb;
		if ( $this->held ) { return $this->renew(); }
		if ( ! self::sqlite() && false !== self::$advisory_supported ) {
			$previous = $wpdb->suppress_errors( true );
			$error = '';
			$result = null;
			try { $result = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $this->name, max( 0, (int) $wait ) ) ); $error = $wpdb->last_error; }
			catch ( \Throwable $exception ) { $error = $exception->getMessage(); }
			finally { $wpdb->suppress_errors( $previous ); }
			if ( '1' === (string) $result ) { self::$advisory_supported = true; $this->held = true; $this->advisory = true; return true; }
			if ( '0' === (string) $result ) { return false; }
			// Unknown NULL, connection and permission failures must not bypass an advisory owner.
			if ( false === stripos( $error, 'GET_LOCK' ) || ! preg_match( '/does not exist|no such function|not supported|not implemented|unsupported|not recognized/i', $error ) ) { return false; }
			self::$advisory_supported = false;
		}
		$deadline = microtime( true ) + max( 0, (int) $wait );
		$this->token = wp_generate_uuid4();
		do {
			self::$checking = true;
			try {
				$this->clear_cache();
				if ( add_option( $this->option, $this->value(), '', false ) ) {
					$this->held = true;
					add_filter( 'query', array( $this, 'fence' ), PHP_INT_MAX );
					return true;
				}
				$old = $this->read();
				$lease = json_decode( (string) $old, true );
				if ( is_array( $lease ) && isset( $lease['expires'], $lease['token'] ) && is_int( $lease['expires'] ) && is_string( $lease['token'] ) && '' !== $lease['token'] && $lease['expires'] <= time() ) {
					$wpdb->delete( $wpdb->options, array( 'option_name' => $this->option, 'option_value' => $old ) );
					$this->clear_cache();
					if ( add_option( $this->option, $this->value(), '', false ) ) { $this->held = true; add_filter( 'query', array( $this, 'fence' ), PHP_INT_MAX ); return true; }
				}
			} finally { self::$checking = false; }
			if ( microtime( true ) >= $deadline ) { return false; }
			usleep( 50000 );
		} while ( true );
	}
	private function value() { return wp_json_encode( array( 'token' => $this->token, 'expires' => time() + 600, 'revision' => wp_generate_uuid4() ) ); }
	private function read() {
		global $wpdb;
		return $wpdb->get_var( $wpdb->prepare( 'SELECT option_value FROM %i WHERE option_name = %s', $wpdb->options, $this->option ) );
	}
	private function clear_cache() { wp_cache_delete( $this->option, 'options' ); wp_cache_delete( 'notoptions', 'options' ); }
	public function renew() {
		global $wpdb;
		if ( ! $this->held ) { return false; }
		if ( $this->advisory ) { return true; }
		self::$checking = true;
		try {
			$old = $this->read(); $lease = json_decode( (string) $old, true );
			if ( ! is_array( $lease ) || ! isset( $lease['expires'] ) || ! is_int( $lease['expires'] ) || ( $lease['token'] ?? '' ) !== $this->token || $lease['expires'] <= time() ) { return false; }
			$updated = $wpdb->update( $wpdb->options, array( 'option_value' => $this->value() ), array( 'option_name' => $this->option, 'option_value' => $old ) );
			$this->clear_cache();
			return 1 === $updated;
		} finally { self::$checking = false; }
	}
	public function fence( $query ) {
		if ( ! self::$checking && is_string( $query ) && preg_match( '/^\s*(?:(?:\/\*.*?\*\/|--[^\r\n]*(?:\r?\n|$)|#[^\r\n]*(?:\r?\n|$))\s*)*(?:INSERT|UPDATE|DELETE|REPLACE|ALTER|CREATE|DROP|TRUNCATE|RENAME|COMMIT|WITH)\b/is', $query ) && ! $this->renew() ) {
			throw new \RuntimeException( 'editharbor_database_lock_lost' );
		}
		return $query;
	}
	public function release() {
		global $wpdb;
		if ( ! $this->held ) { return; }
		try {
			if ( $this->advisory ) { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $this->name ) ); }
			else {
				self::$checking = true;
				$old = $this->read(); $lease = json_decode( (string) $old, true );
				if ( is_array( $lease ) && ( $lease['token'] ?? '' ) === $this->token ) { $wpdb->delete( $wpdb->options, array( 'option_name' => $this->option, 'option_value' => $old ) ); }
				$this->clear_cache();
			}
		} finally { self::$checking = false; remove_filter( 'query', array( $this, 'fence' ), PHP_INT_MAX ); $this->held = false; }
	}
}
