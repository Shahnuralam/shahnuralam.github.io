<?php
/** Request-scoped database serialization; no order-table SQL. @package EDHB */
namespace EDHB\Support;

defined( 'ABSPATH' ) || exit;

// Plugin-owned audit tables/advisory locks require current database state; WordPress has no CRUD API for them.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

final class Order_Lock {
	private $held = array();

	public function acquire( $order_id ) {
		global $wpdb;
		if ( isset( $this->held[ $order_id ] ) ) {
			return $this->held[ $order_id ]->renew();
		}
		$name = 'editharbor_' . hash( 'sha256', $wpdb->prefix . ':' . absint( $order_id ) );
		$name = substr( $name, 0, 64 );
		$lock = new Database_Lock( $name );
		if ( ! $lock->acquire() ) {
			return false;
		}
		$this->held[ $order_id ] = $lock;
		return true;
	}

	public function release( $order_id ) {
		global $wpdb;
		if ( isset( $this->held[ $order_id ] ) ) {
			$this->held[ $order_id ]->release();
			unset( $this->held[ $order_id ] );
		}
	}

	public function release_all() {
		foreach ( array_keys( $this->held ) as $id ) {
			$this->release( $id );
		}
	}
}
