<?php
/**
 * Plugin Name: EditHarbor – Order History & Guard for WooCommerce
 * Plugin URI: https://shahnuralam.github.io/editharbor/
 * Description: Clear order change history, staff change reasons and paid-order warnings.
 * Version: 1.0.4
 * Author: Shahnur Alam
 * Author URI: https://shahnuralam.github.io/
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 8.2
 * WC tested up to: 11.1.2
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: order-edit-guard-for-woocommerce
 * Domain Path: /languages
 *
 * @package EDHB
 */

defined( 'ABSPATH' ) || exit;

define( 'EDHB_VERSION', '1.0.4' );
define( 'EDHB_DB_VERSION', '2' );
define( 'EDHB_FILE', __FILE__ );
define( 'EDHB_PATH', plugin_dir_path( __FILE__ ) );

// Recognize the branded development checkout as the same dependency as the directory package.
add_filter( 'wp_plugin_dependencies_slug', static function ( $slug ) {
	if ( 'order-edit-guard-for-woocommerce' === $slug && 'editharbor' === dirname( plugin_basename( EDHB_FILE ) ) ) {
		return 'editharbor';
	}
	return $slug;
} );

spl_autoload_register(
	static function ( $class ) {
		if ( 0 === strpos( $class, 'EDHB\\' ) ) {
			$file = EDHB_PATH . 'includes/' . str_replace( '\\', '/', substr( $class, 5 ) ) . '.php';
			if ( is_file( $file ) ) {
				require_once $file;
			}
		}
	}
);

/** Validate the complete settings option registered with the Settings API. */
function editharbor_sanitize_settings( $input ) {
	return ( new \EDHB\Core\Settings() )->sanitize( $input );
}

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', EDHB_FILE, true );
		}
	}
);

register_activation_hook( __FILE__, array( '\EDHB\Database\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\EDHB\Core\Plugin', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		if ( defined( 'OEG_VERSION' ) ) {
			add_action( 'admin_notices', static function () {
				if ( \EDHB\Support\Capabilities::notice_screen() ) {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'Deactivate the old Order Edit Guard plugin before using EditHarbor. Existing history will be upgraded when EditHarbor starts.', 'order-edit-guard-for-woocommerce' ) . '</p></div>';
				}
			} );
			return;
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				static function () {
					if ( ! \EDHB\Support\Capabilities::notice_screen() ) {
						return;
					}
					echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'EditHarbor requires WooCommerce to be installed and activated.', 'order-edit-guard-for-woocommerce' ) . '</p></div>';
				}
			);
			return;
		}
		// WooCommerce APIs and translation catalogs are ready once init has begun.
		add_action( 'init', array( \EDHB\Core\Plugin::instance(), 'boot' ), 20 );
	},
	20
);
