<?php
/** Native admin screens and order history. @package EDHB */
namespace EDHB\Admin;

defined( 'ABSPATH' ) || exit;

final class Admin {
	private $plugin;
	public function __construct( $plugin ) {
		$this->plugin = $plugin; }
	public function register() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'settings' ) );
		add_action( 'add_meta_boxes', array( $this, 'metabox' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'wp_ajax_editharbor_history', array( $this, 'history_ajax' ) );
		add_action( 'wp_ajax_editharbor_maintenance', array( $this, 'maintenance' ) );
		add_action( 'admin_post_editharbor_maintenance', array( $this, 'maintenance' ) );
		add_action( 'admin_notices', array( $this, 'notices' ) );
		add_filter(
			'option_page_capability_editharbor',
			static function () {
				return 'editharbor_manage_settings';
			}
		);
	}
	public function menu() {
		$this->plugin->get( 'workspace' )->menu(); }
	public function settings() {
		register_setting(
			'editharbor',
			'editharbor_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => 'editharbor_sanitize_settings',
			)
		);
	}
	public function notices() {
		$screen = get_current_screen();
		if ( ! current_user_can( 'editharbor_manage_settings' ) || ! $screen || false === strpos( $screen->id, 'editharbor' ) ) {
			return; }
		if ( get_option( 'editharbor_db_error' ) || get_option( 'editharbor_last_error' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'EditHarbor has reported a database or capture error. Review its diagnostics and WooCommerce logs.', 'order-edit-guard-for-woocommerce' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=editharbor-settings' ) ) . '">' . esc_html__( 'Diagnostics', 'order-edit-guard-for-woocommerce' ) . '</a></p></div>';
		}
		if ( get_option( 'editharbor_welcome' ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'EditHarbor is ready. Review your auditing, warning and privacy settings before editing orders.', 'order-edit-guard-for-woocommerce' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=editharbor-settings' ) ) . '">' . esc_html__( 'View settings', 'order-edit-guard-for-woocommerce' ) . '</a></p></div>';
			delete_option( 'editharbor_welcome' );
		}
	}
	public function dashboard() {
		$this->authorize( 'editharbor_view_all_audits' );
		$repository = $this->plugin->get( 'repository' );
		$midnight   = new \DateTimeImmutable( 'today', wp_timezone() );
		$filters    = array( 'from' => $midnight->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ) );
		$stats      = $repository->summary( $filters );
		$paid       = $repository->count( array_merge( $filters, array( 'was_paid' => 1 ) ) );
		Components::heading( __( 'Overview', 'order-edit-guard-for-woocommerce' ), __( 'A clear picture of today’s changes.', 'order-edit-guard-for-woocommerce' ), __( 'See what your team changed, review important edits, and find the story behind each order.', 'order-edit-guard-for-woocommerce' ) );
		echo '<div class="editharbor-metrics">';
		Components::metric( __( 'Orders edited', 'order-edit-guard-for-woocommerce' ), $stats['orders'], __( 'Distinct orders changed today', 'order-edit-guard-for-woocommerce' ), 'cart' );
		Components::metric( __( 'Change groups', 'order-edit-guard-for-woocommerce' ), $stats['events'], __( 'Related edits recorded together', 'order-edit-guard-for-woocommerce' ), 'backup' );
		Components::metric( __( 'Team members', 'order-edit-guard-for-woocommerce' ), $stats['users'], __( 'People who made changes today', 'order-edit-guard-for-woocommerce' ), 'groups' );
		Components::metric( __( 'Paid-order activity', 'order-edit-guard-for-woocommerce' ), $paid, __( 'Groups recorded on paid orders', 'order-edit-guard-for-woocommerce' ), 'shield' );
		echo '</div><div class="editharbor-card"><div class="editharbor-card-heading"><div><h3>' . esc_html__( 'Latest activity', 'order-edit-guard-for-woocommerce' ) . '</h3><p>' . esc_html__( 'Open a change group to see previous values, new values and its reason.', 'order-edit-guard-for-woocommerce' ) . '</p></div><a class="button" href="' . esc_url( admin_url( 'admin.php?page=editharbor&section=audit' ) ) . '">' . esc_html__( 'View all history', 'order-edit-guard-for-woocommerce' ) . '</a></div>';
		$this->table( $repository->query( array(), 1, 10 ) );
		echo '</div>';
	}

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL controls; screen access is capability checked.
	public function filters( $default_range = 'all' ) {
		$out = array();
		foreach ( array( 'order_id', 'user_id' ) as $key ) {
			$out[ $key ] = isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? absint( $_GET[ $key ] ) : 0; }
		foreach ( array( 'from', 'to', 'category', 'source', 'search', 'actor_role', 'order_status_after' ) as $key ) {
			$out[ $key ] = isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) : '';
		}
		$range = isset( $_GET['range'] ) && is_scalar( $_GET['range'] ) ? sanitize_key( wp_unslash( $_GET['range'] ) ) : ( $out['from'] || $out['to'] ? 'custom' : $default_range );
		$today = new \DateTimeImmutable( 'today', new \DateTimeZone( 'UTC' ) );
		$dates = array(
			'today'     => array( $today, $today ),
			'yesterday' => array( $today->modify( '-1 day' ), $today->modify( '-1 day' ) ),
			'7days'     => array( $today->modify( '-6 days' ), $today ),
			'30days'    => array( $today->modify( '-29 days' ), $today ),
			'month'     => array( $today->modify( 'first day of this month' ), $today ),
			'lastmonth' => array( $today->modify( 'first day of last month' ), $today->modify( 'last day of last month' ) ),
		);
		if ( isset( $dates[ $range ] ) ) {
			$out['from'] = $dates[ $range ][0]->format( 'Y-m-d' );
			$out['to']   = $dates[ $range ][1]->format( 'Y-m-d' ); } elseif ( 'all' === $range ) {
			$out['from'] = '';
			$out['to']   = ''; }
			$out['range'] = isset( $dates[ $range ] ) || in_array( $range, array( 'all', 'custom' ), true ) ? $range : 'custom';
			return $out;
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	public function filter_form( $page = 'editharbor-audit', $filters = null ) {
		$filters = $filters ?? $this->filters( 'editharbor-pro-reports' === $page ? '30days' : 'all' );
		$section = 'editharbor-pro-reports' === $page ? 'pro-reports' : 'audit';
		echo '<form method="get" class="editharbor-filter-card"><input type="hidden" name="page" value="editharbor"><input type="hidden" name="section" value="' . esc_attr( $section ) . '"><div class="editharbor-card-heading"><div><h3>' . esc_html__( 'Find the changes you need', 'order-edit-guard-for-woocommerce' ) . '</h3><p>' . esc_html__( 'Choose a period and narrow the results. Report dates use UTC.', 'order-edit-guard-for-woocommerce' ) . '</p></div></div><div class="editharbor-filter-grid"><label>' . esc_html__( 'Time period', 'order-edit-guard-for-woocommerce' ) . '<select name="range" class="editharbor-date-range">';
		foreach ( array(
			'all'       => __( 'All history', 'order-edit-guard-for-woocommerce' ),
			'today'     => __( 'Today', 'order-edit-guard-for-woocommerce' ),
			'yesterday' => __( 'Yesterday', 'order-edit-guard-for-woocommerce' ),
			'7days'     => __( 'Last 7 days', 'order-edit-guard-for-woocommerce' ),
			'30days'    => __( 'Last 30 days', 'order-edit-guard-for-woocommerce' ),
			'month'     => __( 'This month', 'order-edit-guard-for-woocommerce' ),
			'lastmonth' => __( 'Last month', 'order-edit-guard-for-woocommerce' ),
			'custom'    => __( 'Custom dates', 'order-edit-guard-for-woocommerce' ),
		) as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $filters['range'], $key, false ) . '>' . esc_html( $label ) . '</option>'; }
		echo '</select></label>';
		foreach ( array(
			'from'     => __( 'From', 'order-edit-guard-for-woocommerce' ),
			'to'       => __( 'Through', 'order-edit-guard-for-woocommerce' ),
			'order_id' => __( 'Order ID', 'order-edit-guard-for-woocommerce' ),
			'search'   => __( 'Team member or reason', 'order-edit-guard-for-woocommerce' ),
		) as $key => $label ) {
			$type = in_array( $key, array( 'from', 'to' ), true ) ? 'date' : ( 'order_id' === $key ? 'number' : 'search' );
			echo '<label>' . esc_html( $label ) . '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $filters[ $key ] ?: '' ) . '"' . ( 'order_id' === $key ? ' min="1"' : '' ) . '></label>';
		}
		echo '<label>' . esc_html__( 'Team member', 'order-edit-guard-for-woocommerce' ) . '<select name="user_id"><option value="">' . esc_html__( 'Everyone', 'order-edit-guard-for-woocommerce' ) . '</option>';
		$users = get_users(
			array(
				'capability' => 'edit_shop_orders',
				'number'     => 100,
				'orderby'    => 'display_name',
			)
		);
		$ids   = array_map(
			static function ( $user ) {
				return $user->ID;
			},
			$users
		);
		if ( $filters['user_id'] && ! in_array( $filters['user_id'], $ids, true ) ) {
			$selected_user = get_userdata( $filters['user_id'] );
			if ( $selected_user ) {
				$users[] = $selected_user; }
		}
		foreach ( $users as $user ) {
			echo '<option value="' . esc_attr( $user->ID ) . '" ' . selected( $filters['user_id'], $user->ID, false ) . '>' . esc_html( $this->plugin->get( 'settings' )->get( 'mask_display' ) ? \EDHB\Privacy\Masker::mask( $user->display_name ) : $user->display_name ) . '</option>'; }
		if ( $filters['user_id'] && ! get_userdata( $filters['user_id'] ) ) {
			echo '<option selected value="' . esc_attr( $filters['user_id'] ) . '">' . esc_html__( 'Former team member', 'order-edit-guard-for-woocommerce' ) . '</option>'; }
		echo '</select></label><label>' . esc_html__( 'Change category', 'order-edit-guard-for-woocommerce' ) . '<select name="category"><option value="">' . esc_html__( 'Every category', 'order-edit-guard-for-woocommerce' ) . '</option>';
		foreach ( self::categories() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $filters['category'], $key, false ) . '>' . esc_html( $label ) . '</option>'; }
		echo '</select></label><label>' . esc_html__( 'Where it changed', 'order-edit-guard-for-woocommerce' ) . '<select name="source"><option value="">' . esc_html__( 'Every source', 'order-edit-guard-for-woocommerce' ) . '</option>';
		foreach ( Components::sources() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $filters['source'], $key, false ) . '>' . esc_html( $label ) . '</option>'; }
		echo '</select></label>';
		do_action( 'editharbor_audit_filter_controls', $filters );
		echo '</div><div class="editharbor-filter-actions"><button type="submit" class="editharbor-save-button">' . esc_html__( 'Apply filters', 'order-edit-guard-for-woocommerce' ) . '</button><a href="' . esc_url(
			add_query_arg(
				array(
					'page'    => 'editharbor',
					'section' => $section,
				),
				admin_url( 'admin.php' )
			)
		) . '">' . esc_html__( 'Reset filters', 'order-edit-guard-for-woocommerce' ) . '</a></div></form>';
	}
	public static function categories() {
		return array(
			'status'   => __( 'Order status', 'order-edit-guard-for-woocommerce' ),
			'items'    => __( 'Products', 'order-edit-guard-for-woocommerce' ),
			'pricing'  => __( 'Pricing', 'order-edit-guard-for-woocommerce' ),
			'customer' => __( 'Customer', 'order-edit-guard-for-woocommerce' ),
			'billing'  => __( 'Billing', 'order-edit-guard-for-woocommerce' ),
			'shipping' => __( 'Shipping', 'order-edit-guard-for-woocommerce' ),
			'coupon'   => __( 'Coupons', 'order-edit-guard-for-woocommerce' ),
			'fee'      => __( 'Fees', 'order-edit-guard-for-woocommerce' ),
			'tax'      => __( 'Taxes', 'order-edit-guard-for-woocommerce' ),
			'payment'  => __( 'Payment', 'order-edit-guard-for-woocommerce' ),
			'note'     => __( 'Customer note', 'order-edit-guard-for-woocommerce' ),
			'metadata' => __( 'Metadata', 'order-edit-guard-for-woocommerce' ),
			'system'   => __( 'System', 'order-edit-guard-for-woocommerce' ),
		);
	}
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL controls; screen access is capability checked.
	public function audit() {
		$this->authorize( 'editharbor_view_all_audits' );
		Components::heading( __( 'Audit history', 'order-edit-guard-for-woocommerce' ), __( 'Every change has a story.', 'order-edit-guard-for-woocommerce' ), __( 'See who edited an order, what changed, and why. Open any change group for a detailed comparison.', 'order-edit-guard-for-woocommerce' ) );
		echo '<div class="editharbor-admin">';
		$this->filter_form();
		$event_id = isset( $_GET['event'] ) && is_scalar( $_GET['event'] ) ? absint( $_GET['event'] ) : 0;
		if ( $event_id ) {
			$event = $this->plugin->get( 'repository' )->event( $event_id );
			if ( $event ) {
				$this->render_event( $event );
				do_action( 'editharbor_audit_event_detail', $event ); }
		}
		$page    = isset( $_GET['paged'] ) && is_scalar( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$limit   = $this->plugin->get( 'settings' )->get( 'per_page' );
		$filters = $this->filters();
		$this->table( $this->plugin->get( 'repository' )->query( $filters, $page, $limit ) );
		$total      = $this->plugin->get( 'repository' )->count( $filters );
		$pagination = paginate_links(
			array(
				'base'    => add_query_arg( 'paged', '%#%' ),
				'format'  => '',
				'current' => $page,
				'total'   => max( 1, ceil( $total / $limit ) ),
			)
		);
		if ( $pagination ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( $pagination ) . '</div></div>';
		}
		echo '</div>';
	}	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	public function table( array $events ) {
		if ( ! $events ) {
			Components::empty_state( __( 'No changes to show yet', 'order-edit-guard-for-woocommerce' ), __( 'Try a broader date range or clear your filters. New edits to existing orders appear here when auditing is enabled.', 'order-edit-guard-for-woocommerce' ) );
			return; }
		echo '<div class="editharbor-table-scroll" role="region" aria-label="' . esc_attr__( 'Order change history', 'order-edit-guard-for-woocommerce' ) . '" tabindex="0"><table class="widefat editharbor-activity-table"><thead><tr>';
		foreach ( array( __( 'Date', 'order-edit-guard-for-woocommerce' ), __( 'Order', 'order-edit-guard-for-woocommerce' ), __( 'Changed by', 'order-edit-guard-for-woocommerce' ), __( 'Change type', 'order-edit-guard-for-woocommerce' ), __( 'Summary', 'order-edit-guard-for-woocommerce' ), __( 'Reason', 'order-edit-guard-for-woocommerce' ), __( 'Source', 'order-edit-guard-for-woocommerce' ) ) as $label ) {
			echo '<th scope="col">' . esc_html( $label ) . '</th>'; }
		echo '</tr></thead><tbody>';
		foreach ( $events as $event ) {
			$order = wc_get_order( $event['order_id'] );
			echo '<tr><td><a href="' . esc_url(
				add_query_arg(
					array(
						'page'    => 'editharbor',
						'section' => 'audit',
						'event'   => $event['id'],
					),
					admin_url( 'admin.php' )
				)
			) . '">' . esc_html( \EDHB\Support\Formatting::date( $event['created_at_gmt'], 'utc' === $this->plugin->get( 'settings' )->get( 'date_display' ) ) ) . '</a></td><td>';
			if ( $order ) {
				echo '<a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a>';
			} else {
					echo '#' . esc_html( $event['order_id'] ); }
			$changes = $this->plugin->get( 'repository' )->changes( $event['id'] );
			$labels  = array_unique( array_map( array( '\EDHB\Support\Formatting', 'label' ), $changes ) );
			echo '</td><td>' . esc_html( $this->actor_name( $event ) ) . '</td><td>' . esc_html( Components::event_label( $event['event_type'] ) ) . '</td><td>' . esc_html( implode( ', ', array_slice( $labels, 0, 4 ) ) ) . '</td><td>' . esc_html( $this->plugin->get( 'settings' )->get( 'mask_display' ) ? \EDHB\Privacy\Masker::mask( $event['reason'] ) : $event['reason'] ) . '</td><td>' . esc_html( Components::sources()[ $event['source'] ] ?? $event['source'] ) . '</td></tr>';
		}
		if ( ! $events ) {
			echo '<tr><td colspan="7">' . esc_html__( 'No order changes found.', 'order-edit-guard-for-woocommerce' ) . '</td></tr>'; }
		echo '</tbody></table></div>';
	}
	private function actor_name( $event ) {
		$name = $event['actor_name'] ?: __( 'System / anonymized actor', 'order-edit-guard-for-woocommerce' );
		if ( $this->plugin->get( 'settings' )->get( 'mask_display' ) ) {
			$name = \EDHB\Privacy\Masker::mask( $name ); }
		if ( $event['user_id'] && ! get_userdata( $event['user_id'] ) ) {
			$name .= ' (' . __( 'Former user', 'order-edit-guard-for-woocommerce' ) . ')'; }
		return $name;
	}
	public function render_event( array $event ) {
		$mask = $this->plugin->get( 'settings' )->get( 'mask_display' );
		echo '<article class="editharbor-event"><header><strong>' . esc_html( $this->actor_name( $event ) ) . '</strong> <span class="editharbor-badge">' . esc_html( Components::sources()[ $event['source'] ] ?? $event['source'] ) . '</span><p>' . esc_html( \EDHB\Support\Formatting::date( $event['created_at_gmt'], 'utc' === $this->plugin->get( 'settings' )->get( 'date_display' ) ) ) . ' · ' . esc_html( wp_roles()->get_names()[ $event['actor_role'] ] ?? __( 'System / former role', 'order-edit-guard-for-woocommerce' ) ) . '</p></header>';
		if ( $event['reason'] ) {
			echo '<p><strong>' . esc_html__( 'Reason', 'order-edit-guard-for-woocommerce' ) . '</strong><br>' . nl2br( esc_html( $mask ? \EDHB\Privacy\Masker::mask( $event['reason'] ) : $event['reason'] ) ) . '</p>'; }
		foreach ( $event['changes'] ?? $this->plugin->get( 'repository' )->changes( $event['id'] ) as $change ) {
			echo '<div class="editharbor-change" data-category="' . esc_attr( $change['category'] ) . '"><strong>' . esc_html( \EDHB\Support\Formatting::label( $change ) ) . '</strong>';
			if ( ! empty( $change['metadata']['item_name'] ) ) {
				echo '<p>' . esc_html( $mask && $change['is_sensitive'] ? \EDHB\Privacy\Masker::mask( $change['metadata']['item_name'] ) : $change['metadata']['item_name'] ) . '</p>'; }
			if ( ! empty( $change['metadata']['attributes'] ) ) {
				$attributes = array();
				foreach ( $change['metadata']['attributes'] as $key => $value ) {
					$attributes[] = wc_attribute_label( $key ) . ': ' . ( $mask && $change['is_sensitive'] ? \EDHB\Privacy\Masker::mask( $value ) : $value ); }
				echo '<p class="editharbor-muted">' . esc_html( implode( ', ', $attributes ) ) . '</p>';
			}
			echo '<div class="editharbor-diff"><span><small>' . esc_html__( 'Before this change', 'order-edit-guard-for-woocommerce' ) . '</small>' . esc_html( \EDHB\Support\Formatting::value( $change, 'old', $mask ) ) . '</span><span><small>' . esc_html__( 'After this change', 'order-edit-guard-for-woocommerce' ) . '</small>' . esc_html( \EDHB\Support\Formatting::value( $change, 'new', $mask ) ) . '</span></div></div>';
		}
		echo '</article>';
	}
	public function metabox() {
		if ( ! current_user_can( 'editharbor_view_order_audit' ) ) {
			return; }
		foreach ( array_unique( array( 'shop_order', wc_get_page_screen_id( 'shop-order' ) ) ) as $screen ) {
			add_meta_box( 'editharbor-history', __( 'Order Edit History', 'order-edit-guard-for-woocommerce' ), array( $this, 'panel' ), $screen, 'normal', 'default' );
		}
	}
	public function panel( $object ) {
		$order = $object instanceof \WC_Order ? $object : wc_get_order( $object->ID );
		if ( ! $order || ! \EDHB\Support\Capabilities::can_view_order( $order->get_id() ) ) {
			return; }
		$id = $order->get_id();
		wp_nonce_field( 'editharbor_edit_' . $id, 'editharbor_nonce' );
		echo '<div class="editharbor-panel" data-order="' . esc_attr( $id ) . '"><label for="editharbor-reason">' . esc_html__( 'Reason for change', 'order-edit-guard-for-woocommerce' ) . '</label><textarea id="editharbor-reason" name="editharbor_reason" rows="2" maxlength="' . esc_attr( $this->plugin->get( 'settings' )->get( 'reason_max' ) ) . '" class="widefat"></textarea><div class="editharbor-filters"><label>' . esc_html__( 'Category', 'order-edit-guard-for-woocommerce' ) . '<select class="editharbor-category"><option value="">' . esc_html__( 'All', 'order-edit-guard-for-woocommerce' ) . '</option>';
		foreach ( self::categories() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</option>'; }
		echo '</select></label><label>' . esc_html__( 'Search this page', 'order-edit-guard-for-woocommerce' ) . '<input type="search" class="editharbor-search"></label></div><div class="editharbor-history">';
		$this->history_html( $id, 1 );
		echo '</div><button type="button" class="button editharbor-prev" disabled>' . esc_html__( 'Previous page', 'order-edit-guard-for-woocommerce' ) . '</button> <button type="button" class="button editharbor-next">' . esc_html__( 'Next page', 'order-edit-guard-for-woocommerce' ) . '</button><span class="editharbor-page" aria-live="polite">1</span></div>';
		do_action( 'editharbor_order_panel', $order );
		$settings = $this->plugin->get( 'settings' )->all();
		$required = 'all' === $settings['reason_mode'] || ( 'statuses' === $settings['reason_mode'] && in_array( $order->get_status(), $settings['reason_statuses'], true ) );
		$warning  = in_array( $order->get_status(), apply_filters( 'editharbor_warning_statuses', $settings['warning_statuses'] ), true );
		echo '<script type="application/json" id="editharbor-order-config">' . wp_json_encode(
			array(
				'id'       => $id,
				'paid'     => $order->is_paid() && $settings['warn_paid'],
				'warning'  => $warning,
				'required' => $required,
				'min'      => $settings['reason_min'],
				'max'      => $settings['reason_max'],
			),
			JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
		) . '</script>';
	}
	private function history_html( $id, $page, $category = '' ) {
		$events = $this->plugin->get( 'repository' )->query(
			array(
				'order_id' => $id,
				'category' => $category,
			),
			$page,
			$this->plugin->get( 'settings' )->get( 'per_page' )
		);
		foreach ( $events as $event ) {
			$this->render_event( $event ); }
		if ( ! $events ) {
			echo '<p>' . esc_html__( 'No changes on this page.', 'order-edit-guard-for-woocommerce' ) . '</p>'; }
		return count( $events );
	}
	public function history_ajax() {
		check_ajax_referer( 'editharbor_history', 'nonce' );
		$id = isset( $_POST['order_id'] ) && is_scalar( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		if ( ! \EDHB\Support\Capabilities::can_view_order( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied.', 'order-edit-guard-for-woocommerce' ) ), 403 ); }
		$page     = isset( $_POST['page'] ) && is_scalar( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$category = isset( $_POST['category'] ) && is_scalar( $_POST['category'] ) ? sanitize_key( wp_unslash( $_POST['category'] ) ) : '';
		ob_start();
		$count = $this->history_html( $id, $page, $category );
		wp_send_json_success(
			array(
				'html'     => ob_get_clean(),
				'has_more' => $count === $this->plugin->get( 'settings' )->get( 'per_page' ),
			)
		);
	}
	public function assets() {
		$screen = get_current_screen();
		if ( ! $screen || ( ! in_array( $screen->id, array( 'shop_order', wc_get_page_screen_id( 'shop-order' ) ), true ) && false === strpos( $screen->id, 'editharbor' ) ) ) {
			return; }
		wp_enqueue_style( 'editharbor-admin', plugins_url( 'assets/css/admin.css', EDHB_FILE ), array(), EDHB_VERSION . '.' . filemtime( EDHB_PATH . 'assets/css/admin.css' ) );
		if ( false !== strpos( $screen->id, 'editharbor' ) ) {
			wp_enqueue_script( 'editharbor-workspace', plugins_url( 'assets/js/workspace.js', EDHB_FILE ), array( 'jquery' ), EDHB_VERSION . '.' . filemtime( EDHB_PATH . 'assets/js/workspace.js' ), true );
			wp_localize_script(
				'editharbor-workspace',
				'editharborWorkspace',
				array(
					'url'            => admin_url( 'admin-ajax.php' ),
					'nonce'          => wp_create_nonce( 'editharbor_workspace' ),
					'saving'         => __( 'Saving…', 'order-edit-guard-for-woocommerce' ),
					'saved'          => __( 'All changes saved', 'order-edit-guard-for-woocommerce' ),
					'dirty'          => __( 'You have unsaved changes', 'order-edit-guard-for-woocommerce' ),
					'error'          => __( 'Could not complete this request. Your changes are still here. Please try again.', 'order-edit-guard-for-woocommerce' ),
					'reloadConfirm'  => __( 'Discard your unsaved changes in this section and load the saved settings?', 'order-edit-guard-for-woocommerce' ),
					'leave'          => __( 'You have unsaved settings.', 'order-edit-guard-for-woocommerce' ),
					'auditingOn'     => __( 'Auditing is on', 'order-edit-guard-for-woocommerce' ),
					'auditingPaused' => __( 'Auditing is paused', 'order-edit-guard-for-woocommerce' ),
					'copied'         => __( 'Support report copied.', 'order-edit-guard-for-woocommerce' ),
				)
			);
		}
		wp_enqueue_script( 'editharbor-admin', plugins_url( 'assets/js/admin.js', EDHB_FILE ), array( 'jquery' ), EDHB_VERSION . '.' . filemtime( EDHB_PATH . 'assets/js/admin.js' ), true );
		wp_localize_script(
			'editharbor-admin',
			'editharborAdmin',
			array(
				'url'            => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( 'editharbor_history' ),
				'title'          => __( 'Review this order change', 'order-edit-guard-for-woocommerce' ),
				'paid'           => __( 'This order has already been paid. Changing products, prices, discounts, shipping or taxes will not automatically collect or refund money.', 'order-edit-guard-for-woocommerce' ),
				'protected'      => __( 'This order has a protected status. Changes can affect reporting and fulfillment records.', 'order-edit-guard-for-woocommerce' ),
				'reason'         => __( 'Why are you changing this order?', 'order-edit-guard-for-woocommerce' ),
				'cancel'         => __( 'Cancel', 'order-edit-guard-for-woocommerce' ),
				'continue'       => __( 'Continue', 'order-edit-guard-for-woocommerce' ),
				'submitApproval' => __( 'Submit for approval', 'order-edit-guard-for-woocommerce' ),
				'reviewError'    => __( 'The order safety check could not be completed. Your changes are still here. Please retry.', 'order-edit-guard-for-woocommerce' ),
				'reasonError'    => __( 'Enter a reason within the required length.', 'order-edit-guard-for-woocommerce' ),
			)
		);
	}
	public function settings_page() {
		$this->authorize( 'editharbor_manage_settings' );
		$s = $this->plugin->get( 'settings' )->all();
		echo '<div class="wrap editharbor-admin"><h1>' . esc_html__( 'EditHarbor Settings', 'order-edit-guard-for-woocommerce' ) . '</h1><form method="post" action="' . esc_url( admin_url( 'options.php' ) ) . '">';
		settings_fields( 'editharbor' );
		settings_errors();
		foreach ( array(
			'General'        => array( 'enabled', 'manual', 'automated', 'order_notes', 'date_display', 'per_page' ),
			'Change reasons' => array( 'reason_mode', 'reason_statuses', 'reason_min', 'reason_max' ),
			'Warnings'       => array( 'warn_paid', 'warning_statuses' ),
			'Privacy'        => array( 'log_ip', 'mask_display', 'retain_personal', 'delete_data' ),
		) as $section => $keys ) {
			echo '<h2>' . esc_html( $section ) . '</h2><table class="form-table" role="presentation">';
			foreach ( $keys as $key ) {
				$this->setting_row( $key, $s[ $key ] ); }
			echo '</table>';
		}
		submit_button();
		echo '</form><h2>' . esc_html__( 'Maintenance and diagnostics', 'order-edit-guard-for-woocommerce' ) . '</h2><textarea readonly class="widefat" rows="10" aria-label="' . esc_attr__( 'Support diagnostics', 'order-edit-guard-for-woocommerce' ) . '">' . esc_textarea( $this->diagnostics() ) . '</textarea><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'editharbor_maintenance' );
		echo '<input type="hidden" name="action" value="editharbor_maintenance"><p><label><input type="checkbox" name="confirm_cleanup" value="1"> ' . esc_html__( 'Remove up to 100 audit groups whose orders have been deleted. This permanently deletes their history.', 'order-edit-guard-for-woocommerce' ) . '</label></p>';
		submit_button( __( 'Run maintenance / database upgrade', 'order-edit-guard-for-woocommerce' ), 'secondary' );
		echo '</form></div>';
	}
	private function setting_row( $key, $value ) {
		$labels = array(
			'enabled'          => __( 'Enable auditing', 'order-edit-guard-for-woocommerce' ),
			'manual'           => __( 'Audit manual order edits', 'order-edit-guard-for-woocommerce' ),
			'automated'        => __( 'Audit automated changes', 'order-edit-guard-for-woocommerce' ),
			'order_notes'      => __( 'Add one order note per group', 'order-edit-guard-for-woocommerce' ),
			'reason_mode'      => __( 'Require a reason', 'order-edit-guard-for-woocommerce' ),
			'reason_statuses'  => __( 'Statuses requiring a reason', 'order-edit-guard-for-woocommerce' ),
			'reason_min'       => __( 'Minimum reason length', 'order-edit-guard-for-woocommerce' ),
			'reason_max'       => __( 'Maximum reason length', 'order-edit-guard-for-woocommerce' ),
			'warn_paid'        => __( 'Warn when editing paid orders', 'order-edit-guard-for-woocommerce' ),
			'warning_statuses' => __( 'Protected statuses (warning mode)', 'order-edit-guard-for-woocommerce' ),
			'log_ip'           => __( 'Log IP addresses', 'order-edit-guard-for-woocommerce' ),
			'mask_display'     => __( 'Mask personal data in audit display', 'order-edit-guard-for-woocommerce' ),
			'retain_personal'  => __( 'Retain personal audit values', 'order-edit-guard-for-woocommerce' ),
			'delete_data'      => __( 'Delete plugin data on uninstall', 'order-edit-guard-for-woocommerce' ),
			'per_page'         => __( 'Groups per page', 'order-edit-guard-for-woocommerce' ),
			'date_display'     => __( 'Date display', 'order-edit-guard-for-woocommerce' ),
		);
		$name   = 'editharbor_settings[' . $key . ']';
		echo '<tr><th scope="row"><label for="editharbor-' . esc_attr( $key ) . '">' . esc_html( $labels[ $key ] ) . '</label></th><td>';
		if ( is_bool( $value ) ) {
			echo '<input id="editharbor-' . esc_attr( $key ) . '" type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . '>'; } elseif ( is_array( $value ) ) {
				echo '<select id="editharbor-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '[]" multiple size="7">';
			foreach ( wc_get_order_statuses() as $status => $label ) {
				$status = substr( $status, 3 );
				echo '<option value="' . esc_attr( $status ) . '" ' . selected( in_array( $status, $value, true ), true, false ) . '>' . esc_html( $label ) . '</option>'; }
					echo '</select>';
			} elseif ( in_array( $key, array( 'reason_mode', 'date_display' ), true ) ) {
				$options = 'reason_mode' === $key ? array(
					'disabled' => __( 'Disabled', 'order-edit-guard-for-woocommerce' ),
					'all'      => __( 'All manual admin edits', 'order-edit-guard-for-woocommerce' ),
					'statuses' => __( 'Selected statuses', 'order-edit-guard-for-woocommerce' ),
				) : array(
					'local' => __( 'Site timezone', 'order-edit-guard-for-woocommerce' ),
					'utc'   => __( 'UTC', 'order-edit-guard-for-woocommerce' ),
				);
				echo '<select id="editharbor-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">';
				foreach ( $options as $option => $label ) {
					echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $label ) . '</option>'; }
				echo '</select>';
			} else {
				echo '<input id="editharbor-' . esc_attr( $key ) . '" type="number" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">'; }
			echo '</td></tr>';
	}
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Current diagnostics and explicit cleanup of plugin-owned tables.
	public function diagnostics() {
		global $wpdb;
		$hpos = \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		return implode( "\n", array( 'EditHarbor: ' . EDHB_VERSION, 'Pro: ' . ( defined( 'EDHB_PRO_VERSION' ) ? EDHB_PRO_VERSION : 'inactive' ), 'WordPress: ' . get_bloginfo( 'version' ), 'WooCommerce: ' . WC_VERSION, 'PHP: ' . PHP_VERSION, 'HPOS: ' . ( $hpos ? 'yes' : 'no' ), 'DB schema: ' . get_option( 'editharbor_db_version', 'missing' ), 'Events: ' . $this->plugin->get( 'repository' )->count(), 'Changes: ' . $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $this->plugin->get( 'repository' )->table( 'changes' ) ) ), 'WP Cron disabled: ' . ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'yes' : 'no' ), 'Last error: ' . wp_json_encode( get_option( 'editharbor_last_error', null ) ) ) );
	}	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Current diagnostics and explicit cleanup of plugin-owned tables.
	public function maintenance() {
		$this->authorize( 'editharbor_manage_settings' );
		check_admin_referer( 'editharbor_maintenance' );
		\EDHB\Database\Installer::install();
		if ( isset( $_POST['confirm_cleanup'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['confirm_cleanup'] ) ) ) {
			global $wpdb;
			$repository = $this->plugin->get( 'repository' );
			$cursor     = absint( get_option( 'editharbor_orphan_cursor', 0 ) );
			$events     = $repository->query( array( 'after_id' => $cursor ), 1, 100, true );
			foreach ( $events as $event ) {
				$cursor = $event['id'];
				if ( wc_get_order( $event['order_id'] ) || ! $event['order_id'] ) {
					continue; }
				do_action( 'editharbor_before_event_delete', $event['id'], 'orphan_cleanup' );
				$wpdb->delete( $repository->table( 'changes' ), array( 'event_id' => $event['id'] ) );
				$wpdb->delete( $repository->table( 'identities' ), array( 'event_id' => $event['id'] ) );
				$wpdb->delete( $repository->table( 'events' ), array( 'id' => $event['id'] ) );
			}
			update_option( 'editharbor_orphan_cursor', count( $events ) < 100 ? 0 : $cursor, false );
			delete_transient( 'editharbor_stats' );
		}
		delete_option( 'editharbor_last_error' );
		if ( wp_doing_ajax() ) {
			wp_send_json_success(
				array(
					'message'     => __( 'Database check complete.', 'order-edit-guard-for-woocommerce' ),
					'diagnostics' => $this->diagnostics(),
				)
			); }
		wp_safe_redirect( admin_url( 'admin.php?page=editharbor-settings' ) );
		exit;
	}	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	private function authorize( $capability ) {
		if ( ! current_user_can( $capability ) ) {
			wp_die( esc_html__( 'Access denied.', 'order-edit-guard-for-woocommerce' ), '', array( 'response' => 403 ) ); }
	}
}
