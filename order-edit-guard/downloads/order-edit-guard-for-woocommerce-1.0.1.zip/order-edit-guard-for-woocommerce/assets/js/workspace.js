/* Single-page settings, retained form state and asynchronous saves. */
(function ($) {
 'use strict';
 const root = document.querySelector('.oeg-workspace');
 if (!root) return;
 const panels = root.querySelector('.oeg-panels');
 const tabs = Array.from(root.querySelectorAll('[role="tab"]'));
 const loading = root.querySelector('.oeg-loading');
 const toast = root.querySelector('.oeg-toast');
 let request, toastTimer, active = panels.firstElementChild.dataset.section;
 let desired = active;
 const dirty = new Set();
 function message(text, error) {
  toast.textContent = text; toast.classList.toggle('oeg-toast-error', !!error); toast.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(function () { toast.hidden = true; }, error ? 10000 : 3500);
 }
 function formState(form) { return $(form).serialize(); }
 function initialize(section) {
  dirty.delete(section.dataset.section);
  root.querySelector('#oeg-tab-' + section.dataset.section).classList.remove('oeg-is-dirty');
  section.querySelectorAll('.oeg-settings-form').forEach(function (form) { form.dataset.baseline = formState(form); });
  conditional(section);
  document.dispatchEvent(new CustomEvent('oeg:panel', {detail: section}));
 }
 function conditional(section) {
  const mode = section.querySelector('[name="oeg_settings[reason_mode]"]');
  const statuses = section.querySelector('[data-field="reason_statuses"]');
  if (mode && statuses) statuses.hidden = mode.value !== 'statuses';
 }
 function mark(form) {
  const section = form.closest('[role="tabpanel"]').dataset.section;
  const changed = formState(form) !== form.dataset.baseline;
  if (changed) dirty.add(section); else dirty.delete(section);
  root.querySelector('#oeg-tab-' + section).classList.toggle('oeg-is-dirty', changed);
  form.querySelector('.oeg-save-state').textContent = changed ? oegWorkspace.dirty : oegWorkspace.saved;
 }
 function select(section, updateHistory) {
  active = section;
  panels.querySelectorAll('[role="tabpanel"]').forEach(function (panel) { panel.hidden = panel.dataset.section !== section; });
  tabs.forEach(function (tab) { const selected = tab.dataset.section === section; tab.setAttribute('aria-selected', selected); tab.tabIndex = selected ? 0 : -1; });
  if (updateHistory) { const url = new URL(window.location); url.search = ''; url.searchParams.set('page','oeg'); url.searchParams.set('section',section); const panel = panels.querySelector('#oeg-section-' + section); Object.entries(panel.oegParams || {}).forEach(function (pair) { if (!['action','nonce','page','section'].includes(pair[0])) url.searchParams.set(pair[0],pair[1]); }); history.replaceState({},'',url); }
 }
 function load(section, params, force) {
  desired = section;
  const cached = panels.querySelector('#oeg-section-' + section);
  if (cached && cached.oegStale) { force = true; params = params || cached.oegParams || {}; }
  if (cached && !force && ['overview','audit','pro-approvals','pro-reports','maintenance'].includes(section)) { force = true; params = cached.oegParams || {}; }
  if (cached && !force) { select(section, true); return; }
  if (request) request.abort();
  loading.hidden = false; root.querySelector('.oeg-main').setAttribute('aria-busy','true');
  request = $.ajax({url: oegWorkspace.url, method: 'GET', data: Object.assign({},params || {},{action:'oeg_workspace_panel',nonce:oegWorkspace.nonce,section:section})});
  request.done(function (response) {
   if (!response.success) { message(response.data.message || oegWorkspace.error,true); return; }
   const panel = document.createElement('section'); panel.id = 'oeg-section-' + section; panel.dataset.section = section;
   panel.setAttribute('role','tabpanel'); panel.setAttribute('aria-labelledby','oeg-tab-' + section); panel.tabIndex = 0;
   panel.innerHTML = response.data.html; panel.oegParams = params || {};
   if (cached) cached.replaceWith(panel); else panels.appendChild(panel);
   initialize(panel); select(section,true);
   if (params) { const url = new URL(window.location); Object.entries(params).forEach(function (pair) { if (!['action','nonce'].includes(pair[0])) url.searchParams.set(pair[0],pair[1]); }); history.replaceState({},'',url); }
  }).fail(function (xhr,status) { if (status !== 'abort') message((xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || oegWorkspace.error,true); }).always(function () { loading.hidden = true; root.querySelector('.oeg-main').removeAttribute('aria-busy'); request = null; });
 }
 tabs.forEach(function (tab) {
  tab.addEventListener('click',function () { load(tab.dataset.section); });
  tab.addEventListener('keydown',function (event) {
   let index = tabs.indexOf(tab);
   if (['ArrowDown','ArrowRight','ArrowUp','ArrowLeft','Home','End'].includes(event.key)) {
    event.preventDefault();
    index = event.key === 'Home' ? 0 : (event.key === 'End' ? tabs.length - 1 : (index + (['ArrowDown','ArrowRight'].includes(event.key) ? 1 : -1) + tabs.length) % tabs.length);
    tabs[index].focus(); load(tabs[index].dataset.section);
   }
  });
 });
 root.addEventListener('input', function (event) { const form = event.target.closest('.oeg-settings-form'); if (form) mark(form); });
 root.addEventListener('change', function (event) {
  const filters = event.target.closest('.oeg-filter-card');
  if (filters && ['from','to'].includes(event.target.name)) filters.querySelector('[name="range"]').value = 'custom';
  const form = event.target.closest('.oeg-settings-form'); if (form) { conditional(form); mark(form); } });
 root.addEventListener('submit', function (event) {
  const form = event.target;
  if (form.method.toLowerCase() === 'get') {
   event.preventDefault(); const params = Object.fromEntries(new FormData(form).entries()); const section = params.section || active; delete params.page; load(section,params,true); return;
  }
  const settings = form.matches('.oeg-settings-form');
  const operation = form.querySelector('[name="action"]');
  if (!settings && (!operation || !['oeg_maintenance','oeg_pro_action'].includes(operation.value))) return;
  event.preventDefault();
  if (!form.reportValidity()) return;
  if (form.dataset.saving === 'true') return;
  const origin = form.closest('[role="tabpanel"]'); const actionSection = origin.dataset.section; const actionParams = Object.assign({},origin.oegParams || {});
  const submitter = event.submitter || form.querySelector('[type="submit"]'); const status = form.querySelector('.oeg-save-state');
  const data = new FormData(form);
  if (event.submitter && event.submitter.name) data.set(event.submitter.name,event.submitter.value);
  data.set('action', settings ? form.dataset.action : operation.value);
  data.set('nonce',oegWorkspace.nonce);
  if (settings) data.set('section',form.dataset.section);
  const snapshot = formState(form);
  form.dataset.saving = 'true'; if (submitter) submitter.disabled = true; if (status) status.textContent = oegWorkspace.saving;
  $.ajax({url:oegWorkspace.url,method:'POST',data:data,processData:false,contentType:false}).done(function (response) {
   if (!response.success) { message(response.data.message || oegWorkspace.error,true); if (settings) form.querySelector('.oeg-reload-section').hidden = false; return; }
   if (settings) {
    form.querySelector('[name="revision"]').value = response.data.revision;
    if (formState(form).replace(/revision=[^&]*/,'') === snapshot.replace(/revision=[^&]*/,'')) {
     if (response.data.settings) form.querySelectorAll('[name^="oeg_settings["]').forEach(function (input) {
      const match = input.name.match(/^oeg_settings\[([^\]]+)\]/); const value = response.data.settings[match[1]];
      if (input.type === 'checkbox') input.checked = Array.isArray(value) ? value.includes(input.value) : !!value;
      else input.value = value;
     });
     if (response.data.html) {
      const canonical = document.createElement('div'); canonical.innerHTML = response.data.html;
      const savedForm = canonical.querySelector('.oeg-settings-form');
      if (savedForm) { form.innerHTML = savedForm.innerHTML; document.dispatchEvent(new CustomEvent('oeg:panel',{detail:form})); }
     }
     form.dataset.baseline = formState(form);
    }
    mark(form);
    const enabled = response.data.settings && response.data.settings.enabled;
    if (typeof enabled === 'boolean') { root.querySelector('.oeg-header-state').classList.toggle('oeg-paused',!enabled); root.querySelector('.oeg-header-state-label').textContent = enabled ? oegWorkspace.auditingOn : oegWorkspace.auditingPaused; }
   } else {
    if (response.data.verify_page) actionParams.verify_page = response.data.verify_page;
    if (desired === actionSection) load(actionSection,actionParams,true);
    else origin.oegStale = true;
   }
   message(response.data.message || oegWorkspace.saved,false);
  }).fail(function (xhr) { if (settings && xhr.status === 409) form.querySelector('.oeg-reload-section').hidden = false; message((xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || oegWorkspace.error,true); }).always(function () {
   form.dataset.saving = 'false'; if (submitter) submitter.disabled = false; if (settings) mark(form); else if (status) status.textContent = '';
  });
 });
 root.addEventListener('click', function (event) {
  const reload = event.target.closest('.oeg-reload-section');
  if (reload) { const panel = reload.closest('[role="tabpanel"]'); if (!dirty.has(panel.dataset.section) || window.confirm(oegWorkspace.reloadConfirm)) load(panel.dataset.section,panel.oegParams || {},true); return; }
  const copy = event.target.closest('.oeg-copy-diagnostics');
  if (copy) {
   const diagnostics = root.querySelector('.oeg-diagnostics');
   if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(diagnostics.value).then(function () { message(oegWorkspace.copied); }).catch(function () { message(oegWorkspace.error,true); });
   else {
    const temporary = document.createElement('textarea'); temporary.value = diagnostics.value; temporary.style.position = 'fixed'; temporary.style.opacity = '0'; document.body.appendChild(temporary); temporary.select();
    let copied = false; try { copied = document.execCommand('copy'); } catch (_) {} temporary.remove(); copy.focus(); message(copied ? oegWorkspace.copied : oegWorkspace.error,!copied);
   }
  }
  const link = event.target.closest('a');
  if (!link || event.ctrlKey || event.metaKey || link.target === '_blank') return;
  const url = new URL(link.href,window.location);
  const legacy = {'oeg-audit':'audit','oeg-pro-reports':'pro-reports','oeg-pro-approvals':'pro-approvals'};
  const section = url.searchParams.get('section') || legacy[url.searchParams.get('page')];
  if (url.origin === window.location.origin && section && tabs.some(function (tab) { return tab.dataset.section === section; })) {
   event.preventDefault(); const params = Object.fromEntries(url.searchParams); delete params.page; load(section,params,true);
  }
 });
 window.addEventListener('beforeunload',function (event) { if (dirty.size) { event.preventDefault(); event.returnValue = ''; } });
 panels.firstElementChild.oegParams = Object.fromEntries(new URL(window.location).searchParams);
 initialize(panels.firstElementChild);
})(jQuery);
