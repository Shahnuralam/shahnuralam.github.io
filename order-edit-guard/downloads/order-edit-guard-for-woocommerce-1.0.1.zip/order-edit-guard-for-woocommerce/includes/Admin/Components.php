<?php
/**
 * Shared, accessible workspace presentation.
 *
 * @package OEG
 */
namespace OEG\Admin;

defined( 'ABSPATH' ) || exit;

/** Small native HTML components shared by Free and extensions. */
final class Components {
	/** Render a page introduction. */
	public static function heading( $label, $title, $description ) {
		echo '<div class="oeg-section-header"><span class="oeg-eyebrow">' . esc_html( $label ) . '</span><h2>' . esc_html( $title ) . '</h2><p>' . esc_html( $description ) . '</p></div>';
	}

	/** Render a labelled count with explanatory text. */
	public static function metric( $label, $value, $description, $icon = 'chart-bar' ) {
		echo '<div class="oeg-metric"><span class="oeg-metric-label"><span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span>' . esc_html( $label ) . '</span><strong>' . esc_html( number_format_i18n( (int) $value ) ) . '</strong><span class="oeg-metric-help">' . esc_html( $description ) . '</span></div>';
	}

	/** Explain an empty result with a useful next step. */
	public static function empty_state( $title, $description, $icon = 'clipboard' ) {
		echo '<div class="oeg-empty"><span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $description ) . '</p></div>';
	}

	/** Friendly names for recorded operation origins. */
	public static function sources() {
		return array(
			'wc_admin'         => __( 'Order editor', 'order-edit-guard-for-woocommerce' ),
			'ajax'             => __( 'Admin item editor', 'order-edit-guard-for-woocommerce' ),
			'rest'             => __( 'API / integration', 'order-edit-guard-for-woocommerce' ),
			'store_api'        => __( 'Store checkout API', 'order-edit-guard-for-woocommerce' ),
			'checkout'         => __( 'Checkout', 'order-edit-guard-for-woocommerce' ),
			'cron'             => __( 'Scheduled task', 'order-edit-guard-for-woocommerce' ),
			'action_scheduler' => __( 'WooCommerce background task', 'order-edit-guard-for-woocommerce' ),
			'wp_cli'           => __( 'Command line', 'order-edit-guard-for-woocommerce' ),
			'unknown'          => __( 'Other / unknown source', 'order-edit-guard-for-woocommerce' ),
		);
	}

	/** Readable event labels retain machine identifiers in storage. */
	public static function event_label( $type ) {
		$labels = array(
			'order_updated'      => __( 'Order edited', 'order-edit-guard-for-woocommerce' ),
			'order_locked'       => __( 'Order locked', 'order-edit-guard-for-woocommerce' ),
			'order_unlocked'     => __( 'Order unlocked', 'order-edit-guard-for-woocommerce' ),
			'order_relocked'     => __( 'Order locked again', 'order-edit-guard-for-woocommerce' ),
			'approval_requested' => __( 'Approval requested', 'order-edit-guard-for-woocommerce' ),
			'approval_approved'  => __( 'Change approved', 'order-edit-guard-for-woocommerce' ),
			'approval_rejected'  => __( 'Change rejected', 'order-edit-guard-for-woocommerce' ),
			'approval_cancelled' => __( 'Request cancelled', 'order-edit-guard-for-woocommerce' ),
			'restore_performed'  => __( 'Previous values restored', 'order-edit-guard-for-woocommerce' ),
			'order_restored'     => __( 'Previous values restored', 'order-edit-guard-for-woocommerce' ),
			'values_restored'    => __( 'Previous values restored', 'order-edit-guard-for-woocommerce' ),
			'logs_cleaned'       => __( 'Old history removed', 'order-edit-guard-for-woocommerce' ),
			'unusual_activity'   => __( 'Activity needs review', 'order-edit-guard-for-woocommerce' ),
		);
		return $labels[ $type ] ?? ucwords( str_replace( '_', ' ', $type ) );
	}

	/** Friendly status text for approvals and deliveries. */
	public static function status_label( $status ) {
		$labels = array(
			'pending'   => __( 'Awaiting review', 'order-edit-guard-for-woocommerce' ),
			'applying'  => __( 'Applying changes', 'order-edit-guard-for-woocommerce' ),
			'approved'  => __( 'Approved', 'order-edit-guard-for-woocommerce' ),
			'rejected'  => __( 'Rejected', 'order-edit-guard-for-woocommerce' ),
			'cancelled' => __( 'Cancelled', 'order-edit-guard-for-woocommerce' ),
			'failed'    => __( 'Needs attention', 'order-edit-guard-for-woocommerce' ),
			'sending'   => __( 'Sending', 'order-edit-guard-for-woocommerce' ),
			'delivered' => __( 'Delivered', 'order-edit-guard-for-woocommerce' ),
		);
		return $labels[ $status ] ?? ucwords( str_replace( '_', ' ', $status ) );
	}

	/** A text badge conveys state without relying on color. */
	public static function badge( $label, $state = 'neutral' ) {
		echo '<span class="oeg-status-pill oeg-status-' . esc_attr( sanitize_key( $state ) ) . '">' . esc_html( $label ) . '</span>';
	}
}
