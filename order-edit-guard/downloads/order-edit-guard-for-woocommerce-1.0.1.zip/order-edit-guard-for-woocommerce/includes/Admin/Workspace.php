<?php
/** One-page administration with section-scoped asynchronous settings. @package OEG */
namespace OEG\Admin;

defined( 'ABSPATH' ) || exit;
final class Workspace {
	private $plugin;
	public function __construct( $plugin ) {
		$this->plugin = $plugin; }
	public function register() {
		add_action( 'wp_ajax_oeg_workspace_panel', array( $this, 'panel_ajax' ) );
		add_action( 'wp_ajax_oeg_save_settings', array( $this, 'save_ajax' ) );
		add_action( 'admin_init', array( $this, 'redirect_legacy' ) );
	}
	public function tabs() {
		return apply_filters(
			'oeg_admin_tabs',
			array(
				'overview'    => array(
					'label'      => __( 'Overview', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'dashboard',
					'group'      => 'activity',
					'capability' => 'oeg_view_all_audits',
				),
				'audit'       => array(
					'label'      => __( 'Audit history', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'clock',
					'group'      => 'activity',
					'capability' => 'oeg_view_all_audits',
				),
				'general'     => array(
					'label'      => __( 'General', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'admin-settings',
					'group'      => 'settings',
					'capability' => 'oeg_manage_settings',
				),
				'reasons'     => array(
					'label'      => __( 'Change reasons', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'edit',
					'group'      => 'settings',
					'capability' => 'oeg_manage_settings',
				),
				'warnings'    => array(
					'label'      => __( 'Order protection', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'shield',
					'group'      => 'settings',
					'capability' => 'oeg_manage_settings',
				),
				'privacy'     => array(
					'label'      => __( 'Privacy & data', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'privacy',
					'group'      => 'settings',
					'capability' => 'oeg_manage_settings',
				),
				'maintenance' => array(
					'label'      => __( 'System status', 'order-edit-guard-for-woocommerce' ),
					'icon'       => 'heart',
					'group'      => 'settings',
					'capability' => 'oeg_manage_settings',
				),
			)
		);
	}
	public function sections() {
		return array(
			'general'  => array( 'enabled', 'manual', 'automated', 'order_notes', 'date_display', 'per_page' ),
			'reasons'  => array( 'reason_mode', 'reason_statuses', 'reason_min', 'reason_max' ),
			'warnings' => array( 'warn_paid', 'warning_statuses' ),
			'privacy'  => array( 'log_ip', 'mask_display', 'retain_personal', 'delete_data' ),
		);
	}
	private function access( $section ) {
		$tabs = $this->tabs();
		return isset( $tabs[ $section ] ) && current_user_can( $tabs[ $section ]['capability'] ); }
	public function menu() {
		add_menu_page( __( 'Order Edit Guard', 'order-edit-guard-for-woocommerce' ), __( 'Order Edit Guard', 'order-edit-guard-for-woocommerce' ), 'oeg_view_order_audit', 'oeg', array( $this, 'page' ), 'dashicons-shield', 56 );
	}
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL controls; screen access is capability checked.
	public function redirect_legacy() {
		if ( wp_doing_ajax() || ! isset( $_GET['page'] ) ) {
			return; }
		$page = sanitize_key( wp_unslash( $_GET['page'] ) );
		$map  = array(
			'oeg-audit'         => 'audit',
			'oeg-settings'      => 'general',
			'oeg-pro-settings'  => 'pro-rules',
			'oeg-pro-approvals' => 'pro-approvals',
			'oeg-pro-reports'   => 'pro-reports',
		);
		if ( isset( $map[ $page ] ) ) {
			$query            = array_map( 'sanitize_text_field', wp_unslash( $_GET ) );
			$query['page']    = 'oeg';
			$query['section'] = $map[ $page ];
			wp_safe_redirect( add_query_arg( $query, admin_url( 'admin.php' ) ) );
			exit; }
	}	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL controls; screen access is capability checked.
	public function page() {
		$tabs = array_filter(
			$this->tabs(),
			static function ( $tab ) {
				return current_user_can( $tab['capability'] );
			}
		);
		if ( ! $tabs ) {
			wp_die( esc_html__( 'Open an order to view its edit history.', 'order-edit-guard-for-woocommerce' ) ); }
		$section = isset( $_GET['section'] ) && is_scalar( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : key( $tabs );
		if ( ! isset( $tabs[ $section ] ) ) {
			$section = key( $tabs ); }
		echo '<div class="wrap oeg-workspace"><h1 class="screen-reader-text">Order Edit Guard</h1><div class="oeg-workspace-header"><div class="oeg-wordmark"><span class="oeg-brand-icon dashicons dashicons-shield" aria-hidden="true"></span><div><h2>' . esc_html__( 'Order Edit Guard', 'order-edit-guard-for-woocommerce' ) . '</h2><p>' . esc_html__( 'A little more confidence in every order change.', 'order-edit-guard-for-woocommerce' ) . '</p></div></div><div class="oeg-header-state' . ( $this->plugin->get( 'settings' )->get( 'enabled' ) ? '' : ' oeg-paused' ) . '"><span class="oeg-state-dot" aria-hidden="true"></span><span class="oeg-header-state-label">' . esc_html( $this->plugin->get( 'settings' )->get( 'enabled' ) ? __( 'Auditing is on', 'order-edit-guard-for-woocommerce' ) : __( 'Auditing is paused', 'order-edit-guard-for-woocommerce' ) ) . '</span></div></div><div class="oeg-workspace-layout"><aside class="oeg-sidebar"><nav role="tablist" aria-label="' . esc_attr__( 'Order Edit Guard sections', 'order-edit-guard-for-woocommerce' ) . '" aria-orientation="vertical">';
		$group = '';
		foreach ( $tabs as $key => $tab ) {
			if ( $group !== $tab['group'] ) {
				$group = $tab['group'];
				echo '<p class="oeg-nav-label">' . esc_html( 'activity' === $group ? __( 'Your store', 'order-edit-guard-for-woocommerce' ) : ( 'settings' === $group ? __( 'Settings', 'order-edit-guard-for-woocommerce' ) : __( 'Pro tools', 'order-edit-guard-for-woocommerce' ) ) ) . '</p>'; }
			echo '<button type="button" id="oeg-tab-' . esc_attr( $key ) . '" role="tab" aria-controls="oeg-section-' . esc_attr( $key ) . '" aria-selected="' . ( $key === $section ? 'true' : 'false' ) . '" tabindex="' . ( $key === $section ? '0' : '-1' ) . '" data-section="' . esc_attr( $key ) . '"><span class="dashicons dashicons-' . esc_attr( $tab['icon'] ) . '" aria-hidden="true"></span><span>' . esc_html( $tab['label'] ) . '</span><span class="oeg-dirty-indicator" aria-hidden="true"></span></button>';
		}
		echo '</nav><div class="oeg-sidebar-note"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><p>' . esc_html__( 'Order changes are recorded. Payments are never collected or refunded by this plugin.', 'order-edit-guard-for-woocommerce' ) . '</p></div><span class="oeg-version">v' . esc_html( OEG_VERSION ) . '</span></aside><main class="oeg-main"><div class="oeg-loading" role="status" hidden>' . esc_html__( 'Loading your settings…', 'order-edit-guard-for-woocommerce' ) . '</div><div class="oeg-panels"><section id="oeg-section-' . esc_attr( $section ) . '" data-section="' . esc_attr( $section ) . '" role="tabpanel" aria-labelledby="oeg-tab-' . esc_attr( $section ) . '" tabindex="0">';
		$this->content( $section );
		echo '</section></div><div class="oeg-toast" role="status" aria-live="polite" hidden></div></main></div></div>';
	}	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	public function panel_ajax() {
		check_ajax_referer( 'oeg_workspace', 'nonce' );
		$section = isset( $_GET['section'] ) && is_scalar( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : '';
		if ( ! $this->access( $section ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have access to this section.', 'order-edit-guard-for-woocommerce' ) ), 403 ); }
		ob_start();
		$this->content( $section );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}
	public function revision( $section, $settings = null ) {
		$settings = $settings ?? $this->plugin->get( 'settings' )->all();
		return hash( 'sha256', wp_json_encode( array_intersect_key( $settings, array_flip( $this->sections()[ $section ] ?? array() ) ) ) );
	}
	public function save_ajax() {
		check_ajax_referer( 'oeg_workspace', 'nonce' );
		if ( ! current_user_can( 'oeg_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot change these settings.', 'order-edit-guard-for-woocommerce' ) ), 403 ); }
		$section = isset( $_POST['section'] ) && is_scalar( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';
		if ( ! isset( $this->sections()[ $section ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown settings section.', 'order-edit-guard-for-woocommerce' ) ), 400 ); }
		$revision = isset( $_POST['revision'] ) && is_scalar( $_POST['revision'] ) ? sanitize_text_field( wp_unslash( $_POST['revision'] ) ) : '';
		if ( ! isset( $_POST['oeg_settings'] ) || ! is_array( $_POST['oeg_settings'] ) ) {
			wp_send_json_error( array( 'message' => __( 'The settings payload is invalid.', 'order-edit-guard-for-woocommerce' ) ), 400 );
		}
		$posted = map_deep( wp_unslash( $_POST['oeg_settings'] ), 'sanitize_text_field' );
		$result   = \OEG\Support\Settings_Lock::update(
			'oeg_settings',
			function () use ( $section, $revision, $posted ) {
				if ( ! hash_equals( $this->revision( $section ), $revision ) ) {
					return new \WP_Error( 'oeg_settings_stale', __( 'These settings were changed in another session. Reload this section and review your changes.', 'order-edit-guard-for-woocommerce' ), array( 'status' => 409 ) );
				}
				$current  = $this->plugin->get( 'settings' )->all();
				$defaults = $this->plugin->get( 'settings' )->defaults();
				foreach ( $this->sections()[ $section ] as $key ) {
					$current[ $key ] = $posted[ $key ] ?? ( is_array( $defaults[ $key ] ) ? array() : ( is_bool( $defaults[ $key ] ) ? false : $defaults[ $key ] ) ); }
				$clean = $this->plugin->get( 'settings' )->sanitize( $current );
				update_option( 'oeg_settings', $clean, false );
				if ( get_option( 'oeg_settings' ) !== $clean ) {
					return new \WP_Error( 'oeg_settings_failed', __( 'The database could not save your settings. Please try again.', 'order-edit-guard-for-woocommerce' ), array( 'status' => 500 ) ); }
				return array(
					'message'  => __( 'Your settings are saved.', 'order-edit-guard-for-woocommerce' ),
					'revision' => $this->revision( $section, $clean ),
					'settings' => $clean,
				);
			}
		);
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), $result->get_error_data()['status'] ?? 500 ); }
		wp_send_json_success( $result );
	}
	public function content( $section ) {
		if ( ! $this->access( $section ) ) {
			return; }
		if ( 'overview' === $section ) {
			$this->plugin->get( 'admin' )->dashboard();
			return; }
		if ( 'audit' === $section ) {
			$this->plugin->get( 'admin' )->audit();
			return; }
		if ( 0 === strpos( $section, 'pro-' ) ) {
			do_action( 'oeg_admin_tab_content', $section );
			return; }
		if ( 'maintenance' === $section ) {
			$this->maintenance();
			return; }
		$copy = array(
			'general'  => array( __( 'Make every change traceable.', 'order-edit-guard-for-woocommerce' ), __( 'Choose which order changes to record and how your history is displayed.', 'order-edit-guard-for-woocommerce' ) ),
			'reasons'  => array( __( 'Give every edit a reason.', 'order-edit-guard-for-woocommerce' ), __( 'Help your team remember why an order changed. Automated operations keep running normally.', 'order-edit-guard-for-woocommerce' ) ),
			'warnings' => array( __( 'Add a pause before important edits.', 'order-edit-guard-for-woocommerce' ), __( 'Friendly warnings help staff review changes to paid or finished orders.', 'order-edit-guard-for-woocommerce' ) ),
			'privacy'  => array( __( 'Keep useful history. Protect personal data.', 'order-edit-guard-for-woocommerce' ), __( 'Control what your audit history retains and what your team can see.', 'order-edit-guard-for-woocommerce' ) ),
		);
		$tabs = $this->tabs();
		echo '<div class="oeg-section-header"><span class="oeg-eyebrow">' . esc_html( $tabs[ $section ]['label'] ) . '</span><h2>' . esc_html( $copy[ $section ][0] ) . '</h2><p>' . esc_html( $copy[ $section ][1] ) . '</p></div><form method="post" class="oeg-settings-form" data-section="' . esc_attr( $section ) . '" data-action="oeg_save_settings"><input type="hidden" name="revision" value="' . esc_attr( $this->revision( $section ) ) . '">';
		$s = $this->plugin->get( 'settings' )->all();
		foreach ( $this->sections()[ $section ] as $key ) {
			$this->field( $key, $s[ $key ] ); }
		if ( 'warnings' === $section ) {
			$this->callout( __( 'An order total is different from the amount collected.', 'order-edit-guard-for-woocommerce' ), __( 'Editing a paid order will never automatically charge the difference or issue a refund. Always review payment and fulfillment separately.', 'order-edit-guard-for-woocommerce' ) ); }
		if ( 'privacy' === $section ) {
			$this->callout( __( 'Privacy requests are handled by WordPress.', 'order-edit-guard-for-woocommerce' ), __( 'Use Tools → Export Personal Data or Erase Personal Data to process customer requests. These settings affect audit history, not the actual order.', 'order-edit-guard-for-woocommerce' ) ); }
		$this->save_bar();
		echo '</form>';
	}
	public function save_bar() {
		echo '<footer class="oeg-save-bar"><div class="oeg-save-status"><span class="oeg-save-state" role="status" aria-live="polite">' . esc_html__( 'All changes saved', 'order-edit-guard-for-woocommerce' ) . '</span><button type="button" class="button-link oeg-reload-section" hidden>' . esc_html__( 'Reload saved settings', 'order-edit-guard-for-woocommerce' ) . '</button></div><button type="submit" class="oeg-save-button"><span class="dashicons dashicons-saved" aria-hidden="true"></span>' . esc_html__( 'Save changes', 'order-edit-guard-for-woocommerce' ) . '</button></footer>'; }
	public function callout( $title, $text ) {
		echo '<div class="oeg-callout"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><div><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $text ) . '</p></div></div>'; }
	public function field( $key, $value ) {
		$copy = array(
			'enabled'          => array( __( 'Order auditing', 'order-edit-guard-for-woocommerce' ), __( 'Keep a clear history of meaningful changes to existing orders.', 'order-edit-guard-for-woocommerce' ) ),
			'manual'           => array( __( 'Changes made by your team', 'order-edit-guard-for-woocommerce' ), __( 'Record order edits made by administrators and shop managers.', 'order-edit-guard-for-woocommerce' ) ),
			'automated'        => array( __( 'Changes from apps & automations', 'order-edit-guard-for-woocommerce' ), __( 'Include API, scheduled task and integration changes when their source is known.', 'order-edit-guard-for-woocommerce' ) ),
			'order_notes'      => array( __( 'Add a short order note', 'order-edit-guard-for-woocommerce' ), __( 'Add one summary per change group. Personal before-and-after values stay in the audit history.', 'order-edit-guard-for-woocommerce' ) ),
			'date_display'     => array( __( 'Time display', 'order-edit-guard-for-woocommerce' ), __( 'Choose the timezone used to show audit timestamps.', 'order-edit-guard-for-woocommerce' ) ),
			'per_page'         => array( __( 'History per page', 'order-edit-guard-for-woocommerce' ), __( 'Show between 5 and 100 change groups on each page.', 'order-edit-guard-for-woocommerce' ) ),
			'reason_mode'      => array( __( 'When should a reason be required?', 'order-edit-guard-for-woocommerce' ), __( 'Ask staff for a reason only when they make a meaningful change.', 'order-edit-guard-for-woocommerce' ) ),
			'reason_statuses'  => array( __( 'Orders that need a reason', 'order-edit-guard-for-woocommerce' ), __( 'Select the order statuses where staff must explain an edit.', 'order-edit-guard-for-woocommerce' ) ),
			'reason_min'       => array( __( 'Minimum reason length', 'order-edit-guard-for-woocommerce' ), __( 'Keep reasons meaningful. Default: 3 characters.', 'order-edit-guard-for-woocommerce' ) ),
			'reason_max'       => array( __( 'Maximum reason length', 'order-edit-guard-for-woocommerce' ), __( 'Keep explanations concise. Default: 500 characters.', 'order-edit-guard-for-woocommerce' ) ),
			'warn_paid'        => array( __( 'Warn before editing paid orders', 'order-edit-guard-for-woocommerce' ), __( 'Remind staff that financial edits do not change the money already collected.', 'order-edit-guard-for-woocommerce' ) ),
			'warning_statuses' => array( __( 'Protect important order statuses', 'order-edit-guard-for-woocommerce' ), __( 'Show a warning before manual edits to these statuses. Staff can continue after reviewing it.', 'order-edit-guard-for-woocommerce' ) ),
			'log_ip'           => array( __( 'Record IP addresses', 'order-edit-guard-for-woocommerce' ), __( 'Disabled by default. Enable only if your store needs this extra audit detail.', 'order-edit-guard-for-woocommerce' ) ),
			'mask_display'     => array( __( 'Mask personal details in history', 'order-edit-guard-for-woocommerce' ), __( 'Hide names, addresses and parts of email addresses and phone numbers in audit displays.', 'order-edit-guard-for-woocommerce' ) ),
			'retain_personal'  => array( __( 'Retain personal audit values', 'order-edit-guard-for-woocommerce' ), __( 'Keep previous and current customer details for review. Turning this off redacts new personal audit values.', 'order-edit-guard-for-woocommerce' ) ),
			'delete_data'      => array( __( 'Remove data when uninstalling', 'order-edit-guard-for-woocommerce' ), __( 'Permanently delete this plugin’s history and settings when the plugin is deleted. Keep off to preserve your records.', 'order-edit-guard-for-woocommerce' ) ),
		);
		$id   = 'oeg-setting-' . $key;
		$name = 'oeg_settings[' . $key . ']';
		echo '<div class="oeg-field-row' . ( is_bool( $value ) ? ' oeg-toggle-row' : '' ) . '" data-field="' . esc_attr( $key ) . '"><div class="oeg-field-copy"><label id="' . esc_attr( $id ) . '-label" for="' . esc_attr( $id ) . '">' . esc_html( $copy[ $key ][0] ) . '</label><p id="' . esc_attr( $id ) . '-help">' . esc_html( $copy[ $key ][1] ) . '</p></div><div class="oeg-field-control">';
		if ( is_bool( $value ) ) {
			echo '<label class="oeg-switch"><input id="' . esc_attr( $id ) . '" type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . ' aria-describedby="' . esc_attr( $id ) . '-help"><span aria-hidden="true"></span></label>';
		} elseif ( is_array( $value ) ) {
			echo '<fieldset aria-labelledby="' . esc_attr( $id ) . '-label" aria-describedby="' . esc_attr( $id ) . '-help" class="oeg-status-options"><legend class="screen-reader-text">' . esc_html( $copy[ $key ][0] ) . '</legend>';
			foreach ( wc_get_order_statuses() as $status => $label ) {
				$status = substr( $status, 3 );
				echo '<label class="oeg-status-choice"><input type="checkbox" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $status ) . '" ' . checked( in_array( $status, $value, true ), true, false ) . '><span>' . esc_html( $label ) . '</span></label>';
			} echo '</fieldset>';
		} elseif ( in_array( $key, array( 'reason_mode', 'date_display' ), true ) ) {
			$options = 'reason_mode' === $key ? array(
				'disabled' => __( 'Optional for all edits', 'order-edit-guard-for-woocommerce' ),
				'all'      => __( 'Required for all team edits', 'order-edit-guard-for-woocommerce' ),
				'statuses' => __( 'Required for selected statuses', 'order-edit-guard-for-woocommerce' ),
			) : array(
				'local' => __( 'Store timezone', 'order-edit-guard-for-woocommerce' ),
				'utc'   => __( 'UTC', 'order-edit-guard-for-woocommerce' ),
			);
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" aria-describedby="' . esc_attr( $id ) . '-help">';
			foreach ( $options as $option => $label ) {
					echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $label ) . '</option>';
			} echo '</select>';
		} else {
			$limits = array(
				'per_page'   => array( 5, 100 ),
				'reason_min' => array( 1, 100 ),
				'reason_max' => array( 1, 2000 ),
			);
			echo '<input id="' . esc_attr( $id ) . '" type="number" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" min="' . esc_attr( $limits[ $key ][0] ) . '" max="' . esc_attr( $limits[ $key ][1] ) . '" required aria-describedby="' . esc_attr( $id ) . '-help">';
		}
		echo '</div></div>';
	}
	private function maintenance() {
		Components::heading( __( 'System status', 'order-edit-guard-for-woocommerce' ), __( 'Check the health of your audit tools.', 'order-edit-guard-for-woocommerce' ), __( 'Review your store environment, check the audit database, and copy a support report without customer information.', 'order-edit-guard-for-woocommerce' ) );
		$labels = array(
			'Order Edit Guard' => __( 'Free plugin version', 'order-edit-guard-for-woocommerce' ),
			'Pro'              => __( 'Pro plugin version', 'order-edit-guard-for-woocommerce' ),
			'WordPress'        => __( 'WordPress version', 'order-edit-guard-for-woocommerce' ),
			'WooCommerce'      => __( 'WooCommerce version', 'order-edit-guard-for-woocommerce' ),
			'PHP'              => __( 'Server PHP version', 'order-edit-guard-for-woocommerce' ),
			'HPOS'             => __( 'Order storage', 'order-edit-guard-for-woocommerce' ),
			'DB schema'        => __( 'Audit database version', 'order-edit-guard-for-woocommerce' ),
			'Events'           => __( 'Saved change groups', 'order-edit-guard-for-woocommerce' ),
			'Changes'          => __( 'Saved field changes', 'order-edit-guard-for-woocommerce' ),
			'WP Cron disabled' => __( 'WordPress scheduled tasks', 'order-edit-guard-for-woocommerce' ),
			'Last error'       => __( 'Last reported issue', 'order-edit-guard-for-woocommerce' ),
		);
		echo '<div class="oeg-system-grid">';
		foreach ( explode( "\n", $this->plugin->get( 'admin' )->diagnostics() ) as $line ) {
			$parts = explode( ': ', $line, 2 );
			$value = $parts[1] ?? '';
			if ( 'HPOS' === $parts[0] ) {
				$value = 'yes' === $value ? __( 'High-performance order storage (HPOS)', 'order-edit-guard-for-woocommerce' ) : __( 'Legacy order storage', 'order-edit-guard-for-woocommerce' ); }
			if ( 'WP Cron disabled' === $parts[0] ) {
				$value = 'yes' === $value ? __( 'Disabled in configuration', 'order-edit-guard-for-woocommerce' ) : __( 'Enabled', 'order-edit-guard-for-woocommerce' ); }
			if ( 'Last error' === $parts[0] ) {
				$error = json_decode( $value, true );
				$value = empty( $error['code'] ) ? __( 'No issue reported', 'order-edit-guard-for-woocommerce' ) : ucwords( str_replace( '_', ' ', $error['code'] ) ); }
			if ( 'inactive' === $value ) {
				$value = __( 'Not active', 'order-edit-guard-for-woocommerce' ); }
			echo '<div><span>' . esc_html( $labels[ $parts[0] ] ?? $parts[0] ) . '</span><strong>' . esc_html( $value ) . '</strong></div>';
		}
		echo '</div><p><button class="button oeg-copy-diagnostics" type="button">' . esc_html__( 'Copy support report', 'order-edit-guard-for-woocommerce' ) . '</button></p><textarea class="oeg-diagnostics screen-reader-text" readonly>' . esc_textarea( $this->plugin->get( 'admin' )->diagnostics() ) . '</textarea><div class="oeg-card oeg-tool-card"><h3>' . esc_html__( 'Check your audit database', 'order-edit-guard-for-woocommerce' ) . '</h3><p>' . esc_html__( 'Check and repair the plugin’s database structure. Order data stays in WooCommerce. Removing history for deleted orders is optional and permanent.', 'order-edit-guard-for-woocommerce' ) . '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="oeg-tool-form">';
		wp_nonce_field( 'oeg_maintenance' );
		echo '<input type="hidden" name="action" value="oeg_maintenance"><label class="oeg-confirm"><input type="checkbox" name="confirm_cleanup" value="1"> ' . esc_html__( 'Also remove up to 100 history groups for deleted orders.', 'order-edit-guard-for-woocommerce' ) . '</label><button type="submit" class="button">' . esc_html__( 'Check / repair database', 'order-edit-guard-for-woocommerce' ) . '</button><span class="oeg-save-state" role="status" aria-live="polite"></span></form></div>';
	}
}
