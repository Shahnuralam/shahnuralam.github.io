<?php
/** Public service graph and deterministic bootstrap. @package OEG */
namespace OEG\Core;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static $instance;
	private $services = array();
	private $booted   = false;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function get( $key ) {
		return $this->services[ $key ] ?? null;
	}

	public function boot() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;
		if ( OEG_DB_VERSION !== get_option( 'oeg_db_version' ) ) {
			\OEG\Database\Installer::activate();
		}
		$s               = &$this->services;
		$s['settings']   = new Settings();
		$s['snapshot']   = new \OEG\Services\Order_Snapshot();
		$s['diff']       = new \OEG\Services\Order_Diff( $s['snapshot'] );
		$s['repository'] = new \OEG\Database\Event_Repository();
		$s['context']    = new \OEG\Services\Request_Context();
		$s['lock']       = new \OEG\Support\Order_Lock();
		$s['reason']     = new \OEG\Services\Change_Reason( $s['settings'], $s['context'] );
		$s['recorder']   = new \OEG\Services\Audit_Recorder( $s['settings'], $s['snapshot'], $s['diff'], $s['repository'], $s['context'], $s['reason'], $s['lock'] );
		$s['preflight']  = new \OEG\Services\Preflight( $s['recorder'], $s['snapshot'], $s['context'] );
		$s['recorder']->register();
		$s['preflight']->register();
		$s['privacy'] = new \OEG\Privacy\Privacy( $s['repository'] );
		$s['privacy']->register();
		$s['workspace'] = new \OEG\Admin\Workspace( $this );
		$s['workspace']->register();
		$s['admin'] = new \OEG\Admin\Admin( $this );
		$s['admin']->register();
		add_action(
			'action_scheduler_before_execute',
			function () {
				$this->get( 'context' )->scheduler = true;
			}
		);
		add_action(
			'action_scheduler_after_execute',
			function () {
				$this->get( 'context' )->scheduler = false;
			}
		);
		do_action( 'oeg_loaded', $this );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'oeg_cleanup_orphans' );
	}
}
