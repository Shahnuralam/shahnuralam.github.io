<?php
/** Settings storage and validation. @package OEG */
namespace OEG\Core;

defined( 'ABSPATH' ) || exit;

final class Settings {
	public function defaults() {
		return array(
			'enabled'          => true,
			'manual'           => true,
			'automated'        => true,
			'order_notes'      => false,
			'reason_mode'      => 'disabled',
			'reason_statuses'  => array(),
			'reason_min'       => 3,
			'reason_max'       => 500,
			'warn_paid'        => true,
			'warning_statuses' => array( 'completed', 'refunded', 'cancelled' ),
			'log_ip'           => false,
			'mask_display'     => false,
			'retain_personal'  => true,
			'delete_data'      => false,
			'per_page'         => 20,
			'date_display'     => 'local',
		);
	}

	public function all() {
		$stored = get_option( 'oeg_settings', array() );
		return wp_parse_args( is_array( $stored ) ? $stored : array(), $this->defaults() );
	}

	public function get( $key ) {
		$settings = $this->all();
		return $settings[ $key ] ?? null;
	}

	public function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		foreach ( $input as $key => $value ) {
			if ( in_array( $key, array( 'reason_statuses', 'warning_statuses' ), true ) ) {
				$input[ $key ] = array_filter( (array) $value, 'is_scalar' );
			} elseif ( ! is_scalar( $value ) ) {
				unset( $input[ $key ] );
			}
		}
		$out   = $this->defaults();
		foreach ( array( 'enabled', 'manual', 'automated', 'order_notes', 'warn_paid', 'log_ip', 'mask_display', 'retain_personal', 'delete_data' ) as $key ) {
			$out[ $key ] = ! empty( $input[ $key ] );
		}
		$out['reason_mode'] = in_array( $input['reason_mode'] ?? '', array( 'disabled', 'all', 'statuses' ), true ) ? $input['reason_mode'] : 'disabled';
		$statuses           = array_map(
			static function ( $status ) {
				return substr( $status, 3 );
			},
			array_keys( wc_get_order_statuses() )
		);
		foreach ( array( 'reason_statuses', 'warning_statuses' ) as $key ) {
			$out[ $key ] = array_values( array_intersect( array_map( 'sanitize_key', (array) ( $input[ $key ] ?? array() ) ), $statuses ) );
		}
		$out['reason_min']   = min( 100, max( 1, absint( $input['reason_min'] ?? 3 ) ) );
		$out['reason_max']   = min( 2000, max( $out['reason_min'], absint( $input['reason_max'] ?? 500 ) ) );
		$out['per_page']     = min( 100, max( 5, absint( $input['per_page'] ?? 20 ) ) );
		$out['date_display'] = 'utc' === ( $input['date_display'] ?? '' ) ? 'utc' : 'local';
		return $out;
	}
}
