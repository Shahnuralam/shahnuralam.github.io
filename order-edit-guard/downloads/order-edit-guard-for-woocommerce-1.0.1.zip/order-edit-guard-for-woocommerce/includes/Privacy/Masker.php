<?php
/** Mask audit displays without changing WooCommerce orders. @package OEG */
namespace OEG\Privacy;

defined( 'ABSPATH' ) || exit;

final class Masker {
	public static function mask( $value, $field = '' ) {
		if ( is_array( $value ) ) {
			return array_map(
				static function ( $part ) use ( $field ) {
					return self::mask( $part, $field );
				},
				$value
			);
		}
		$value = (string) $value;
		if ( '' === $value || in_array( $value, array( '[erased]', '[redacted]' ), true ) ) {
			return $value;
		}
		if ( false !== strpos( $field, 'email' ) && is_email( $value ) ) {
			$parts = explode( '@', $value );
			return substr( $parts[0], 0, 1 ) . '***@' . $parts[1];
		}
		if ( false !== strpos( $field, 'phone' ) ) {
			return '******' . substr( preg_replace( '/\D/', '', $value ), -4 );
		}
		return '***';
	}
}
