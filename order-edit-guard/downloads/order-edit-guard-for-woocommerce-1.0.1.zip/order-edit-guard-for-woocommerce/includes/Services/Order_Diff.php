<?php
/** Stable order and item comparisons. @package OEG */
namespace OEG\Services;

defined( 'ABSPATH' ) || exit;

final class Order_Diff {
	private $snapshot;

	public function __construct( Order_Snapshot $snapshot ) {
		$this->snapshot = $snapshot;
	}

	public function compare( array $before, array $after, $filter = true ) {
		$out  = array();
		$meta = $this->snapshot->meta_keys();
		foreach ( array_unique( array_merge( array_keys( $before['fields'] ), array_keys( $after['fields'] ) ) ) as $field ) {
			$old = $before['fields'][ $field ] ?? null;
			$new = $after['fields'][ $field ] ?? null;
			if ( $filter && isset( Order_Snapshot::FIELDS[ $field ] ) && ! in_array( $field, $after['audited_fields'] ?? array_keys( Order_Snapshot::FIELDS ), true ) ) {
				continue; }
			if ( $old === $new ) {
				continue;
			}
			$category  = Order_Snapshot::FIELDS[ $field ] ?? ( 0 === strpos( $field, 'billing_' ) ? 'billing' : 'shipping' );
			$sensitive = in_array( $category, array( 'billing', 'shipping', 'customer', 'note' ), true );
			if ( 0 === strpos( $field, 'meta:' ) ) {
				$config    = $meta[ substr( $field, 5 ) ] ?? array();
				$category  = sanitize_key( $config['category'] ?? 'metadata' );
				$sensitive = ! empty( $config['sensitive'] );
			}
			$change = $this->change( $field, $category, $old, $new, $sensitive, 0, 'order', $after['currency'] );
			if ( 'customer_id' === $field ) {
				$change['metadata']['old_name'] = $before['customer_name'];
				$change['metadata']['new_name'] = $after['customer_name'];
			}
			if ( 0 === strpos( $field, 'meta:' ) ) {
				$change['field_label'] = $meta[ substr( $field, 5 ) ]['label'] ?? $field;
			}
			$out[] = $change;
		}
		foreach ( array_unique( array_merge( array_keys( $before['items'] ), array_keys( $after['items'] ) ) ) as $id ) {
			$old      = $before['items'][ $id ] ?? null;
			$new      = $after['items'][ $id ] ?? null;
			$item     = $new ?? $old;
			$category = array(
				'line_item' => 'items',
				'fee'       => 'fee',
				'shipping'  => 'shipping',
				'coupon'    => 'coupon',
				'tax'       => 'tax',
			)[ $item['type'] ] ?? 'items';
			if ( null === $old || null === $new ) {
				$change                          = $this->change( null === $old ? 'item_added' : 'item_removed', $category, $old, $new, false, absint( $id ), $item['type'], $after['currency'] );
				$change['metadata']['item_name'] = $item['name'];
				$out[]                           = $change;
				continue;
			}
			foreach ( $new['fields'] as $field => $value ) {
				$previous = $old['fields'][ $field ] ?? null;
				if ( $previous === $value ) {
					continue;
				}
				$field_category = $category;
				if ( 'items' === $category && in_array( $field, Order_Snapshot::MONEY, true ) ) {
					$field_category = 'pricing';
				}
				if ( in_array( $field, array( 'taxes', 'total_tax', 'subtotal_tax', 'tax_class' ), true ) ) {
					$field_category = 'tax';
				}
				$change                           = $this->change( $field, $field_category, $previous, $value, false, absint( $id ), $item['type'], $after['currency'] );
				$change['metadata']['item_name']  = $item['name'];
				$change['metadata']['attributes'] = $item['attributes'];
				$out[]                            = $change;
			}
		}
		return $filter ? array_values(
			array_filter(
				$out,
				static function ( $change ) {
					return apply_filters( 'oeg_should_audit_change', true, $change );
				}
			)
		) : $out;
	}

	private function change( $field, $category, $old, $new, $sensitive, $id, $type, $currency ) {
		$sensitive_fields = (array) apply_filters( 'oeg_sensitive_fields', array() );
		return array(
			'field_key'    => $field,
			'field_label'  => $field,
			'category'     => $category,
			'old_value'    => $old,
			'new_value'    => $new,
			'is_sensitive' => $sensitive || in_array( $field, $sensitive_fields, true ),
			'object_id'    => $id,
			'object_type'  => $type,
			'value_type'   => in_array( $field, Order_Snapshot::MONEY, true ) ? 'money' : ( is_array( $old ) || is_array( $new ) ? 'structured' : 'text' ),
			'metadata'     => array( 'currency' => $currency ),
		);
	}
}
