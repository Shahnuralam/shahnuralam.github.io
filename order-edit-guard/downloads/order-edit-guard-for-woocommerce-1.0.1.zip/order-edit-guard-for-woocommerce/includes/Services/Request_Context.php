<?php
/** Actor, source and per-order reason context. @package OEG */
namespace OEG\Services;

defined( 'ABSPATH' ) || exit;

final class Request_Context {
	public $request_id;
	public $operation = array();
	public $denied    = array();
	public $scheduler = false;
	private $reasons  = array();
	private $groups   = array();

	public function __construct() {
		$this->request_id = wp_generate_uuid4();
	}

	public function actor() {
		$user   = wp_get_current_user();
		$source = $this->source();
		$actor  = array(
			'user_id'    => $user->ID,
			'actor_name' => $user->ID ? $user->display_name : __( 'System / Unknown', 'order-edit-guard-for-woocommerce' ),
			'actor_type' => $user->ID ? 'user' : ( in_array( $source, array( 'rest', 'store_api' ), true ) ? 'api' : 'system' ),
			'actor_role' => $user->roles[0] ?? '',
			'source'     => $source,
			'manual'     => $user->ID && is_admin() && ! wp_doing_cron() && ! ( defined( 'WP_CLI' ) && WP_CLI ) && ! $this->scheduler,
		);
		return apply_filters( 'oeg_actor_context', $actor );
	}

	public function source() {
		$source = 'unknown';
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			$source = 'wp_cli';
		} elseif ( $this->scheduler ) {
			$source = 'action_scheduler';
		} elseif ( wp_doing_cron() ) {
			$source = 'cron';
		} elseif ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			$source = 'rest';
		} elseif ( wp_doing_ajax() ) {
			$source = 'ajax';
		} elseif ( is_admin() ) {
			$source = 'wc_admin';
		} elseif ( doing_action( 'woocommerce_checkout_update_order_meta' ) || doing_action( 'woocommerce_checkout_order_processed' ) ) {
			$source = 'checkout';
		}
		return sanitize_key( apply_filters( 'oeg_change_source', $source ) );
	}

	public function group( $id ) {
		if ( ! isset( $this->groups[ $id ] ) ) {
			$this->groups[ $id ] = wp_generate_uuid4();
		}
		return $this->groups[ $id ];
	}

	public function set_reason( $id, $reason ) {
		$this->reasons[ absint( $id ) ] = sanitize_textarea_field( $reason );
	}

	public function reason( $id ) {
		return $this->reasons[ $id ] ?? '';
	}

	public function clear( $id ) {
		unset( $this->reasons[ $id ], $this->groups[ $id ], $this->operation[ $id ], $this->denied[ $id ] );
	}
}
