<?php
/** Capability installation. @package OEG */
namespace OEG\Support;

defined( 'ABSPATH' ) || exit;

final class Capabilities {
	const ALL = array( 'oeg_view_order_audit', 'oeg_view_all_audits', 'oeg_manage_settings' );

	public static function install() {
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( self::ALL as $capability ) {
				$admin->add_cap( $capability );
			}
		}
		$manager = get_role( 'shop_manager' );
		if ( $manager ) {
			$manager->add_cap( 'oeg_view_order_audit' );
		}
	}

	public static function can_view_order( $id ) {
		$id = absint( $id );
		if ( ! $id || ! current_user_can( 'oeg_view_order_audit' ) || ! current_user_can( 'edit_shop_order', $id ) ) {
			return false;
		}
		$order = wc_get_order( $id );
		return $order && 'shop_order' === $order->get_type();
	}
}
