<?php
/** Human-readable audit values; callers escape output. @package OEG */
namespace OEG\Support;

defined( 'ABSPATH' ) || exit;

final class Formatting {
	public static function label( $change ) {
		$labels         = array(
			'status'               => __( 'Order status', 'order-edit-guard-for-woocommerce' ),
			'customer_id'          => __( 'Customer', 'order-edit-guard-for-woocommerce' ),
			'total'                => __( 'Total', 'order-edit-guard-for-woocommerce' ),
			'subtotal'             => __( 'Subtotal', 'order-edit-guard-for-woocommerce' ),
			'quantity'             => __( 'Quantity', 'order-edit-guard-for-woocommerce' ),
			'item_added'           => __( 'Item added', 'order-edit-guard-for-woocommerce' ),
			'item_removed'         => __( 'Item removed', 'order-edit-guard-for-woocommerce' ),
			'discount_total'       => __( 'Discount total', 'order-edit-guard-for-woocommerce' ),
			'shipping_total'       => __( 'Shipping total', 'order-edit-guard-for-woocommerce' ),
			'payment_method'       => __( 'Payment method', 'order-edit-guard-for-woocommerce' ),
			'payment_method_title' => __( 'Payment method title', 'order-edit-guard-for-woocommerce' ),
			'tax_total'            => __( 'Tax total', 'order-edit-guard-for-woocommerce' ),
			'shipping_tax_total'   => __( 'Shipping tax total', 'order-edit-guard-for-woocommerce' ),
			'cart_tax'             => __( 'Order tax', 'order-edit-guard-for-woocommerce' ),
			'shipping_tax'         => __( 'Shipping tax', 'order-edit-guard-for-woocommerce' ),
			'currency'             => __( 'Currency', 'order-edit-guard-for-woocommerce' ),
			'customer_note'        => __( 'Customer note', 'order-edit-guard-for-woocommerce' ),
		);
		$address_labels = array(
			'first_name' => __( 'First name', 'order-edit-guard-for-woocommerce' ),
			'last_name'  => __( 'Last name', 'order-edit-guard-for-woocommerce' ),
			'company'    => __( 'Company', 'order-edit-guard-for-woocommerce' ),
			'address_1'  => __( 'Address line 1', 'order-edit-guard-for-woocommerce' ),
			'address_2'  => __( 'Address line 2', 'order-edit-guard-for-woocommerce' ),
			'city'       => __( 'City', 'order-edit-guard-for-woocommerce' ),
			'state'      => __( 'State', 'order-edit-guard-for-woocommerce' ),
			'postcode'   => __( 'Postcode', 'order-edit-guard-for-woocommerce' ),
			'country'    => __( 'Country', 'order-edit-guard-for-woocommerce' ),
			'email'      => __( 'Email', 'order-edit-guard-for-woocommerce' ),
			'phone'      => __( 'Phone', 'order-edit-guard-for-woocommerce' ),
		);
		$key            = $change['field_key'];
		$label          = $labels[ $key ] ?? ucwords( str_replace( '_', ' ', $change['field_label'] ) );
		if ( preg_match( '/^(billing|shipping)_(.+)$/', $key, $parts ) && in_array( $parts[2], \OEG\Services\Order_Snapshot::ADDRESS, true ) ) {
			/* translators: 1: address type, 2: field. */
			$label = sprintf( __( '%1$s: %2$s', 'order-edit-guard-for-woocommerce' ), 'billing' === $parts[1] ? __( 'Billing', 'order-edit-guard-for-woocommerce' ) : __( 'Shipping', 'order-edit-guard-for-woocommerce' ), $address_labels[ $parts[2] ] ?? $parts[2] );
		}
		return apply_filters( 'oeg_format_field_label', $label, $change );
	}

	public static function value( $change, $side, $mask = false ) {
		$value = $change[ $side . '_value' ];
		if ( $mask && $change['is_sensitive'] ) {
			$masked = \OEG\Privacy\Masker::mask( $value, $change['field_key'] );
			return is_array( $masked ) ? implode( ', ', self::flatten( $masked ) ) : $masked;
		}
		if ( null === $value || '' === $value ) {
			$value = __( 'None', 'order-edit-guard-for-woocommerce' );
		} elseif ( 'money' === $change['value_type'] ) {
			$value = html_entity_decode( wp_strip_all_tags( wc_price( $value, array( 'currency' => $change['metadata']['currency'] ?? get_woocommerce_currency() ) ) ), ENT_QUOTES, 'UTF-8' );
		} elseif ( 'status' === $change['field_key'] ) {
			$value = wc_get_order_status_name( $value );
		} elseif ( 'customer_id' === $change['field_key'] ) {
			$value = $change['metadata'][ $side . '_name' ] ?? __( 'Guest / former customer', 'order-edit-guard-for-woocommerce' );
		} elseif ( is_array( $value ) ) {
			$value = isset( $value['name'] ) ? $value['name'] : implode( ', ', self::flatten( $value ) );
		}
		return apply_filters( 'oeg_format_audit_value', (string) $value, $change, $side );
	}

	private static function flatten( array $values ) {
		$out = array();
		foreach ( $values as $key => $value ) {
			$out[] = $key . ': ' . ( is_array( $value ) ? implode( ', ', self::flatten( $value ) ) : (string) $value );
		}
		return $out;
	}

	public static function date( $date, $utc = false ) {
		$timestamp = strtotime( $date . ' UTC' );
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp, $utc ? new \DateTimeZone( 'UTC' ) : wp_timezone() );
	}
}
