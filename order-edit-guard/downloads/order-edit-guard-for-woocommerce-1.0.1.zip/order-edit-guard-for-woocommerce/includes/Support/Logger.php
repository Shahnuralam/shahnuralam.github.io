<?php
/** Diagnostic logging without order contents. @package OEG */
namespace OEG\Support;

defined( 'ABSPATH' ) || exit;

final class Logger {
	public static function error( $code ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->error( sanitize_key( $code ), array( 'source' => 'order-edit-guard' ) );
		}
		update_option(
			'oeg_last_error',
			array(
				'code' => sanitize_key( $code ),
				'time' => time(),
			),
			false
		);
	}
}
