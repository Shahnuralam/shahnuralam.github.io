<?php
/** Request-scoped advisory serialization; no order-table SQL. @package OEG */
namespace OEG\Support;

defined( 'ABSPATH' ) || exit;

// Plugin-owned audit tables/advisory locks require current database state; WordPress has no CRUD API for them.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

final class Order_Lock {
	private $held = array();

	public function acquire( $order_id ) {
		global $wpdb;
		if ( isset( $this->held[ $order_id ] ) ) {
			return true;
		}
		$name = 'oeg_' . hash( 'sha256', $wpdb->prefix . ':' . absint( $order_id ) );
		$name = substr( $name, 0, 64 );
		if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $name ) ) ) {
			return false;
		}
		$this->held[ $order_id ] = $name;
		return true;
	}

	public function release( $order_id ) {
		global $wpdb;
		if ( isset( $this->held[ $order_id ] ) ) {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $this->held[ $order_id ] ) );
			unset( $this->held[ $order_id ] );
		}
	}

	public function release_all() {
		foreach ( array_keys( $this->held ) as $id ) {
			$this->release( $id );
		}
	}
}
