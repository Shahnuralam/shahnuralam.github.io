<?php
/**
 * Plugin Name: Order Edit Guard for WooCommerce
 * Plugin URI: https://shahnuralam.github.io/order-edit-guard/
 * Description: Clear order change history, staff change reasons and paid-order warnings.
 * Version: 1.0.1
 * Author: Shahnur Alam
 * Author URI: https://shahnuralam.github.io/
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 8.2
 * WC tested up to: 11.1.2
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: order-edit-guard-for-woocommerce
 * Domain Path: /languages
 *
 * @package OEG
 */

defined( 'ABSPATH' ) || exit;

define( 'OEG_VERSION', '1.0.1' );
define( 'OEG_DB_VERSION', '2' );
define( 'OEG_FILE', __FILE__ );
define( 'OEG_PATH', plugin_dir_path( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		if ( 0 === strpos( $class, 'OEG\\' ) ) {
			$file = OEG_PATH . 'includes/' . str_replace( '\\', '/', substr( $class, 4 ) ) . '.php';
			if ( is_file( $file ) ) {
				require_once $file;
			}
		}
	}
);

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', OEG_FILE, true );
		}
	}
);

register_activation_hook( __FILE__, array( '\OEG\Database\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\OEG\Core\Plugin', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Order Edit Guard requires WooCommerce to be installed and activated.', 'order-edit-guard-for-woocommerce' ) . '</p></div>';
				}
			);
			return;
		}
		// WooCommerce APIs and translation catalogs are ready once init has begun.
		add_action( 'init', array( \OEG\Core\Plugin::instance(), 'boot' ), 20 );
	},
	20
);
