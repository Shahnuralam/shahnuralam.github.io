=== Order Edit Guard for WooCommerce ===
Contributors: shahnuralam025
Tags: woocommerce, order history, audit log, order management, change tracking
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Track edits to existing WooCommerce orders, review before-and-after values, collect staff reasons, and warn before important changes.

== Description ==

Order Edit Guard for WooCommerce helps store administrators answer three everyday questions: who changed this order, what changed, and why?

It records meaningful changes to existing orders and groups related edits from the same request. Your team can review history in the order editor, while administrators can browse a store-wide audit history in a dedicated workspace.

= Included in the free plugin =

* **Order edit history:** compare previous and current values for order status, products, quantities, totals, taxes, shipping, fees, coupons, customer details, payment method details, and customer notes.
* **Staff and source context:** see the time, staff identity, reason, and detected source of a change. Sources can include the WooCommerce editor, item AJAX requests, REST API, scheduled tasks, and WP-CLI. Unrecognized sources are labelled as unknown.
* **Change reasons:** keep reasons optional, require them for manual admin edits, or require them for selected order statuses. Required reasons are checked on the server.
* **Paid-order warnings:** remind staff before financial edits to paid orders and before edits to selected important statuses.
* **Store-wide history:** filter by dates, order, staff member, source, category, or a search for staff names and reasons.
* **Overview:** see today's edited orders, change groups, team members, and paid-order activity.
* **Optional order notes:** add a short summary for each recorded change group.
* **Privacy controls:** optional display masking, a setting to avoid retaining sensitive audit values, and IP collection that is off by default.
* **WordPress privacy tools:** register an exporter and eraser for audit data matched to historical billing and staff email hashes.
* **One-page settings:** use seven sidebar tabs and save settings without a page reload. Unsaved edits stay available when switching tabs.
* **System status:** inspect diagnostics, check the audit database, and optionally remove history for deleted orders in batches.
* **WooCommerce HPOS:** use WooCommerce CRUD APIs for order access and separate plugin-owned tables for audit data. Legacy order storage is also supported.

= Important behavior =

This plugin records edits to existing orders after it is activated. It does not reconstruct older history, record initial checkout creation as an edit, or guarantee coverage of integrations that write directly to database tables instead of WooCommerce CRUD APIs.

Warnings help staff review an edit; they are not order locks or payment authorization. Editing an order total does not collect an extra payment or issue a refund. Handle payment and fulfillment separately in WooCommerce.

Automated changes can be audited without requiring a manual staff reason. Installations must keep WooCommerce's own permissions and authentication enabled.

= Free and Pro =

The free plugin works without a license key, trial period, remote service, or paid upgrade. Order Edit Guard Pro is a separately distributed add-on for advanced rules, approvals, locks, reports, notifications, and other workflows. Pro code is not included in this plugin.

Learn about the editions at [the project website](https://shahnuralam.github.io/order-edit-guard/).

= Privacy and data storage =

Audit records are stored locally in three site-specific database tables. Depending on your settings and edits, they may contain staff user IDs/names/roles, timestamps, order IDs, sources, change reasons, before-and-after order values, and optional IP addresses. Historical billing and staff email addresses are matched using salted hashes for privacy requests.

IP collection is disabled by default. Personal audit values are retained by default; display masking is off by default. Masking changes the display, not existing stored records. Disabling personal-value retention affects future records and does not retroactively erase older history. Free does not automatically expire audit records. Use WordPress privacy requests, explicit orphan cleanup, or opt-in uninstall deletion when appropriate for your store.

Only users with the relevant audit permissions can access plugin history. Administrators receive all plugin capabilities by default. Shop managers receive per-order history access subject to WooCommerce's order-edit permissions; store-wide history and plugin settings are not granted to them by default.

The free plugin does not send telemetry, contact external services, load remote assets, or share audit data with the developer. It adds suggested text to WordPress's Privacy Policy Guide. Store operators should review that text and their own retention obligations.

Uninstall preserves audit records and settings by default. Enable **Delete plugin data on uninstall** under **Privacy & data** to remove plugin-owned tables, options, and capabilities on uninstall. WooCommerce orders are not deleted. On multisite, settings and audit history are site-specific; automatic network-wide reporting is not provided.

== Installation ==

1. Install and activate WooCommerce.
2. Install the plugin through **Plugins > Add New > Upload Plugin**, or copy its folder into `wp-content/plugins/`.
3. Activate **Order Edit Guard for WooCommerce**.
4. Open **Order Edit Guard** in the WordPress admin menu and review the General, Change reasons, Order protection, and Privacy & data tabs.
5. Edit an existing WooCommerce order. Open its **Order Edit History** panel to inspect recorded changes.

Minimum requirements: WordPress 6.5, PHP 7.4, and WooCommerce 8.2. Keep a backup and test your store's custom order integrations on staging before enabling required reasons.

== Frequently Asked Questions ==

= Does it work with High-Performance Order Storage (HPOS)? =

Yes. The plugin declares HPOS compatibility and uses WooCommerce CRUD APIs to read orders. Audit data uses its own tables. It also supports legacy order storage.

= Does it show changes made before installation? =

No. History starts when auditing is enabled. Initial order creation is not treated as an edit.

= Can shop managers see or change the settings? =

Not by default. They can view history for orders they are allowed to edit. Store-wide history and settings require separate plugin capabilities granted to administrators by default.

= Are reasons required for API, checkout, cron, or background changes? =

The Free reason policy applies to meaningful manual admin edits. Automated operations continue without a mandatory staff reason. Integrations may supply context through the documented plugin hooks.

= Does editing a paid order charge or refund the customer? =

No. The warning explains that editing an order and changing money already collected are separate operations.

= Does masking delete stored personal data? =

No. Masking affects displays. Disable personal-value retention to redact sensitive values in future audit records, and use WordPress's personal-data eraser for existing matching records.

= What happens when I deactivate or delete the plugin? =

Deactivation keeps the data. Deletion keeps it too unless you explicitly enabled uninstall deletion before removing the plugin. WooCommerce orders are never removed by this plugin.

= Why might a change not appear? =

Check that auditing and the appropriate manual/automated source are enabled. Only supported changes to existing orders made through WooCommerce CRUD hooks can be captured. Review System status and WooCommerce logs if the plugin reports a capture or database error.

= Is Pro required? =

No. All features described as included in the free plugin work without Pro. The separately distributed add-on provides additional workflows.

== Screenshots ==

1. Overview with today's order changes and latest recorded activity.
2. Audit history with filters and readable before-and-after comparisons.
3. General settings for auditing, order notes, time display, and page size.
4. Change reason settings with selected-status and length controls.
5. Order protection settings for paid orders and important statuses.
6. Privacy and data controls with clear explanations of retention and masking.
7. System status with local diagnostics and optional database maintenance.
8. Native WooCommerce order editor with the Order Edit History panel.

== Changelog ==

= 1.0.1 =
* Prepare the first directory submission with documentation, translations, and a clean release package.
* Avoid null HTML sanitization when audit pagination is not needed.
* Harden request types, order-history access checks, optional reason length, and sensitive-value display masking.
* Preserve server permission checks, per-operation nonces, and prepared audit queries.

= 1.0.0 =
* Initial development version with order auditing, staff reasons, warning dialogs, privacy controls, and a dedicated admin workspace.

== Upgrade Notice ==

= 1.0.1 =
Includes audit-history and security hardening plus the initial WordPress.org submission materials. Review privacy settings before recording customer details.
