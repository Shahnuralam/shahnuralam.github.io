<?php
/** Explicit opt-in uninstall; never deletes WooCommerce order data. @package OEG */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
function oeg_uninstall_site() {
	global $wpdb;
	$settings = get_option( 'oeg_settings', array() );
	foreach ( array( 'oeg_cleanup_orphans' ) as $hook ) {
		wp_clear_scheduled_hook( $hook );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( $hook, array(), 'order-edit-guard' ); }
	}
	if ( empty( $settings['delete_data'] ) ) {
		return; }
	foreach ( array( 'events', 'changes', 'identities' ) as $suffix ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Explicit opt-in uninstall removes only the plugin-owned table.
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'oeg_' . $suffix ) ); }
	foreach ( array( 'oeg_settings', 'oeg_db_version', 'oeg_db_error', 'oeg_last_error', 'oeg_identity_secret', 'oeg_welcome', 'oeg_orphan_cursor' ) as $option ) {
		delete_option( $option ); }
	foreach ( wp_roles()->role_objects as $role ) {
		foreach ( array( 'oeg_view_order_audit', 'oeg_view_all_audits', 'oeg_manage_settings' ) as $capability ) {
			$role->remove_cap( $capability ); }
	}
	delete_transient( 'oeg_stats' );
}
if ( is_multisite() ) {
	$offset = 0;
	do {
		$sites = get_sites(
			array(
				'fields' => 'ids',
				'number' => 100,
				'offset' => $offset,
			)
		);
		foreach ( $sites as $site ) {
			switch_to_blog( $site );
			oeg_uninstall_site();
			restore_current_blog(); }
		$offset += 100;
	} while ( count( $sites ) === 100 );
} else {
	oeg_uninstall_site(); }
